#include "asm_utils.h"
#include "led.h"
#include "stdio.h"

// 屏幕IO处理器
extern STDIO stdio;

extern "C" void run_led(int time)
{
    int temp =0x67;		//颜色设置
    char str[] = "20337172 CaiJiaWei";	//输出字符串
    stdio.moveCursor(1,time%80);	//移动光标
    if (time%18 == 0){		//输出全部字符后重现字符
        for(int i = 0; i<18; ++i ) {
            stdio.print(1,(time%80)-18+i,str[i],0xf0);
        }
    }
    if (time%18 != 0){		//跑马灯消失
        stdio.print(1,(time%80-1),' ',0x00);
    }
    stdio.print(str[time%18],temp+time+1);  
    
}
