#ifndef ENTRY_H
#define ENTRY_H
#include <ctime> 
extern "C" void setup_kernel();
void c_time();

#endif
