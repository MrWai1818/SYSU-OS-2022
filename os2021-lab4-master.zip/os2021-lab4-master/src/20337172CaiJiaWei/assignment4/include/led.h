#ifndef ENTRY_H
#define ENTRY_H
extern "C" void run_led(int);

#endif
