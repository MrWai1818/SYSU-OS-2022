#include <iostream>
using namespace std;
extern "C" void function_from_asm();

int main() {	//最后再将调用C/C++的函数的asm函数调用回来
    cout << "Call function from assembly." <<endl;
    function_from_asm();
    cout << "Done." << :endl;
}