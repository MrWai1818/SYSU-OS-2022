#include <stdio.h>

void function_from_C() {	//定义调用C函数
    printf("This is a function from C.\n");
}