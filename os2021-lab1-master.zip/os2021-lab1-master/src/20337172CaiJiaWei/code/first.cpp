#include <iostream>
#include<string>
using namespace std;
int main(){
    cout<<"Enter your name\n "<<endl;
    string name;
    cin>>name;
    cout<<"Thank u!\n"<<endl;
    return 0;
}
