#include<stdio.h>
void main(){
    printf("helloworld\n");
    fflush(stdout);
    while(1);
}