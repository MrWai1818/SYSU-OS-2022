#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"
#include "program.h"
#include "thread.h"
#include "sync.h"

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;
Semaphore semaphore;
int shared_variable;
int spinLock=0;
SpinLock aLock;
void delay(int a){
     int delay = 0xfffffff/a;
        while (delay)
            --delay;
}
void Socrates(void *arg)
{   
    do{
        printf("  *  Socrates: The only good is knowledge and the only evil is ignorance.\n");
       delay(5);
        printf("  *  Socrates: I'm hungry\n");
        semaphore.P(0);
         delay(5);
        semaphore.P(1);
        delay(5);
        printf("  *  Socrates: I'm full and it's time to think\n");
        semaphore.V(1);
        semaphore.V(0);
     } while (1);
}
void Plato(void *arg)
{   
    do{
        printf("  -  Plato: Beauty lies in the eyes of the beholder.\n");
        delay(5);
        printf("  -  Plato: I'm hungry\n");
        semaphore.P(1);
        delay(5);
        semaphore.P(2);
        delay(5);
        printf("  -  Plato: I'm full and it's time to think\n");
        semaphore.V(2);
        semaphore.V(1);
     } while (1);
}
void Aristotle(void *arg)
{   
    do{
        printf("  +  Aristotle: evil is the cause of evil.\n");
        delay(5);
        printf("  +  Aristotle: I'm hungry\n");
        semaphore.P(2);
        delay(5);
        semaphore.P(3);
        delay(5);
        printf("  +  Aristotle: I'm full and it's time to think\n");
        semaphore.V(3);
        semaphore.V(2);
     } while (1);
}
void kratylos(void *arg)
{   
    do{
        printf("  =  kratylos: One cannot step into the same river once.\n");
        delay(5);
        printf("  =  kratylos: I'm hungry\n");
        semaphore.P(3);
        delay(5);
        semaphore.P(4);
        delay(5);
        printf("  =  kratylos: I'm full and it's time to think\n");
        semaphore.V(4);
        semaphore.V(3);
     } while (1);
}
void Heraclitus(void *arg)
{   
    do{
        printf("  #  Heraclitus: There is nothing permanent except change.\n");
        delay(5);
        printf("  #  Heraclitus: I'm hungry\n");
        semaphore.P(4);
        delay(5);
        semaphore.P(0);
        delay(5);
        printf("  #  Heraclitus: I'm full and it's time to think\n");
        semaphore.V(0);
        semaphore.V(4);
     } while (1);
}
void first_thread(void *arg)
{
    // 第1个线程不可以返回
    stdio.moveCursor(0);
    for (int i = 0; i < 25 * 80; ++i)
    {
        stdio.print(' ');
    }
    stdio.moveCursor(0);

    semaphore.initialize(3);
    aLock.initialize();

    programManager.executeThread(Socrates, nullptr, "second thread", 1);
    
    programManager.executeThread(Plato, nullptr, "third thread", 1);
    programManager.executeThread(Aristotle, nullptr, "forth thread", 1);
    programManager.executeThread(kratylos, nullptr, "fifth thread", 1);
    programManager.executeThread(Heraclitus, nullptr, "sixth thread", 1);
    asm_halt();
}

extern "C" void setup_kernel()
{

    // 中断管理器
    interruptManager.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);

    // 输出管理器
    stdio.initialize();

    // 进程/线程管理器
    programManager.initialize();

    // 创建第一个线程
    int pid = programManager.executeThread(first_thread, nullptr, "first thread", 1);
    if (pid == -1)
    {
        printf("can not execute thread\n");
        asm_halt();
    }

    ListItem *item = programManager.readyPrograms.front();
    PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
    firstThread->status = RUNNING;
    programManager.readyPrograms.pop_front();
    programManager.running = firstThread;
    asm_switch_thread(0, firstThread);

    asm_halt();
}
