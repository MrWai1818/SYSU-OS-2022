#include "sync.h"
#include "asm_utils.h"
#include "stdio.h"
#include "os_modules.h"

SpinLock::SpinLock()
{
    initialize();
}

void SpinLock::initialize()
{
    bolt = 0;
}

// void SpinLock::lock()
// {
//     uint32 key = 1;

//     do
//     {
//         asm_atomic_exchange(&key, &bolt);
//         //printf("pid: %d\n", programManager.running->pid);
//     } while (key);
// }
void SpinLock::lock(){  //没有原子指令会导致因为中断而重来
    while (bolt ==1)
    {
        if (bolt == 0){		//简单的循环作为锁
            break;
        }
    }
    
    bolt = 1;
}
void SpinLock::unlock()
{
    bolt = 0;
}