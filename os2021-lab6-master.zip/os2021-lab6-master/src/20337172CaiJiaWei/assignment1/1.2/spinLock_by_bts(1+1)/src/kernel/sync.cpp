#include "sync.h"
#include "asm_utils.h"
#include "stdio.h"
#include "os_modules.h"

SpinLock::SpinLock()
{
    initialize();
}

void SpinLock::initialize()
{
    bolt = 0;
}

void SpinLock::lock()
{
     uint32 key = 1;

     do
     {
         asm_atomic_exchange(&key, &bolt);
//         printf("pid: %d  bolt:%d \n", programManager.running->pid,bolt);
     } while (key);
 }

void SpinLock::lock()
{
    uint32 key = 1;

    do
    {
        asm_exchange3(&key, &bolt);
       // printf("pid: %d  bolt:%d \n", programManager.running->pid,bolt);
    } while (key);
}

void SpinLock::unlock()
{
    bolt = 0;
}