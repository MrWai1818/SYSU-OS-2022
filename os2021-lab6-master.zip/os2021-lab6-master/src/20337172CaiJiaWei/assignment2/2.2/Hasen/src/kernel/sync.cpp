#include "sync.h"
#include "asm_utils.h"
#include "stdio.h"
#include "os_modules.h"

SpinLock::SpinLock()
{
    initialize();
}

void SpinLock::initialize()
{
    bolt = 0;
}

void SpinLock::lock()
{
    uint32 key = 1;

    do
    {
        asm_atomic_exchange(&key, &bolt);
        //printf("pid: %d  bolt:%d \n", programManager.running->pid,bolt);
    } while (key);
}

// void SpinLock::lock(){
//     while (bolt ==1)
//     {
//         if (bolt == 0){
//             break;
//         }
//     }
    
//     bolt = 1;
// }

// void SpinLock::lock()
// {
//      int ticket =programManager.running->pid;
//      tickets[bolt] = ticket;
//     while (programManager.running->pid !=tickets[bolt]) {
//     }
// }


// void SpinLock::unlock()
// {
//     tickets[bolt] = 0;
//     bolt++;
// }
void SpinLock::unlock()
{
    bolt=0;
}
Semaphore::Semaphore()
{
    initialize(0);
}

void Semaphore::initialize(uint32 counter)
{
    this->space= counter;
    this->taken = 0 ;
    semLock.initialize();
    waiting.initialize();
}

void Semaphore::P(int v)
{
    PCB *cur = nullptr;
    
    while (true)
    {
        semLock.lock();
        if ((v == 1)&&(space>0))
        {
            --space;
            semLock.unlock();
            return;
        }
        if ((v == 0)&&(taken>0))
        {
            --taken;
            semLock.unlock();
            return;
        }
        cur = programManager.running;
        waiting.push_back(&(cur->tagInGeneralList));
        cur->status = ProgramStatus::BLOCKED;
        semLock.unlock();
        programManager.schedule();
    }
}

void Semaphore::V(int v)
{
    semLock.lock();
    if(v==1){
        space++;
    }
    if(v==0){
        taken++;
    }
    semLock.unlock();
}   

void Semaphore::W(){
    PCB *program = ListItem2PCB(waiting.front(), tagInGeneralList);
    waiting.pop_front();
    semLock.unlock();
    programManager.MESA_WakeUp(program);
}