#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"
#include "program.h"
#include "thread.h"
#include "sync.h"

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;
Semaphore semaphore;
int shared_variable;
int spinLock=0;
SpinLock aLock;
int drink;
void bartender(void *arg)
{ 
   while (drink <3){
      semaphore.P(1);
        int delay = 0;
        printf("  *  bartenderr: I'm going to barteding, there are %d drink now\n", drink);
        // 
        printf("  *  bartenderr: I'm rolling , it'll take a seconds\n");
        delay = 0xfffffff/5;
        while (delay)
            --delay;

        drink += 1;
        printf("  *  bartender: Here has %d  drink now .\n ",drink);
        printf(" *  bartender: I need some time to clean the bottle\n");
        // 
        
        delay = 0xfffffff/5;
        while (delay)
            --delay;
        // done
        printf("  *  bartender:then I should put these %d cups of drink on the bar \n",drink);
       semaphore.V(0);
     }
     while(semaphore.waiting.size()){
            semaphore.W();
     }
}
void customer1(void *arg){
     printf("customer 1: I'm going to buy a cup of drink,\n");
    //  while (1){
    //     if (drink >0){  
            semaphore.P(0);
            drink --;
            printf("customer 1:OK,I get it\n");
            semaphore.V(1);
    //        break;
    //     }
    // } 
}
void customer2(void *arg){
    printf("customer 2: I'm going to get some  drink,\n");
     //while (1){
       // if (drink >0){
           semaphore.P(0);
            drink --;
            printf("customer 2:OK,I get it\n");
            semaphore.V(1);
        //     break;
        //  }
  //  } 
}
void customer3(void *arg){
      printf("customer 3: I'm going to  drink,\n");
    // while (1){
     //  if (drink >0){
           semaphore.P(0);
          
            drink --;
            printf("customer 3:OK,I get it\n");
            semaphore.V(1);
        //     break;
        //  }
  // } 
}

void first_thread(void *arg)
{
    // 第1个线程不可以返回
    stdio.moveCursor(0);
    for (int i = 0; i < 25 * 80; ++i)
    {
        stdio.print(' ');
    }
    stdio.moveCursor(0);

    drink= 0;
    semaphore.initialize(3);
    aLock.initialize();

    programManager.executeThread(bartender, nullptr, "second thread", 1);
    programManager.executeThread(customer1, nullptr, "third thread", 1);
    programManager.executeThread(customer2, nullptr, "forth thread", 1);
    programManager.executeThread(customer3, nullptr, "fifth thread", 1);
    asm_halt();
}

extern "C" void setup_kernel()
{

    // 中断管理器
    interruptManager.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);

    // 输出管理器
    stdio.initialize();

    // 进程/线程管理器
    programManager.initialize();

    // 创建第一个线程
    int pid = programManager.executeThread(first_thread, nullptr, "first thread", 1);
    if (pid == -1)
    {
        printf("can not execute thread\n");
        asm_halt();
    }

    ListItem *item = programManager.readyPrograms.front();
    PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
    firstThread->status = RUNNING;
    programManager.readyPrograms.pop_front();
    programManager.running = firstThread;
    asm_switch_thread(0, firstThread);

    asm_halt();
}
