#ifndef SYNC_H
#define SYNC_H

#include "os_type.h"
#include "list.h"

class SpinLock
{
private:
    uint32 bolt;
    uint32 tickets[32] ;
public:
    SpinLock();
    void initialize();
    void lock();
    void unlock();
};

class Semaphore
{
private:
    uint32 taken;		//代表临界区已被占据资源数
    uint32 space;		//代表临界区剩余资源数
    List waiting;		//等待队列
    SpinLock semLock;	//锁
public:
    Semaphore();
    void initialize(uint32 counter); //初始化space为临界资源的上限
    void P(int v);		//int v用于判断占用的是space还是taken
    void V(int v);		//int v用于判断占用的是space还是taken
};
#endif
