#include "sync.h"
#include "asm_utils.h"
#include "stdio.h"
#include "os_modules.h"

SpinLock::SpinLock()
{
    initialize();
}

void SpinLock::initialize()
{
    bolt = 0;
}

void SpinLock::lock()
{
    uint32 key = 1;

    do
    {
        asm_atomic_exchange(&key, &bolt);
        //printf("pid: %d  bolt:%d \n", programManager.running->pid,bolt);
    } while (key);
}

// void SpinLock::lock(){
//     while (bolt ==1)
//     {
//         if (bolt == 0){
//             break;
//         }
//     }
    
//     bolt = 1;
// }

// void SpinLock::lock()
// {
//      int ticket =programManager.running->pid;
//      tickets[bolt] = ticket;
//     while (programManager.running->pid !=tickets[bolt]) {
//     }
// }


// void SpinLock::unlock()
// {
//     tickets[bolt] = 0;
//     bolt++;
// }
void SpinLock::unlock()
{
    bolt=0;
}
Semaphore::Semaphore()
{
    initialize(0);
}

void Semaphore::initialize(uint32 counter)
{
    this->space= counter;
    this->taken = 0 ;
    semLock.initialize();
    waiting.initialize();
}

void Semaphore::P(int v)
{
    PCB *cur = nullptr;
    while (true)
    {
        semLock.lock();		//自旋锁上锁
        if ((v == 1)&&(space>0))	//如果输入为1，代表使用的信号量是space
        {
            --space;				//space信号量减少，代表生产一个临界资源到临界区
            semLock.unlock();		//解锁
            return;
        }
        if ((v == 0)&&(taken>0))	//如果输入为0，代表使用的信号量是taken
        {
            --taken;				//taken信号量减少，代表临界区的一个临界资源被消耗
            semLock.unlock();
            return;
        }
        cur = programManager.running;		//如果两个信号量都没法改变
        waiting.push_back(&(cur->tagInGeneralList));	//阻塞当前进程并放入等待队列
        cur->status = ProgramStatus::BLOCKED;			
        semLock.unlock();
        programManager.schedule();
    }
}

void Semaphore::V(int v)
{
    semLock.lock();
    if(v==1){		//如果输入为1，代表使用的信号量是space
        space++;	//space信号量增加，代表临界区的一个临界资源被消耗
    }
    if(v==0){	//如果输入为0，代表使用的信号量是taken
        taken++;	//space信号量减少，代表生产一个临界资源到临界区
    }
    if (waiting.size())	//如果两个信号量都没法改变
    {
        PCB *program = ListItem2PCB(waiting.front(), tagInGeneralList);
        waiting.pop_front();	//唤醒之前阻塞的进程
        semLock.unlock();
        programManager.MESA_WakeUp(program);
    }
    else
    {
        semLock.unlock();
    }
}   