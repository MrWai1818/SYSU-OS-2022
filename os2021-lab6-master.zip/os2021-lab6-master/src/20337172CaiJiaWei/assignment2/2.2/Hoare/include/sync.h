#ifndef SYNC_H
#define SYNC_H

#include "os_type.h"
#include "list.h"

class SpinLock
{
private:
    uint32 bolt;
    uint32 tickets[32] ;
public:
    SpinLock();
    void initialize();
    void lock();
    void unlock();
};

class Semaphore
{
private:
    uint32 taken;
    uint32 space;
    List waiting;
    SpinLock semLock;

public:

    Semaphore();
    void initialize(uint32 counter);
    void P(int v);
    void V(int v);
};
#endif
