#include "sync.h"
#include "asm_utils.h"
#include "stdio.h"
#include "os_modules.h"

SpinLock::SpinLock()
{
    initialize();
}

void SpinLock::initialize()
{
    bolt = 1;
}

// void SpinLock::lock()
// {
//     uint32 key = 1;

//     do
//     {
//         asm_atomic_exchange(&key, &bolt);
//         printf("pid: %d  bolt:%d \n", programManager.running->pid,bolt);
//     } while (key);
// }

// void SpinLock::lock(){
//     while (bolt ==1)
//     {
//         if (bolt == 0){
//             break;
//         }
//     }
    
//     bolt = 1;
// }

void SpinLock::lock()
{
     int ticket =programManager.running->pid;
     tickets[bolt] = ticket;
    while (programManager.running->pid != bolt) {
    }
}


void SpinLock::unlock()
{
    tickets[bolt] = 0;
    bolt++;
}