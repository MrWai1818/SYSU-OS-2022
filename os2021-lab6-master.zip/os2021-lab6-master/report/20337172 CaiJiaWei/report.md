<font size =6>**操作系统原理 实验六**</font>

## 个人信息



【院系】	计算机学院

【专业】	计算机科学与技术

【学号】	20337172

【姓名】   蔡嘉威

## 实验题目

并发与锁机制

## 实验目的

1. 学习自旋锁以及使用自旋锁实现信号量，并在原子指令层面理解其实现过程。
1. 实现自定义的锁机制。
2. 学习使用信号量机制解决同步互斥问题。
2. 学习死锁的解决方法。

## 实验要求

1. 复现自旋锁和信号量机制。
2. 实现自定义的锁机制。
3. 掌握几种经典的同步互斥问题解决方法。
4. 撰写实验报告。

## 实验方案

###  Assignment 1 代码复现题：

- #### 1.1 代码复现：

  操作系统会出现许多多个进程并发(同时)访问操作共享数据的情况，而这将引发竞争条件。为了解决竞争条件，我们需要将各个进程进行同步处理，使本来异步进行的进程相互配合，有序推进。本次实验以”消失的芝士汉堡“为例，其中cheese_burger为临界资源，是mother和son两个线程将进行改动的共享资源。进程对于临界资源的更改部分为临界区，而**同一时间进入临界区的进程只能有一个，这便是进程的互斥**。为了协调线程之间的对共享变量的访问顺序，我们首先使用自旋锁工具。

  - #### 自旋锁：

    定义一个共享变量bolt作为线程进入更改临界资源cheese_burger临界区的锁。当bolt为1代表已经有线程进入临界区，其他线程便不能够在进入临界区，以此实现互斥。而之所以叫自选锁、便是让线程在临界区外执行循环，而不是将线程挂起，直到临界区空闲。其中让临界区外执行循环的方式便是利用**”原子“指令asm_atomic_exchange(&key, &bolt)**使bolt在0和1之间切换或者在1状态循环。

    为了方便管理，我们将锁封装成一个类：
    
    ```c
    class SpinLock
    {
    private:
        uint32 bolt;	//锁
    public:
        SpinLock();		//定义
        void initialize();	//初始化，bolt=0
        void lock();	//上锁
        void unlock();	//开锁，简单设置bolt=0即可
    }；
    ```
    
    ```c
     void SpinLock::lock()
     {
         uint32 key = 1;	//检查bolt是否为1
         do
         {
             asm_atomic_exchange(&key, &bolt);	//通过"原子"命令，改变bolt的值
             //printf("pid: %d\n", programManager.running->pid);
         } while (key);		//如果是则做循环
     }
    ```
    
    其中的asm_atomic_exchange(&key, &bolt)并不是真正的原子，其中的**xchg**才是真正的原子指令，用于交换内存地址和寄存器的值。
    
    ```asm
    asm_atomic_exchange:;交换key和bolt的值
        push ebp
        mov ebp, esp
        pushad
    
        mov ebx, [ebp + 4 * 2] ; register
        mov eax, [ebx]         ; 读取key的值到eax
        mov ebx, [ebp + 4 * 3] ; memory
        xchg [ebx], eax        ;通过原子指令将key的值与bolt的值交换
        mov ebx, [ebp + 4 * 2] ; memory
        mov [ebx], eax         ; 将交换过(先前)bolt的值给key
    
        popad
        pop ebp
        ret
    ```
    
     其中用于交换的填入的register不能是**共享变量**。因为我们需要的是将register的值取出，并放入memory的地址当中。如果register是共享变量bolt，当有两个进程同时访问 **asm_atomic_exchange**时，会出现填入memory的值都为0的矛盾现象，从而导致两个进程同时进入临界区。也只有当register不是**共享变量的时候**，asm_atomic_exchange才是一个**真正的原子指令。**
    
    - #### 值得一提的事：
    
      事实上自旋锁就是简单设置循环，使进程在临界区外的地方不推进。是可以简单通过以下简单的实现的：
    
      ```c
      void SpinLock::lock(){  //没有原子指令会导致因为中断而重来
          while (bolt ==1)
          {
              if (bolt == 0){		//简单的循环作为锁
                  break;
              }
          }
          
          bolt = 1;
      }
      ```
    
      但是为了保证**循环和bolt的值的变化不会因为中断而停止，需要原子指令来实现锁，所以简单的循环是不行的。**
    
      但是因为自旋锁是将进程运行**停在临界区前不断循环**，这占据CPU的资源，因为未被换下，消耗处理机时间。 而且容易导致饥饿， 可能死锁，我们便寻求更好的方式——信号量。
  
  - #### 信号量：
  
    设置信号量或者说是共享资源counter，在每个进程进入临界区前，先对共享资源的数量进行判断，如果共享资源有剩，可以认为是临界区空闲，进程可以进入临界区。否则将进程改为**阻塞态**，并且进入等待队列waiting。因为出现了共享资源counter和等待队列waiting，所以对其进行更改的操作也是**临界区，需要进程互斥访问**，我们便要使用到先前实现的自旋锁。
  
    信号量的实现也将封装成类。
  
    ```c++
    class Semaphore
    {
    private:
        uint32 counter; //共享资源数
        List waiting;   //等待队列
        SpinLock semLock;	//先前实现的自旋锁
    
    public:
        Semaphore();	//定义
        void initialize(uint32 counter);	//初始化，共享资源数自己设置
        void P();		//共享资源消耗
        void V();		//共享资源返还
    };
    ```
  
    关于共享资源消耗的P操作：首先加上先前实现的自旋锁，**上锁是为了互斥的对临界资源counter和waiting进行改变**，再对共享资源的残余进行判断。如果**共享资源**有剩余，则消耗对应数量共享资源，解锁，进程进入临界区；如果没剩余，则将当前进程进行**阻塞，并且加入到等待队列。并且在下一次调度到该进程时，会进行循环，直到共享资源有剩余。**
  
    ```c++
    void Semaphore::P()
    {
        PCB *cur = nullptr;		//当前进程
    	
        while (true)	//如果临界资源counter没有剩余，当前进程将会在P操作循环进行
        {
            semLock.lock();		//上锁
            if (counter > 0)	//如果临界资源有剩
            {
                --counter;		//消耗一个资源
                semLock.unlock();	//开锁
                return;			//进程进入临界区
            }
    		//临界资源没有剩余
            cur = programManager.running;	//当前进程进入等待队列
            waiting.push_back(&(cur->tagInGeneralList));
            cur->status = ProgramStatus::BLOCKED;	//当前进程阻塞
    
            semLock.unlock();			//开锁
            programManager.schedule();	//线程调度
        }
    }
    ```
  
    当进程进入临界区并且完成修改后，**在退出区需要进行V操作，对共享资源counter和waiting进行释放。**因为涉及到**对临界资源修改，还是需要使用自旋锁进行互斥访问。**
  
    ```c++
    void Semaphore::V()
    {
        semLock.lock();	//为修改临界资源，互斥，上锁
        ++counter;		//返回共享资源
        if (waiting.size())	//如果等待队列有成员
        {
            PCB *program = ListItem2PCB(waiting.front(), tagInGeneralList);
            waiting.pop_front();	//调出该成员
            semLock.unlock();		//开锁
            programManager.MESA_WakeUp(program);	//唤醒之前阻塞的进程
        }
        else
        {
            semLock.unlock();	//直接开锁
        }
    }
    ```
  
    其中唤醒函数模型为**MESA模型**，我们在下一次线程调度时才会运行我们刚刚唤醒的阻塞线程。而当前运行的线程会运行直到运行结束。
  
    ```c++
    void ProgramManager::MESA_WakeUp(PCB *program) {//唤醒阻塞态的进程
        program->status = ProgramStatus::READY;		//改为就绪态
        readyPrograms.push_front(&(program->tagInGeneralList));//放入就绪队列
    }
    ```
  
  
  - #### 线程调度检验：
  
    * 关于自旋锁的插入部分与信号量相似，**都是在临界区前上锁，临界区后解锁**，便不再赘述。
  
    ##### 信号量：
  
    ```c++
    void a_mother(void *arg)
    {
        semaphore.P();	//P操作
        int delay = 0;  //延时
        //临界区
        printf("mother: start to make cheese burger, there are %d cheese burger now\n", cheese_burger);
        // make 10 cheese_burger
        cheese_burger += 10;	//临界资源改动
        printf("mother: Here has %d cheese burgers now .\n ",cheese_burger);
        printf("mother: oh, I have to hang clothes out.\n");
        // hanging clothes out
        delay = 0xfffffff;	//延时
        while (delay)
            --delay;
        // done
    
        printf("mother: Oh, Jesus! There are %d cheese burgers\n", cheese_burger);
        semaphore.V(); //V操作
    }
    ```
  
  以上代码复现结束。

- #### 1.2  锁机制的实现

  在实验教程中我们使用xchg这一原子操作来实现自旋锁。接下来我们将采用**原子指令bts以及lock前缀**来实现自旋锁。其中bts指令为**位测试并置位**指令，作用是将字串对应位的字符取出放置到CF位中，并将对应位置0，如果对应位的字符为0则置1。

  ```asm
  asm_exchange3 :
      push ebp
      mov ebp, esp
      pushad
      mov ebx, [ebp + 4 * 2] ; register    
      mov ecx, [ebp + 4 * 3] ; memory
      mov eax,[ebx]		;获取register值
      mov edx,[ecx]		;获取memory值
      cmp eax,edx			;如果两个值一致，代表锁被占用
      je out				;则不改变register的值，返回
      lock btc dword [ebx], 0  ; 	否则将register取反
      lock btc dword [ecx], 0  ; 否则将memory取反
      popad
      pop ebp
      ret    
  out :
      popad
      pop ebp
      ret
  ```

  我们设置如同教程中的key值作为是否要进行上锁的标准并预设为1，在上述函数中key值作为register的输入而bolt作为memory的输入。如果register和memory的值**均为1**即相同时，代表着临界区被占用，我们将不会对bolt值进行修改，而是返回并进行循环。如果不相等意味着，bolt的值为0，这时我们通过**bts将key和bolt同时取反**，以达到两个值交换的效果。

  余下实现均与实验教程相同，便不再赘述。

  - #### 一点思考：

    如果不将锁封装成类，而是选择采用一个全局变量作为自旋锁的锁，将会减少开关锁的代码量。

    ```c++
    int spinLock = 0; //锁
    ```

    之后在临界区前直接调用asm_exchange2函数即可。

    ```asm
    asm_exchange2 :		;不采用类封装
        lock bts dword [spinLock], 0  ;只需将输入，即锁取反即可(将输入的值放入CF位)    
        jb asm_exchange2		;如果CF为1则循环
        ret
    ```

    以上减少了代码量。

### Assignment 2 生产者-消费者问题：

- #### 2.1 Race Condition：

  在生产者-消费者问题中，生产者和消费者共同享有一个临界区，并且对临界区的访问需要互斥，即生产者生产临界资源时，消费者不能消费；消费者消费时，生产者不能生产。当临界区满时，生产者不能生产，当临界区空时，消费者不能消费。因此临界区有上限值，生产者-消费者问题也成为有限缓冲区问题。

  - 因此设置drink变量作为临界资源，上限为3，有一个生产者线程bartender，每次循环生产一个drink直到缓冲区满。

    ```c++
    int drink;		//临界资源
    void bartender(void *arg)
    {
        //aLock.lock();
       while (drink <3){	//在临界区满之前会一直生产
            int delay = 0;
            printf("  *  bartenderr: I'm going to barteding, there are %d drink now\n", drink);	//判断当前临界资源数量
            printf("  *  bartenderr: I'm rolling , it'll take a seconds\n");
            delay = 0xfffffff/5;	//生产临界资源需要时间
            while (delay)
                --delay;
            drink += 1;			//临界资源增加
            printf("  *  bartender: Here has %d  drink now .\n ",drink);//判断当前临界资源数量
            printf("  *  bartender: I need some time to clean the bottle\n");
            // 下一次生产的时间间隔
            delay = 0xfffffff/5;
            while (delay)
                --delay;
            // done
         }
       // aLock.unlock();
    }
    ```

    - 为了更加直观地体现竞争条件，在最开始会判断临界资源数目、生产临界资源时需要花费时间、生产后再次判断临界资源数目、在生产下一个临界资源前需要等待时间。

  - 设置三个消费者，它们的内容一致，都是先屏幕打印调度被提示、消费1个临界资源并且输出提示信息。但为了区分三个消费者，**对于屏幕打印内容会有所不同**。

    ```c++
    void customer1(void *arg){ //1号消费者
         printf("customer 1: I'm going to buy a cup of drink,\n");//不同提示信息
        drink --;		//消费临界资源
        printf("customer 1:OK,I get it\n");
    }
    void customer2(void *arg){	//2号消费者
         printf("customer 2: I'm going to get some  drink,\n");//不同提示信息
        drink -=1;		//消费临界资源
        printf("customer 2:OK,I get it\n");
     
    }
    void customer3(void *arg){	//3号消费者
         printf("customer 3: I'm going to  drink,\n");//不同提示信息
        drink -=1;		//消费临界资源
        printf("customer 3:OK,I get it\n");
    }
    ```

  - 线程调度，与以往的实验一致，增加了对临界资源和锁的初始化

    ```c++
    drink= 0; //临界资源的初始化
    aLock.initialize();
    //线程调度
    programManager.executeThread(bartender, nullptr, "second thread", 1);
    programManager.executeThread(customer1, nullptr, "third thread", 1);
    programManager.executeThread(customer2, nullptr, "forth thread", 1);
    programManager.executeThread(customer3, nullptr, "fifth thread", 1);
    ```

    - 生产者只调用一次，生产者线程在临界区满时就会停止生产。

- #### 2.2 信号量解决方法：

  大致使用Assignment1中的信号量实现，其中类改动如下：

  ```c++
  class Semaphore
  {
  private:
      uint32 taken;		//代表临界区已被占据资源数
      uint32 space;		//代表临界区剩余资源数
      List waiting;		//等待队列
      SpinLock semLock;	//锁
  public:
      Semaphore();
      void initialize(uint32 counter); //初始化space为临界资源的上限
      void P(int v);		//int v用于判断使用的是space还是taken
      void V(int v);		//int v用于判断使用的是space还是taken
  };
  ```

  - 设置两个信号量，taken代表临界区已被占据资源数，space代表临界区剩余资源数。两个信号量的改变与访问要分开进行。
  - 因此P()操作和V()操作需要靠输入的参数判断是哪个信号量要进行改变。

  ```c++
  void Semaphore::P(int v)
  {
      PCB *cur = nullptr;
      while (true)
      {
          semLock.lock();		//自旋锁上锁
          if ((v == 1)&&(space>0))	//如果输入为1，代表使用的信号量是space
          {
              --space;				//space信号量减少，代表生产一个临界资源到临界区
              semLock.unlock();		//解锁
              return;
          }
          if ((v == 0)&&(taken>0))	//如果输入为0，代表使用的信号量是taken
          {
              --taken;				//taken信号量减少，代表临界区的一个临界资源被消耗
              semLock.unlock();
              return;
          }
          cur = programManager.running;		//如果两个信号量都没法改变
          waiting.push_back(&(cur->tagInGeneralList));	//阻塞当前进程并放入等待队列
          cur->status = ProgramStatus::BLOCKED;			
          semLock.unlock();
          programManager.schedule();
      }
  }
  ```

  ```c++
  void Semaphore::V(int v)
  {
      semLock.lock();
      if(v==1){		//如果输入为1，代表使用的信号量是space
          space++;	//space信号量增加，代表临界区的一个临界资源被消耗
      }
      if(v==0){	//如果输入为0，代表使用的信号量是taken
          taken++;	//space信号量减少，代表生产一个临界资源到临界区
      }
      if (waiting.size())	//如果两个信号量都没法改变
      {
          PCB *program = ListItem2PCB(waiting.front(), tagInGeneralList);
          waiting.pop_front();	//唤醒之前阻塞的进程
          semLock.unlock();
          programManager.MESA_WakeUp(program);
      }
      else
      {
          semLock.unlock();
      }
  }   
  ```

  - 生产者和消费者有着不同的信号量改动顺序。因此P()和V()通过设置额外变量作为判断依据。

  **生产者**的信号量机制引入如下：

  ```c++
  void bartender(void *arg)
  {
     while (drink <3){	//在临界区满之前会一直生产
     	semaphore.P(1); 	//space变量减少
        ........
        semaphore.V(0); 	//taken变量增加
       }
  }
  ```

  **消费者**的信号量机制引入如下：

  ```c++
  void customer1(void *arg){ //1号消费者
       printf("customer 1: I'm going to buy a cup of drink,\n");//不同提示信息
      semaphore.P(0);	//space增加
      drink --;		//消费临界资源
      printf("customer 1:OK,I get it\n");
      semaphore.V(1);	//taken减少
  }
  ```

  其余实现与以往实验一致，便不再赘述。

- #### 程序唤醒的实现：

  - **MESA模型**：实验教程中的模型，便不再赘述。

  - **Hasen模型：**线程被唤醒后会在当**前线程执行完成后**立即运行刚被唤醒的线程。

    ```c++
    void Semaphore::V(int v)	//V操作仅作为改动信号量的值
    {
        semLock.lock();
        if(v==1){
            space++;
        }
        if(v==0){
            taken++;
        }
        semLock.unlock();
    }   
    
    void Semaphore::W(){	//将第一个等待队列的阻塞进程唤醒
        PCB *program = ListItem2PCB(waiting.front(), tagInGeneralList);
        waiting.pop_front();
        semLock.unlock();
        programManager.MESA_WakeUp(program);
    }
    ```
    
    - 因为Hasen模型是在线程结束后才调度阻塞线程，所以我们不会在V操作唤醒，而是另起炉灶W操作
    
    ```C++
    void bartender(void *arg)//生产者
    { 
       while (drink <3){
          .......
         }
         while(semaphore.waiting.size()){	//检测等待队列，如果不为空
                semaphore.W();				//唤醒等待队列的线程
         }
    }
    ```
    
    - 因为我们预设仅调用了1次生产者，所以所有的线程唤醒都交给线程结束的部分。
    - 消费者也是在线程的最后**加上while循环来唤醒当前所有阻塞线程**。

  - **Hoare 模型：**阻塞线程被唤醒后，中断当前运行的线程，立即执行被唤醒的线程，等阻塞线程完成再回来运行当前线程。

    ```c++
    void Semaphore::V(int v)
    {
        .....
        if (waiting.size())
        {
            PCB *program = ListItem2PCB(waiting.front(), tagInGeneralList);
            waiting.pop_front();	//唤醒线程
            semLock.unlock();
            programManager.MESA_WakeUp(program);	
            programManager.schedule();	//唤醒线程后直接执行线程调度，之后在调度函数更改即可
        }
        else
        {
            semLock.unlock();
        }
    }   
    ```

    - 将线程唤醒后直接进行线程调度即可

### Assignment 3 哲学家就餐问题：

**哲学家问题：**有五个哲学在坐在圆桌用餐和思考，每一个哲学家的左边和右边分别有一支筷子。当一位哲学家思考时，他与其他同事不交流。当哲学家感到饥饿时会尝试拿起左边和右边的筷子就餐，且一次只能拿一支筷子，显然他不能从其他哲学家手里拿走筷子，只有当左边的筷子和右边的筷子同时在一个哲学家手中时，该哲学家方可就餐。就餐完毕后，该哲学家会将筷子放回原处，并开始思考。

**死锁：**两个或两个以上的进程在执行过程中，都在等待互相或者另一个进程的资源而导致阻塞，这将使程序无法推进。哲学家问题中死锁出现在于**五个哲学家同时拿起一个筷子**，每个哲学家又在等待其他哲学家给出筷子，这将导致死锁。

- #### 3.1 初步解决方法

  按照上述提及的哲学家问题，使用信号量机制来解决该问题。

  - 首先先设置好时间间隔的函数
  
    ```c++
    void delay(int a){	//思考与用餐时间间隔
         int delay = 0xfffffff/a;
            while (delay)
                --delay;
    }
    ```
  
  - 5位哲学家的线程实现：
  
      ```c++
      void Socrates(void *arg)	//苏格拉底
      {   
      do{	//在吃饭与思考间循环
          printf("  *  Socrates: The only good is knowledge and the only evil is ignorance.\n");	
         delay(5);	//思考
          printf("  *  Socrates: I'm hungry\n");	//尝试拿起筷子的信息
          semaphore.P(0);		//拿起左筷子
           delay(5);			//为了出现死锁的延时设置
          semaphore.P(1);		//拿起右筷子
          delay(5);			//吃饭延时
          printf("  *  Socrates: I'm full and it's time to think\n");	//吃完饭提示
          semaphore.V(0);		//放下右筷子
          semaphore.V(1);		//放下左筷子
       } while (1);
      }
      void Plato(void *arg)	//柏拉图
      {   
      do{	//在吃饭与思考间循环
          printf("  -  Plato: Beauty lies in the eyes of the beholder.\n");
          delay(5);//思考
          printf("  -  Plato: I'm hungry\n");
          semaphore.P(1);	//拿起左筷
          delay(5);
          semaphore.P(2);	//拿起右筷
          delay(5);
          printf("  -  Plato: I'm full and it's time to think\n");//吃完饭提示
          semaphore.V(1);	//放下右筷
          semaphore.V(2);//放下左筷
       } while (1);
      }
      void Aristotle(void *arg)	//亚里士多德
      {   
      do{
          printf("  +  Aristotle: evil is the cause of evil.\n");
          delay(5);	//思考
          printf("  +  Aristotle: I'm hungry\n");
          semaphore.P(2);	//拿起左筷
          delay(5);
          semaphore.P(3);	//拿起右筷
          delay(5);
          printf("  +  Aristotle: I'm full and it's time to think\n");
          semaphore.V(2);	//放下左筷
          semaphore.V(3);	//放下右筷
       } while (1);
      }
      void kratylos(void *arg)	//克拉底鲁
      {   
      do{
          printf("  =  kratylos: One cannot step into the same river once.\n");
          delay(5);	//思考
          printf("  =  kratylos: I'm hungry\n");
          semaphore.P(3);	//拿起左筷
          delay(5);
          semaphore.P(4);//拿起右筷
          delay(5);	//吃饭
          printf("  =  kratylos: I'm full and it's time to think\n");
          semaphore.V(3);	//放下左筷
          semaphore.V(4);	//放下右筷
       } while (1);
      }
      void Heraclitus(void *arg)	//赫拉克利特
      {   
      do{
          printf("  #  Heraclitus: There is nothing permanent except change.\n");
          delay(5);	//思考
          printf("  #  Heraclitus: I'm hungry\n");
          semaphore.P(4);	//拿起左筷
          delay(5);
          semaphore.P(0);//拿起右筷
          delay(5);
          printf("  #  Heraclitus: I'm full and it's time to think\n");
          semaphore.V(0);//放下左筷
          semaphore.V(4);	//放下右s筷
       } while (1);
      }
      ```
  
      - 每位哲学家先输出思考语句后进行思考，之后输出提示语句并且拿起两只筷子，吃完饭后输出提示信息并且放下两支筷子。
      - 为了体现理论课教材中方案会导致的死锁，我们在每拿起一支筷子时都进行延时，为的是模拟所有**哲学家同时饿了，并且同时拿起1支筷子的情况**。而上述情况将会导致死锁。
  
  - **信号量的实现**
  
      ```c++
      class Semaphore	
      {
      private:
          uint32 chopsticks[5];	//有五个临界资源数量,代表5支筷子
          List waiting;			//等待队列
          SpinLock semLock;		//自旋锁
      public:
          Semaphore();
          void initialize(uint32 counter);
          void P(int v);
          void V(int v);
      };
      ```
  
      - 类的成员基本和assignment2一致,仅是对于**临界资源的描述发生改变**,改为一个含有5个变量的数组。
      
      ```c++
      void Semaphore::initialize(uint32 counter)
      {
          for (int i=0;i<5;i++){		//将所有筷子变量初始化为1
              this->chopsticks[i] = 1;
          }
          semLock.initialize();
          waiting.initialize();
      }
      ```
      
      - 筷子变量仅有两种状态——0和1，0代表筷子被占用，1代表空闲。
      
      ```c++
      void Semaphore::P(int v)
      {
          PCB *cur = nullptr;	
          while (true)
          {
              semLock.lock();
              if (chopsticks[v] == 1)	//如果输入的编号对应的筷子未被占用
              {
                  chopsticks[v] = 0;	//哲学家取筷子
                  semLock.unlock();
                  return;
              }
              cur = programManager.running;		//否则线程阻塞
              waiting.push_back(&(cur->tagInGeneralList));
              cur->status = ProgramStatus::BLOCKED;
              semLock.unlock();
              programManager.schedule();
          }
      }
      ```
      
      - 通过输入的编号，代表某一位哲学家将要取走该编号位置的筷子。
      - 哲学家不会将筷子让出，所以当一个哲学家左右筷子有一个被占用，哲学家线程就要阻塞，直到筷子可用。
      
      ```c++
      void Semaphore::V(int v)
      {
          semLock.lock();
          chopsticks[v] = 1;	//哲学家放下筷子
          if (waiting.size())	//如果阻塞队列有成员，则唤醒
          {
              PCB *program = ListItem2PCB(waiting.front(), tagInGeneralList);
              waiting.pop_front();
              semLock.unlock();
              programManager.MESA_WakeUp(program);//唤醒线程
          }
          else
          {
              semLock.unlock();
          }
      }   
      ```
      
      - 哲学家将输入编号的筷子放回，如果阻塞队列有线程，代表有其他哲学家也要使用这一编号的筷子，则将该哲学家唤醒，使用该编号的筷子。
  
- #### 3.2 死锁解决方法：

  3.1已经说明，虽然可以使相邻两个哲学家不能同时用餐，但仍有可能发生死锁，为了彻底解决死锁，如下方式选择其一即可：

  - ##### 奇数号哲学家只能先拿左边筷子再右边，偶数号先右后左：

    由上述代码，我们的P操作通过**输入编号**代表哲学家拿哪一个筷子。因此只要改一下PV操作顺序即可

    ```c++
    //0号哲学家苏格拉底
    semaphore.P(1);		//拿起左筷子
    semaphore.P(0);		//拿起右筷子
    //1号哲学家柏拉图
    semaphore.P(1);		//拿起右筷子
    semaphore.P(2);		//拿起左筷子
    ```

  - ##### 仅当哲学家左右筷子都可用才能拿起筷子：

    这时我们将会把PV操作整合为一个，在P操作中同时判断左右筷子可用性，才可取：

    ```c++
    void Semaphore::P(int v)
    {
        PCB *cur = nullptr;
        while (true)
        {
            semLock.lock();
             if ((chopsticks[v] == 1)&&(chopsticks[(v+1)%5] == 1))//只有当左右筷子都可用
            {   
                chopsticks[v] = 0;			//取走左筷子
                 chopsticks[(v+1)%5] = 0;	//取走右筷子
                semLock.unlock();
                return;
            }								
            cur = programManager.running;		//否则阻塞
            waiting.push_back(&(cur->tagInGeneralList));
            cur->status = ProgramStatus::BLOCKED;
            semLock.unlock();
            programManager.schedule();
        }
    }
    ```

    - P操作中的输入改为输入哲学家的编号，用于同时判断左右筷子是否可用
    - V操作中同时放下两个筷子即可。

  - ##### 添加限制：只允许8支筷子同时被拿起(同于4个哲学家同时拿筷子)：

    在信号量实现中添加新成员来计数：

    ```c++
    class Semaphore
    {
    private:
        uint num;	//用于计数
        ...
    public:
        ...
    };
    ```

    ```c++
    void Semaphore::P(int v)
    {
        PCB *cur = nullptr; 
        while (true)
        {
            semLock.lock();			
            if ((chopsticks[v] == 1)&&(num<9))//如果num小于9代表还没有4个哲学家同时拿筷子
            {   
                num++;	//计数+1 
          		chopsticks[v] = 0;	//拿筷子
                semLock.unlock();
                return;
            }	
            .....
        }
    }
    ```

  - #### 注：为了减少文件数目，以上三种实现全部放在一个文件中，img映像文件中为实现之一，其他实现在代码中均已注释，以下实验过程会给出结果截图，如要亲自验证代码正确性，请取消注释部分，重新生成img映像。

## 实验过程

### Assignment 1 代码复现题：

- #### 1.1 代码复现：

  - ##### 自旋锁：

    <img src="img/cd1-1.png">

  - ##### 信号量：

    <img src="img/cd1-2.png">

### Assignment 2 生产者-消费者问题：

- #### 2.1 Race Condition

  <img src="img/cd2-1.png">

  - 可以看到，在没有信号量机制处理前，临界区为空但是数值仍被消费者消耗，出现错误。
  - 生产者bartenderr输出顺序为：**当前临界资源数->生产并延时提示->生产结束后当前临界资源数->生产者清理杯子(延时)->再次确认当前临界资源数**。
  - 消费者customeri输出顺序为：**程序调度提示->消费成功提示**。

- #### 2.2 信号量解决方法

  - ##### MESA模型

    <img src="img/r2-211.png">

    - 红色部分代表生产者前两部分：**当前临界资源数->生产并延时提示**
    - 可以看到生产者在生产时发生线程调度，消费者准备消费临界资源，但因为临界资源为空，不消耗，所以回到生产者。
    - 因为MESA模型是等到**线程调度**时才运行唤醒的线程，因此在生产者生产**第2个临界资源的时间**中发生线程调度，这时候消耗临界资源，所以临界资源数一直是1。

    <img src="img/r2-212.png">

    - 在所有消费者都消耗完临界资源后，生产者继续生产，直到临界区满。

  - ##### Hasen 模型

    <img src="img/r2-221.png">

    - Hasen模型等待线程结束后在运行唤醒的线程，因此如上述截图：生产者线程结束后才调度消费者。

  - ##### Hoare 模型

    <img src="img/r2-231.png">

    - Hoare模型是在唤醒线程后立刻调度唤醒的线程。因此在生产者**生产完第一个临界资源后**立刻发生线程调度，**每生产一个临界资源就消费一个**，所以临界资源数一直是0。

### Assignment 3 哲学家就餐问题：

- #### 3.1 初步解决方法

  借鉴理论课堂的资料对哲学家问题提出解决方式。

  <img src="img/r3-1.png">

  - 可以看到哲学家们思考吃饭正常运作。

- #### 3.2 死锁解决方法

  - ##### 死锁复现

    <img src="img/r3-2-1.png">

    - 按照之前在**实验方案部分**在**每拿起一个筷子就进行延时**，以达到五个哲学家同时拿起一支筷子的效果，以此实现死锁。

- #### 死锁解决：

  - ##### 仅当哲学家左右筷子都可用才能拿起筷子：

    <img src="img/r3-2-2.png">

    - ##### 较3.1更新了输出提示，更便于分析，哲学家循环运行流程：说名言->"I'm hungry"->"eating"->"I'm full"->说名言->.....

    - 可以看到**只有当左右两支筷子同时可用时，哲学家才会吃饭**，输出"eating"的提示。其他哲学家都只是"I'm hungry"的提示。苏格拉底起始所以一定能直接吃饭，**柏拉图因为有一只筷子被苏格拉底拿走，所以不会拿起筷子。因此亚里士多德两只筷子都可用，可以吃饭。**同理对克拉底鲁和赫拉克利特，两只筷子被占用，所以吃不了。

    - ##### 所有哲学家至少用餐一次顺序为：苏格拉底(0)->亚里士多德(2)->克拉底鲁(3)->赫拉克利特(4)->亚里士多德-(2)>苏格拉底(0)->克拉底鲁(3)->柏拉图(1)

  - ##### 奇数号哲学家只能先拿左边筷子再右边，偶数号先右后左：

    <img src="img/r3-2-3.png">

    - 可以看到苏格拉底因为是0号，偶数位，因为是开头，所以可以就餐。**奇数号1号的柏拉图不能就餐，但是先拿走右筷子2号，偶数号2号的亚里士多德因为他的左筷子2号被柏拉图拿走，所以也不能就餐。**所以是奇数号3号克拉底鲁用餐。

    - ##### 所有哲学家至少用餐一次顺序为：苏格拉底(0)->克拉底鲁(3)->柏拉图(1)->赫拉克利特(4)->亚里士多德(2)

  - ##### 添加限制：只允许8支筷子同时被拿起(同于4个哲学家同时拿筷子)：

    <img src="img/r3-2-4.png">

    - 苏格拉底作为开头，直接用餐，**柏拉图先尝试拿起左筷，但是被苏格拉底占用，所以阻塞**。而亚里士多德可以就餐，同理对克拉底鲁和赫拉克利特，两只筷子被占用，所以吃不了。

    - ##### 所有哲学家至少用餐一次顺序为：苏格拉底(0)->亚里士多德(2)->赫拉克利特(4)->克拉底鲁(3)->柏拉图(1)

    以上三种方式任选其一都可避免死锁。

## 实验总结

本次实验通过引入竞争条件，提出解决竞争条件的简单方式——自旋锁。但是自旋锁会占用处理器，消耗大，因此再进一步引出更高级稳定的处理竞争条件的方式——信号量。实验教程使用了“消失的芝士汉堡”这一诙谐的例子，让实验更加易懂。在了解了如何处理竞争条件后，我们便可以对常见的竞争问题进行分析和处理。

首先是生产者消费者问题，也就是有限临界区问题，我们将会设置有阈值的临界区，只有在临界区未满生产者才能够生产，临界区未空消费者才能够消费，而且生产者消费者对于临界区的访问需要互斥进行。在清楚地了解生产者消费者问题的规则后，之后的编码难度就不是很大，仅是设置不同的变量作为对临界区资源数目的判断，将信号量机制中的P()V()操作进行对应的修改即可。对于阻塞线程唤醒后成为的唤醒线程的运行时机的不同，对输出结果(生产者消费者的执行顺序)也会不同。

而哲学家问题是对于可放回的临界资源循环使用的例子。因为一个临界资源始终有2个对象需要使用，而一个对象始终需要同时占有两个临界资源才能使程序继续运行，如果简单使用信号量机制来实现，会有可能导致死锁，而进一步解决死锁只要做到破坏互斥条件、破坏非抢断、破坏占有和申请、破坏循环等待这四种情况之一即可。

个人感觉这次实验的理论知识的需求会多于以往实验，这意味着实践代码的模板改动不大，只需要基于理论进行部分修改即可。所以个人认为本次实验难度最大的是使用不同方式实现自旋锁的部分，因为要考虑到指令的原子性，本次实验也许更倾向于算法的处理。

## 参考文献

[看完你就明白的锁系列之自旋锁 - 程序员cxuan - 博客园 (cnblogs.com)](https://www.cnblogs.com/cxuanBlog/p/11679883.html)

[(68条消息) 面试必备之深入理解自旋锁_JavaGuide的博客-CSDN博客_自旋锁](https://blog.csdn.net/qq_34337272/article/details/81252853)

[(68条消息) 汇编BTS指令_0F34的博客-CSDN博客_汇编bts](https://blog.csdn.net/superchickenchicken/article/details/105144490)

