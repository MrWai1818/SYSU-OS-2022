<font size =6>**操作系统原理 实验八**</font>

## 个人信息

【院系】计算机学院

【专业】计算机科学与技术

【学号】20337172

【姓名】蔡嘉威

## 实验题目

从内核态到用户态

## 实验目的

1. 理解区分内核态和用户态的必要性。
2. 编写一个系统调用，并分析系统调用前后栈的变化。
3. 掌握用户态与内核态之间切换的过程。
4. 掌握进程创建的过程。
5. 分析fork/exit/wait指令执行过程。
6. 学习如何通过分页机制隔离进程间的地址空间。

## 实验要求

1. 编写一个系统调用。
2. 掌握用户态与内核态之间切换的过程。
3. 实现fork/exit/wait指令。
3. 实现进程之间的隔离。
4. 撰写实验报告。

##  实验方案

### 调用段与特权级

------

CPU中有0、1、2、3这4个特权级，数字越大特权级越小。较为核心的代码和数据将被放在特权级较高的层级中。处理器将用这样的机制来避免低特权级的任务在不被允许的情况下访问位于高特权级的段中。如果处理器检测到一个访问请求是不合法的，将会产生常规保护错误。

- **CPL：**当前进程的权限级别(Current Privilege Level)。是当前正在执行的代码所在的段的特权级，存在于cs寄存器的低两位。
-  **RPL：**进程对段访问的请求权限(Request Privilege Level)。对于段选择子而言的，每个段选择子有自己的RPL。RPL对每个段来说不是固定的，两次访问同一段时的RPL可以不同。RPL存在段选择子的低两位中。
- **DPL：**规定访问该段的权限级别(Descriptor Privilege Level)。存储在存储在门(中断描述符IDT)或者段描述符(GDT)的DPL字段中，每个段的DPL固定。

而在访问对应段的资源前，CPU需要对上述三个指标进行检查，也就是特权级检查。

- 对于数据段和栈段要求DPL≥max{CPL,RPL}：即**当前进程特权级或进程对段申请的权限的等级**要高于**将访问段的特权级**。
- 对于**一致性代码段**，即可被低特权级访问，被访问后特权级不会改变的代码仅需要CPL≥DPL，即**当前进程特权级**高于**将访问段的特权级**。
- 对于**非一致性代码段**，即只允许同级间访问， 绝对禁止不同级访问的代码需要CPL=DPL，即**当前进程特权级**与**将访问段的特权级**一致，这保证同级访问。以及CPL≥RPL，即**进程对段申请的权限**的等级小于**当前进程特权级**，这保证不同级间不能访问。

因为本次实验仅涉及用户态和内核态的转换，所以我们只需要考虑0、3两个特权级。

- 从低特权级向高特权级转移时，可以通过中断或调用来实现。而本次实验主要只利用中断。
- 从高特权级向低特权级转移时，仅能通过中断返回和系统调用实现。



### 任务状态段TSS(Task State Segment)

------

CPU在不同的特权级下会使用不同的栈，而这些栈需要在特权值转移时被保存，以便来来回转移使用。而这些栈指针与段选择子将会保存在TTS中。TSS存在TR寄存器中。TSS中只会保存特权级0，1，2的段选择子和栈指针，对应保存在esp0/esp1/esp2中。

TSS可以在任务被切换时暂存任务，每个任务都有对应的TSS。但本次实验会将进程状态保存于PCB，所以不使用上述功能。将自己设置TSS。



### Assignment 1 系统调用

------

#### 系统调用的生成

用户态进程特权级为3，但有时候仍需要访问内核中的函数，所以需要借助系统调用从用户态进入内核态，完成所需操作之后再返回。在往期实验中，我们将各种段描述符的DPL都设置为0

```asm
;创建描述符，这是一个数据段，对应0~4GB的线性地址空间
mov dword [GDT_START_ADDRESS+0x08],0x0000ffff    ; 基地址为0，段界限为0xFFFFF
mov dword [GDT_START_ADDRESS+0x0c],0x00cf9200    ; 粒度为4KB，存储器段描述符 
;建立保护模式下的堆栈段描述符      
mov dword [GDT_START_ADDRESS+0x10],0x00000000    ; 基地址为0x00000000，界限0x0 
mov dword [GDT_START_ADDRESS+0x14],0x00409600    ; 粒度为1个字节
;创建保护模式下平坦模式代码段描述符
mov dword [GDT_START_ADDRESS+0x20],0x0000ffff    ; 基地址为0，段界限为0xFFFFF
mov dword [GDT_START_ADDRESS+0x24],0x00cf9800    ; 粒度为4kb，代码段描述符 
```

之后实现的进程运行时CPL=3，所以需要经过系统调用才能访问以前设置DPL=0的段。

当进行系统调用时，系统调用的参数通过5个寄存器来传递，所以系统调用参数不可超过5个。使用寄存器传参而不是栈的原因在于，**不同特权级有不同的栈存在**，如果将系统调用参数存在当前进程栈上，特权级转换后栈换到对应特权级的新栈上，新栈上并没有先前存的参数，这导致系统调用失败。

因为经由寄存器赋值，使用汇编代码实现：

```asm
；int asm_system_call(int index, int first = 0, int second = 0, int third = 0, int forth = 0, int fifth = 0)
asm_system_call:
    push ebp
    mov ebp, esp

    push ebx
    push ecx
    push edx
    push esi
    push edi
	;调入参数
    mov eax, [ebp + 2 * 4]
    mov ebx, [ebp + 3 * 4]
    mov ecx, [ebp + 4 * 4]
    mov edx, [ebp + 5 * 4]
    mov esi, [ebp + 6 * 4]
    mov edi, [ebp + 7 * 4]
	;调用0x80号中断，选择系统调用函数
    int 0x80
	;恢复现场
    pop edi
    pop esi
    pop edx
    pop ecx
    pop ebx
    pop ebp

    ret

```

- 第一个参数eax为系统调用号。
- Linux系统中中断向量号0x80用于处理系统调用。本实验为向其看齐也设置为0x80号。该中断会根据eax的系统调用号选择系统调用函数进行处理。

系统调用也是函数，因此可以通过设置**系统调用类**对系统调用进行统一管理。

```c++
class SystemService
{
public:
    SystemService();
    void initialize();
    // 设置系统调用，index=系统调用号，function=处理第index个系统调用函数的地址
    bool setSystemCall(int index, int function);
};
```

以下为具体实现：

```c++
int system_call_table[MAX_SYSTEM_CALL];//系统调用表
void SystemService::initialize(){
    memset((char *)system_call_table, 0, sizeof(int) * MAX_SYSTEM_CALL);//预设系统调用表最大为256
    // 代码段选择子默认是DPL=0的平坦模式代码段选择子，DPL=3，否则用户态程序无法使用该中断描述符
    //设置0x80中断
    interruptManager.setInterruptDescriptor(0x80, (uint32)asm_system_call_handler, 3);
}
bool SystemService::setSystemCall(int index, int function){	
    //为系统调用表赋值
    system_call_table[index] = function;
    return true;
}
```

- 先前在os_constant.h设置了系统调用表最大值:

  ```c++
  #define MAX_SYSTEM_CALL 256
  ```

- 使用往期实验的中断设置函数，设置0x80号中断

  ```c++
  void InterruptManager::setInterruptDescriptor(uint32 index, uint32 address, byte DPL){
      IDT[index * 2] = (CODE_SELECTOR << 16) | (address & 0xffff);
      IDT[index * 2 + 1] = (address & 0xffff0000) | (0x1 << 15) | (DPL << 13) | (0xe << 8);
  }
  ```

  - **注意DPL设置为3，否则用户进程无法访问该中断。**

之后设置系统调用即可，首先按照实验教材设置0号系统调用，作用为返回5个参数和。在setup.cpp中实现。

```c++
// 第0个系统调用
int syscall_0(int first, int second, int third, int forth, int fifth){
    printf("systerm call 0: %d, %d, %d, %d, %d\n",
    first, second, third, forth, fifth);
    return first + second + third + forth + fifth;
}
```



#### 用户进程的诞生

- #### 内核地址扩展

  因为每个用户进程都有自己的虚拟地址空间，而内核进程仅有一个内核地址空间。实验的内核存放在0~1MB的物理地址空间中，用户内核有时需要访问内核资源，如本次实验中的时间中断。如果用户进程要使用时钟中断，会因为虚拟地址找不到物理地址0~1MB部分的处理函数。因此需要**将内核地址扩展到4GB，即与用户虚拟内存大小一致。再选取其中的3~4GB的空间作为共享内存区域。**而用户虚拟内存的共享区域已在上次实验中实现，接下来将实现内核地址空间的扩展。这一扩展将在进入内核时就开始，所以须在makefile中将0x20000参数加上0xc0000000偏移。**虽然内核的变量被提升到了3GB以上的空间，但实际上加载内核还是到 0x20000，因此需要在进入内核前打开分页机制**将开启分页机制单独地放到page.cpp，因为函数与上次实验放**在内核中**的分页机制一致，便不再赘述。

  之后在bootloader中调用函数来开启分页机制：

  ```asm
  load_kernel: 
  。。。。。。
      call open_page_mechanism
      mov eax, PAGE_DIRECTORY
      mov cr3, eax ; 放入页目录表地址
      mov eax, cr0
      or eax, 0x80000000
      mov cr0, eax           ; 置PG=1，开启分页机制
  。。。。。。
  jmp $ ; 死循环
  ```

  因为扩展了内核空间，所以对应的内核中涉及代码寻址也需要进行扩展，加上偏移量0xc0000000即可：

  ```asm
  ;内核地址转跳
  KERNEL_START_SECTOR equ 6
  KERNEL_SECTOR_COUNT equ 145
  KERNEL_START_ADDRESS equ 0x20000
  KERNEL_VIRTUAL_ADDRESS equ 0xc0020000
  ```

  ```c++
  //内核内容相关，如页表存放，存储器，显存等
  #define MEMORY_SIZE_ADDRESS 0xc0007c00
  #define BITMAP_START_ADDRESS 0xc0010000
  #define KERNEL_VIRTUAL_START 0xc0100000
  。。。。。。
  void STDIO::initialize(){
  screen = (uint8 *)0xc00b8000;
  }
  ```

  以上完成了内核地址空间的扩展以及内核与用户进程的共享。

- #### 用户进程准备

  因为用户进程有自己的虚拟地址空间，所以其用户代码/数据/栈段都需要备份在程序管理器中：

  ```c++
  class ProgramManager{
  public:
      List allPrograms; // 所有状态的线程/进程的队列
      List readyPrograms; // 处于ready(就绪态)的线程/进程的队列
      PCB *running; // 当前执行的线程
      int USER_CODE_SELECTOR; // 用户代码段选择子
      int USER_DATA_SELECTOR; // 用户数据段选择子
      int USER_STACK_SELECTOR; // 用户栈段选择子
  。。。。。。
  }
  ```

  之后将其初始化：

  ```c++
  void ProgramManager::initialize(){
      。。。。。。
      // 初始化用户代码段、数据段和栈段
      int selector;
      selector = asm_add_global_descriptor(USER_CODE_LOW, USER_CODE_HIGH);
      USER_CODE_SELECTOR = (selector << 3) | 0x3;
      selector = asm_add_global_descriptor(USER_DATA_LOW, USER_DATA_HIGH);
      USER_DATA_SELECTOR = (selector << 3) | 0x3;
      selector = asm_add_global_descriptor(USER_STACK_LOW, USER_STACK_HIGH);
      USER_STACK_SELECTOR = (selector << 3) | 0x3;
      initializeTSS();
  }
  ```

  - 需要设置用户的段描述符，而且要将其DPL设置为3，代表是用户的段描述符：

    ```c++
    #define USER_CODE_LOW 0x0000ffff
    #define USER_CODE_HIGH 0x00cff800
    #define USER_DATA_LOW 0x0000ffff
    #define USER_DATA_HIGH 0x00cff200
    #define USER_STACK_LOW 0x00000000
    #define USER_STACK_HIGH 0x0040f600
    ```

  - 之后借助函数asm_add_global_descriptor将设置好的段描述符送入GDT中：

    ```asm
    ; int asm_add_global_descriptor(int low, int high);
    asm_add_global_descriptor:
        push ebp
        mov ebp, esp
        push ebx
        push esi
        sgdt [ASM_GDTR]
        mov ebx, [ASM_GDTR + 2] ; GDT地址
        xor esi, esi
        mov si, word[ASM_GDTR] ; GDT界限
        add esi, 1
        mov eax, [ebp + 2 * 4] ; low
        mov dword [ebx + esi], eax
        mov eax, [ebp + 3 * 4] ; high
        mov dword [ebx + esi + 4], eax
        mov eax, esi
        shr eax, 3
        add word[ASM_GDTR], 8
        lgdt [ASM_GDTR]
        pop esi
        pop ebx
        pop ebp
        ret
    ```

    - 将给定的段描述符放入GDT，更新GDTR的内容，最后返回段描述符在GDT的位置。

  先前已经提过，要自己设置TSS，不使用CPU原生的进程切换方案。原生的进程切换方案。**因为CPU规定了TSS中的内容，TSS的内容必须固定，如下：**

  ```c++
  struct TSS
  {
  public:
      int backlink;
      int esp0;
      int ss0;
      int esp1;
      int ss1;
      int esp2;
      int ss2;
      int cr3;
      int eip;
      int eflags;
      int eax;
      int ecx;
      int edx;
      int ebx;
      int esp;
      int ebp;
      int esi;
      int edi;
      int es;
      int cs;
      int ss;
      int ds;
      int fs;
      int gs;
      int ldt;
      int trace;
      int ioMap;
  };
  ```

  之后进行初始化：

  ```c++
  void ProgramManager::initializeTSS(){
      int size = sizeof(TSS);
      int address = (int)&tss;
      memset((char *)address, 0, size);
      tss.ss0 = STACK_SELECTOR; // 内核态堆栈段选择子
      int low, high, limit;
      limit = size - 1;
      low = (address << 16) | (limit & 0xff);
      // DPL = 0
      high = (address & 0xff000000) | ((address & 0x00ff0000) >> 16) | ((limit & 0xff00) << 16) |
      int selector = asm_add_global_descriptor(low, high);
      // RPL = 0
      asm_ltr(selector << 3);
      tss.ioMap = address + size;
  }
  ```

- #### 用户进程创建

  **因为进程拥有自己的虚拟地址空间，所以在PCB中需要加入自己的虚拟地址池以及对应页目录表地址。**又因为用户进程不同于内核线程，而以往实现的函数都是用于创建内核线程，所以需要重现编写相关函数：

  ```c++
  int ProgramManager::executeProcess(const char *filename, int priority){
      bool status = interruptManager.getInterruptStatus();
      interruptManager.disableInterrupt();
      // 在线程创建的基础上初步创建进程的PCB
      int pid = executeThread((ThreadFunction)load_process,
      (void *)filename, filename, priority);
      if (pid == -1){
          interruptManager.setInterruptStatus(status);
          return -1;
      }
      // 找到刚刚创建的PCB
      PCB *process = ListItem2PCB(allPrograms.back()， tagInAllList);
      // 创建进程的页目录表
      process->pageDirectoryAddress = createProcessPageDirectory();
      if (!process->pageDirectoryAddress){
          process->status = ThreadStatus::DEAD;
          interruptManager.setInterruptStatus(status);
          return -1;
      }
      // 创建进程的虚拟地址池
      bool res = createUserVirtualPool(process);
      if (!res){
          process->status = ThreadStatus::DEAD;
          interruptManager.setInterruptStatus(status);
          return -1;
      }
      interruptManager.setInterruptStatus(status);
      return pid;
  }
  ```

  - 大部分与线程创建代码一致，但进程的起始是load_process函数

  **因为用户进程有自己的虚拟地址空间，所以需要函数用于创建对应页目录表以及虚拟地址**

  ```c++
  int ProgramManager::createProcessPageDirectory(){
      // 从内核地址池中分配一页存储用户进程的页目录表
      int vaddr = memoryManager.allocatePages(AddressPoolType::KERNEL, 1);
      if (!vaddr){
          //printf("can not create page from kernel\n");
          return 0;
      }
      memset((char *)vaddr, 0, PAGE_SIZE);
      // 复制内核目录项到虚拟地址的高1GB
      int *src = (int *)(0xfffff000 + 0x300 * 4);
      int *dst = (int *)(vaddr + 0x300 * 4);
      for (int i = 0; i < 256; ++i){
     	 dst[i] = src[i];
      }
      // 用户进程页目录表的最后一项指向用户进程页目录表本身
      ((int *)vaddr)[1023] = memoryManager.vaddr2paddr(vaddr) | 0x7;
      return vaddr;
  }
  ```

  ```c++
  bool ProgramManager::createUserVirtualPool(PCB *process){
      int sourcesCount = (0xc0000000 - USER_VADDR_START) / PAGE_SIZE;
      int bitmapLength = ceil(sourcesCount, 8);
      // 计算位图所占的页数
      int pagesCount = ceil(bitmapLength, PAGE_SIZE);
      int start = memoryManager.allocatePages(AddressPoolType::KERNEL, pagesCount);
      if (!start){
      	return false;
      }
      memset((char *)start, 0, PAGE_SIZE * pagesCount);
      (process->userVirtual).initialize((char *)start, bitmapLength, USER_VADDR_START);
      return true;
  }
  ```

  - 仿照Linux做法，将用户进程的可分配的虚拟地址的定义在 USER_VADDR_START 和3GB之间。

    ```c++
    #define USER_VADDR_START 0x8048000
    ```

  - 在内核空间中为进程分配位图所需的内存后初始化虚拟池。

- #### 用户进程加载

  进程就是程序的执行体。程序是放置在磁盘上的，当我们需要运行程序时，就需要将程序加载到内存， 创建PCB和页目录表，然后调度进程执行。

  因为从高特权级到低特权级只能通过中断返回，为了方便起见，定义类 ProgramStartStack在**启动进程前存入进程需要的段选择子等信息**。(声明在process.h中)

  当进程的PCB被首次加载到处理器执行时，CPU首先会进入 load_process：

  ```c++
  void load_process(const char *filename){
      interruptManager.disableInterrupt();
      PCB *process = programManager.running;
      ProcessStartStack *interruptStack =
          (ProcessStartStack *)((int)process + PAGE_SIZE - sizeof(ProcessStartStack));
      interruptStack->edi = 0;
      interruptStack->esi = 0;
      interruptStack->ebp = 0;
      interruptStack->esp_dummy = 0;
      interruptStack->ebx = 0;
      interruptStack->edx = 0;
      interruptStack->ecx = 0;
      interruptStack->eax = 0;
      interruptStack->gs = 0;
      interruptStack->fs = programManager.USER_DATA_SELECTOR;
      interruptStack->es = programManager.USER_DATA_SELECTOR;
      interruptStack->ds = programManager.USER_DATA_SELECTOR;
  
      interruptStack->eip = (int)filename;
      interruptStack->cs = programManager.USER_CODE_SELECTOR;   // 用户模式平坦模式
      interruptStack->eflags = (0 << 12) | (1 << 9) | (1 << 1); // IOPL, IF = 1 开中断, MBS = 1 默认
  
      interruptStack->esp = memoryManager.allocatePages(AddressPoolType::USER, 1);
      if (interruptStack->esp == 0)
      {
          printf("can not build process!\n");
          process->status = ProgramStatus::DEAD;
          asm_halt();
      }
      interruptStack->esp += PAGE_SIZE;
      interruptStack->ss = programManager.USER_STACK_SELECTOR;
      asm_start_process((int)interruptStack);
  }
  ```

  - 因为未设置文件管理系统，所以函数参数filename即相关进程地址。
  - 进程是运行在特权级3下的，每一个特权级都有自己的栈。因此进程虚拟地址空间中分配一页来作为进程的特权级3栈。

  - 定义进程启动时的 eflags 结构，将IOPL设置为0，意味着进程无法直接访问IO端口，由此实现用户态程序无法自由地访问硬件。

  - **因为高特权级到低特权级只通过中断返回，所以使用中断返回来启动用户进程：**

    ```asm
    asm_start_process:
    	mov eax, dword[esp+4]
        mov esp, eax
        popad
        pop gs;
        pop fs;
        pop es;
        pop ds;
        iret
    ```

    - 起始地址送入了esp，之后更新寄存器，iret后特权级3的选择子被放入到段寄存器中，代码跳转到进程的起始处执行。

  - 用户进程和内核线程使用的是不同的代码段、数据段和栈段选择子。往期实验并没有实现对ds,fs,es,gs的保护与恢复，**不同于cs、ss，CPU会自动保护**，我们需要手动修改：

    ```asm
    asm_time_interrupt_handler:
        pushad
        push ds
        push es
        push fs
        push gs
        ; 发送EOI消息，否则下一次中断不发生
        mov al, 0x20
        out 0x20, al
        out 0xa0, al
        call c_time_interrupt_handler
        pop gs
        pop fs
        pop es
        pop ds
        popad
        iret
    ```



#### 用户进程调度

进程的调度只需要在原先的线程调度的基础**增加切换页目录表、更新TSS中特权级0的栈**相关即可。

```c++
void ProgramManager::schedule(){
    。。。。。。
    activateProgramPage(next);
    asm_switch_thread(cur, next);
    interruptManager.setInterruptStatus(status);
}
void ProgramManager::activateProgramPage(PCB *program){
    int paddr = PAGE_DIRECTORY;
    if (program->pageDirectoryAddress){
        tss.esp0 = (int)program + PAGE_SIZE;
        paddr = memoryManager.vaddr2paddr(program->pageDirectoryAddress);
    }
    asm_update_cr3(paddr);
}
```

- ##### 记得最后更新cr3中的页目录表。



#### 验证

在setup.cpp中设置创建线程，并采用系统调用：

```c++
void first_process()
{
    asm_system_call(0, 132, 324, 12, 124);
    asm_halt();
}
void first_thread(void *arg){
    printf("start process\n");
    programManager.executeProcess((const char *)first_process, 1);
    programManager.executeProcess((const char *)first_process, 1);
    programManager.executeProcess((const char *)first_process, 1);
    asm_halt();
}

```

```c++
extern "C" void setup_kernel(){
   。。。。。。
    // 设置0号系统调用
    systemService.setSystemCall(0, (int)syscall_0);
   。。。。。。
}
```

- **记得声明系统调用**



#### 更多系统调用：在用户进程中调用显存

在实验教程中，修改用户进程first_process:

```c++
void first_process(){
    printf("Hello World!");
    asm_system_call(0, 132, 324, 12, 124);
    asm_halt();
}
```

- 这一句printf("Hello World!");使得qemu窗口闪退，因为显存相关的DPL为0，意味着只有内核态才能访问，**因此要增加新的系统调用以便在用户进程使用显存打印。**

新增**系统调用1，作用为调用显存进行屏幕打印**:

```c++
int syscall_1(char* first){
    printf(" %s\n ",first);
    return 0;
}
```

在setup_kernel()中添加新系统调用声明:

```c++
systemService.setSystemCall(1, (int)syscall_1);
```

更改上述第一个进程first_process()：

```c++
void first_process(){
    asm_system_call(1,(int)"Hello World!");
    asm_system_call(0, 132, 324, 12, 124);
    asm_halt();
}
```

- **之后欲在用户进程中使用显存，将欲打印内容通过系统调用即可。**



### Assignment 2 Fork的奥秘

------

fork是一个系统调用，父进程调用fork创建一个新进程作为子进程。子进程是父进程的副本。父子进程共享代码段，但对于数据段、栈段等其他资源，父进程调用的fork函数会将这部分资源完全复制到子进程中。对于这部分资源，父子进程并不共享。之后两个进程将会从fork的返回点继续运行。父进程fork返回新创建子进程的进程ID，子进程返回0，出现错误返回负数。

#### 系统调用fork实现

因为fork于进程复制相关，所以在PCB中新增parentPid作为父进程的pid，详细代码实现位于程序管理器中：

```c++
int ProgramManager::fork(){
    bool status = interruptManager.getInterruptStatus();
    interruptManager.disableInterrupt();
    // 禁止内核线程调用
    PCB *parent = this->running;
    if (!parent->pageDirectoryAddress){
        interruptManager.setInterruptStatus(status);
        return -1;
    }
    // 创建子进程
    int pid = executeProcess("", 0);
    if (pid == -1){
        interruptManager.setInterruptStatus(status);
        return -1;
    }
    // 初始化子进程
    PCB *child = ListItem2PCB(this->allPrograms.back(), tagInAllList);
    bool flag = copyProcess(parent, child);
    if (!flag){
        child->status = ProgramStatus::DEAD;
        interruptManager.setInterruptStatus(status);
        return -1;
    }
    interruptManager.setInterruptStatus(status);
    return pid;
}
```

- fork是进程的系统调用，内核线程没有虚拟地址空间，所以依此限定只有用户进程可以调用fork。
- 子进程的生成就是创建全新的用户进程，之后通过copyProcess()复制父进程的资源。

使用copyProcess()复制父进程的资源：

```c++
bool ProgramManager::copyProcess(PCB *parent, PCB *child){
    // 复制进程0级栈
    ProcessStartStack *childpss =
        (ProcessStartStack *)((int)child + PAGE_SIZE - sizeof(ProcessStartStack));
    ProcessStartStack *parentpss =
        (ProcessStartStack *)((int)parent + PAGE_SIZE - sizeof(ProcessStartStack));
    memcpy(parentpss, childpss, sizeof(ProcessStartStack));
    // 设置子进程的返回值为0
    childpss->eax = 0;
    // 准备执行asm_switch_thread的栈的内容
    child->stack = (int *)childpss - 7;
    child->stack[0] = 0;
    child->stack[1] = 0;
    child->stack[2] = 0;
    child->stack[3] = 0;
    child->stack[4] = (int)asm_start_process;
    child->stack[5] = 0;             // asm_start_process 返回地址
    child->stack[6] = (int)childpss; // asm_start_process 参数
    // 设置子进程的PCB
    child->status = ProgramStatus::READY;
    child->parentPid = parent->pid;
    child->priority = parent->priority;
    child->ticks = parent->ticks;
    child->ticksPassedBy = parent->ticksPassedBy;
    strcpy(parent->name, child->name);
    // 复制用户虚拟地址池
    int bitmapLength = parent->userVirtual.resources.length;
    int bitmapBytes = ceil(bitmapLength, 8);
    memcpy(parent->userVirtual.resources.bitmap, child->userVirtual.resources.bitmap, bitmapBytes);
    // 从内核中分配一页作为中转页
    char *buffer = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 1);
    if (!buffer){
        child->status = ProgramStatus::DEAD;
        return false;
    }
    // 子进程页目录表物理地址
    int childPageDirPaddr = memoryManager.vaddr2paddr(child->pageDirectoryAddress);
    // 父进程页目录表物理地址
    int parentPageDirPaddr = memoryManager.vaddr2paddr(parent->pageDirectoryAddress);
    // 子进程页目录表指针(虚拟地址)
    int *childPageDir = (int *)child->pageDirectoryAddress;
    // 父进程页目录表指针(虚拟地址)
    int *parentPageDir = (int *)parent->pageDirectoryAddress;
    // 子进程页目录表初始化
    memset((void *)child->pageDirectoryAddress, 0, 768 * 4);
    // 复制页目录表
    for (int i = 0; i < 768; ++i){
        // 无对应页表
        if (!(parentPageDir[i] & 0x1)){
            continue;
        }
        // 从用户物理地址池中分配一页，作为子进程的页目录项指向的页表
        int paddr = memoryManager.allocatePhysicalPages(AddressPoolType::USER, 1);
        if (!paddr){
            child->status = ProgramStatus::DEAD;
            return false;
        }
        // 页目录项
        int pde = parentPageDir[i];
        // 构造页表的起始虚拟地址
        int *pageTableVaddr = (int *)(0xffc00000 + (i << 12));
        asm_update_cr3(childPageDirPaddr); // 进入子进程虚拟地址空间
        childPageDir[i] = (pde & 0x00000fff) | paddr;
        memset(pageTableVaddr, 0, PAGE_SIZE);
        asm_update_cr3(parentPageDirPaddr); // 回到父进程虚拟地址空间
    }
    // 复制页表和物理页
    for (int i = 0; i < 768; ++i){
        // 无对应页表
        if (!(parentPageDir[i] & 0x1)){
            continue;
        }
        // 计算页表的虚拟地址
        int *pageTableVaddr = (int *)(0xffc00000 + (i << 12));
        // 复制物理页
        for (int j = 0; j < 1024; ++j){
            // 无对应物理页
            if (!(pageTableVaddr[j] & 0x1)){
                continue;
            }
            // 从用户物理地址池中分配一页，作为子进程的页表项指向的物理页
            int paddr = memoryManager.allocatePhysicalPages(AddressPoolType::USER, 1);
            if (!paddr){
                child->status = ProgramStatus::DEAD;
                return false;
            }
            // 构造物理页的起始虚拟地址
            void *pageVaddr = (void *)((i << 22) + (j << 12));
            // 页表项
            int pte = pageTableVaddr[j];
            // 复制出父进程物理页的内容到中转页
            memcpy(pageVaddr, buffer, PAGE_SIZE);
            asm_update_cr3(childPageDirPaddr); // 进入子进程虚拟地址空间
            pageTableVaddr[j] = (pte & 0x00000fff) | paddr;
            // 从中转页中复制到子进程的物理页
            memcpy(buffer, pageVaddr, PAGE_SIZE);
            asm_update_cr3(parentPageDirPaddr); // 回到父进程虚拟地址空间
        }
    }
    // 归还从内核分配的中转页
    memoryManager.releasePages(AddressPoolType::KERNEL, (int)buffer, 1);
    return true;
}
```

- 首先复制父进程的0级栈给子进程
- 为了使子进程返回0，在最后将eax设为0。
- 接着初始化子进程的0级栈，为了使 asm_switch_thread 跳转到 asm_start_proces。
- 之后复制父进程的PCB以及管理虚拟地址池的bitmap。
- 设置中转页buffer用于**之后传递父进程的物理页内容**。
- 创建完中转页后，先复制父进程的页目录表到子进程：在**父进程页目录项**有指向的页表的前提下，从**用户物理空间**中分配一个物理页作页目录项指向页表。
- 之后进入子进程虚拟地址空间更新子进程的页目录表，**因为增加了子进程的页目录项，父进程的页目录表也要更新。**
- 之后根据更新的页目录表复制父进程的页表到子进程中，在页表项指向的页表存在前提下，从用户物理地址池中分配一页，作为子进程的页表项指向的物理页。
  - 因为父子进程代码段一致，所以相同的虚拟地址中的页目录项指向的**页表所在的物理地址是一样的**，为了复制父进程的物理页表，需要使用到**先前设置的中转页buffer**。

- 最后归还中转页。



#### 四个问题：

- #### 除代码段外，进程包含的资源

  上文已有提及，本次实验中进程包含的资源有：**0特权级栈，PCB、虚拟地址池、页目录表、页表及其指向的物理页**。



- #### 父子进程代码段共享

  因为fork实现中，子进程就是创建全新的进程后复制父进程资源，而两者之间的**代码段都是来源于内核**，而内核代码又作为共享代码段。因此父子进程代码段共享。



- #### 父子进程从相同返回点执行

  除代码段外，在我们的操作系统中，进程包含0特权级栈、PCB、虚拟地址池、页目录表、页表及其指向的物理页，这些都需要复制到子进程中。在进行系统调用fork后，CPU将父进程0特权级的栈送入esp，esp再由activateProgramPage送入TSS，之后CPU将中断发生前的ss，esp，eflags、cs、eip送入栈。之后进行系统调用处理。**子进程需要的便是系统调用处理前的栈**，因此父进程0特权栈的起始地址便是进程PCB所在页的顶部减去一个ProgramStartStack的大小，**实际上就是把在中断的那一刻保存的寄存器的内容复制到子进程的0特权级栈中**。

  父进程此前停在了asm_system_call_handler返回后，并将保存返回点的eip存在0特征级的栈中，之后需要调用asm_start_process启动子进程，在启动完 asm_start_process后，子进程就会从父进程的结束地址开始与父进程同步。而之后将复制父进程3特权级的栈到子进程中，父进程3特权级的栈中存了父进程在系统调用后返回点，所以父子进程可以从相同返回点执行。



- #### 资源在进程之间的复制

  由上述copyProcess()，让子进程PCB等各种资源的内容与父进程各种资源值相等即可。对于物理页内容，因为父子进程的代码段一致，所以虚拟地址对应的物理页是一样的，但是为了复制物理页内容，需要设置中转页buffer。



### Assignment 3 哼哈二将 wait & exit

------

exit当进程或线程的主动结束时调用。在进程或线程调用exit后，我们会释放其占用的所有资源，只保留PCB。此时线程或进程的状态被标记为DEAD 。进程或线程的PCB由专门的线程或进程来回收，在PCB被回收之前的DEAD 线程或进程也被称为僵尸线程或僵尸进程。

#### exit的实现

设置的wait函数声明如下：

```c++
void exit(int ret);
void syscall_exit(int ret);
```

- ret为返回值，用于判断该进程或线程是否已经退出，如果值不为负数。则代表该进程或线程可以回收。

- 因为exit后线程或进程仅剩下PCB，所以对应ret存放在PCB中。

exit实现如下：

```c++
void ProgramManager::exit(int ret){
    interruptManager.disableInterrupt();
    PCB *program = this->running;
    program->retValue = ret;	//设置PCB返回值
    program->status = ProgramStatus::DEAD;//杀死进程
    int *pageDir, *page;
    int paddr;
    if (program->pageDirectoryAddress){
        pageDir = (int *)program->pageDirectoryAddress;
        for (int i = 0; i < 768; ++i){
            if (!(pageDir[i] & 0x1)){
                continue;
            }
            page = (int *)(0xffc00000 + (i << 12));
            for (int j = 0; j < 1024; ++j) {
                if (!(page[j] & 0x1)){
                    continue;
                }
                paddr = memoryManager.vaddr2paddr((i << 22) + (j << 12));
                memoryManager.releasePhysicalPages(AddressPoolType::USER, paddr, 1);
            }
            paddr = memoryManager.vaddr2paddr((int)page);
            memoryManager.releasePhysicalPages(AddressPoolType::USER, paddr, 1);
        }
        memoryManager.releasePages(AddressPoolType::KERNEL, (int)pageDir, 1);
        int bitmapBytes = ceil(program->userVirtual.resources.length, 8);
        int bitmapPages = ceil(bitmapBytes, PAGE_SIZE);
        memoryManager.releasePages(AddressPoolType::KERNEL, (int)program->userVirtual.resources.bitmap, bitmapPages);
    }
    schedule();
}
```

- 先将PCB的各种状态设置为死去线程的状态，如果PCB标识是进程，则释放所占用物理页、页表等资源，如果是线程则直接进行线程调度。

修改load_process可以让3特权级的用户进程在函数退出后主动转跳到exit。

```c++
void load_process(const char *filename){
    。。。。。。
    interruptStack->esp = memoryManager.allocatePages(AddressPoolType::USER, 1);
    if (interruptStack->esp == 0)
    {
    printf("can not build process!\n");
    process->status = ProgramStatus::DEAD;
    asm_halt();
    }
    interruptStack->esp += PAGE_SIZE;
    // 设置进程返回地址
    int *userStack = (int *)interruptStack->esp;
    userStack -= 3;
    userStack[0] = (int)exit;
    userStack[1] = 0;
    userStack[2] = 0;
    interruptStack->esp = (int)userStack;
   。。。。。。
}
```

- 在进程的3特权级栈中的栈顶处 userStack[0] 放入exit的地址，然后CPU会认 为 userStack[1] 是exit的返回地址， userStack[2] 是exit的参数。



#### wait的实现

因为上述提及，在调用了exit后，线程会前往program_exit从而达到线程PCB的回收。而**进程调用exit仅会回收相关资源，而其PCB并不会回收，因此要实现wait，来回收进程的PCB。**以下是声明及实现：

```c++
int wait(int *retval);
int syscall_wait(int *retval);
```

```c++
int ProgramManager::wait(int *retval){
    PCB *child;
    ListItem *item;
    bool interrupt, flag;
    while (true){
        interrupt = interruptManager.getInterruptStatus();
        interruptManager.disableInterrupt();
        item = this->allPrograms.head.next;
        // 查找子进程
        flag = true;
        while (item){
            child = ListItem2PCB(item, tagInAllList);
            if (child->parentPid == this->running->pid){
                flag = false;
                if (child->status == ProgramStatus::DEAD){
                    break;
                }
            }
            item = item->next;
        }
        if (item) // 找到一个可返回的子进程{
            if (retval){
                *retval = child->retValue;
            }
            int pid = child->pid;
            releasePCB(child);
            interruptManager.setInterruptStatus(interrupt);
            return pid;
        }else{
            if (flag) // 子进程已经返回{   
                interruptManager.setInterruptStatus(interrupt);
                return -1;
            }else // 存在子进程，但子进程的状态不是DEAD{
                interruptManager.setInterruptStatus(interrupt);
                schedule();
            }
        }
    }
}
```

- 根据PCB中的返回值retval，找到对应PCB进行回收，返回值为PCB的pid。

- 进程的PCB是由父进程进行回收的，如果 retval==nullptr ，则说明父进程不关心子进程的返回值。如果没有子进程，则返回 -1 。如果存在子进程但子进程的状态不是 DEAD ，则父进程会被阻塞，即wait不会返回直到子进程结束。

- 当 retval 不为 nullptr 时，根据 retval得到子进程的pid，以此调用 releasePCB 来回收子进程的PCB，最后返回子进程的pid。



#### 僵尸进程复现

子进程退出了，但是父进程没有用wait去获取子进程的状态信息，那么子进程的进程描述符仍然保存在系统中，这种进程称为僵尸进程。**实验教程中的代码并不会导致僵尸进程的产生，因此以下首先展示僵尸进程的复现**

```c++
void third_process(){
    int pid = fork();
    int retval;
    if (pid) {
        uint32 tmp = 0xfffffff;	//延时，使第一个子进程结束后，在生成第二个子进程
            while (tmp)
                --tmp;
        pid = fork();
        if (pid) {
            //父进程打印程序管理器中所有进程或线程
            printf("all child process exit,rest programs: %d\n", programManager.allPrograms.size());
            ListItem *item = programManager.allPrograms.front();
            while(item){
                PCB *temp = ListItem2PCB(item,tagInAllList);
                printf("rest pid: %d ,pageDirectoryAddress :%x\n",temp->pid,temp->pageDirectoryAddress); 
                item =item ->next;
            }   
            }
            asm_halt();
        }else{	//第二个子进程
            printf("second son exit, pid: %d ,father:%d,pageDirectoryAddress :%x\n", programManager.running->pid,programManager.running->parentPid,programManager.running->pageDirectoryAddress);    
            exit(123934);
        }
    }else{
    //第一个子进程
        printf("first son exit, pid: %d,father :%d,pageDirectoryAddress :%x\n", programManager.running->pid,programManager.running->parentPid,programManager.running->pageDirectoryAddress);
        exit(-123);
    }
```

- 首先为父进程fork()一个子进程，之后直到第一个子进程结束并且调用exit()后，再fork()第二个子进程。
- 为了模拟僵尸进程的产生，父进程不设置wait。
- 按照代码，第一个子进程结束后会回到父进程，父进程打印结束后再执行第二个子进程。理论上屏幕打印会按照所述顺序，**先打印第一个子进程的信息，之后按照父进程，打印程序管理器中所剩的所有线程或进程，最后打印第二个子进程的内容。**
- **具体分析将在实验过程中阐述。**



#### 僵尸进程问题解决

- #### 方法一、实验教程：父进程通过wait函数循环等待子进程结束

  ```c++
  void third_process(){
     。。。。。。
          if (pid) {
              //循环等待子进程结束
              while ((pid = wait(&retval)) != -1) {
                   printf("wait for a child process, pid: %d, return value: %d\n", pid, retval);
              }
              printf("wait for a child process, pid: %d, return value: %d\n", pid, retval);
              printf("all child process exit,rest programs: %d\n", programManager.allPrograms.size());
              ListItem *item = programManager.allPrograms.front();
              while(item){
                  PCB *temp = ListItem2PCB(item,tagInAllList);
                  printf("rest pid: %d ,pageDirectoryAddress :%x\n",temp->pid,temp->pageDirectoryAddress);    
                  item =item ->next;
              }
          }
         。。。。。。。
  }
  ```

  - 根据wait的特性使用while循环，**直到所有子进程执行完毕，父进程才能工作。**

  - #### 缺点：如果存在大量子进程，会导致父进程一致挂起。

- #### 方法二、使用信号

  在子进程结束后，给父进程发送信号，提醒父进程进行wait操作回收PCB：

  ```c++
  int s = 0 ;	//信号 
  int c = 0 ; //子进程数
  void third_process(){
      int pid = fork();
      int retval;
      if (pid) {
          uint32 tmp = 0xfffffff;
              while (tmp)
                  --tmp;
          pid = fork();
          if (pid) {
              while (1){
                 if(s==1){	//接收到子进程消息，进行回收
                      pid = wait(&retval);
                      printf("wait for a child process, pid: %d, return value: %d\n", pid, retval);
                      s=0;
                      printf("all child process exit,rest programs: %d\n", programManager.allPrograms.size());
                      ListItem *item = programManager.allPrograms.front();
                      while(item){
                          PCB *temp = ListItem2PCB(item,tagInAllList);
                          printf("rest pid: %d ,pageDirectoryAddress :%x\n",temp->pid,temp->pageDirectoryAddress);    
                          item =item ->next;
                      }
              	}
                  if(c==2){	//子进程全部结束，父进程也结束，退出
                      break;
                  }
              }
              //asm_halt();
          }else{
              printf("second son exit, pid: %d ,father:%d,pageDirectoryAddress :%x\n", programManager.running->pid,programManager.running->parentPid,programManager.running->pageDirectoryAddress);    
              s = 1;
              c++;
              exit(123934);
          }
      }else{
          printf("first son exit, pid: %d,father :%d,pageDirectoryAddress :%x\n", programManager.running->pid,programManager.running->parentPid,programManager.running->pageDirectoryAddress);
          s=1;	//子进程结束标记信号提醒
          c++;
          exit(-123);       
      }
  }
  ```

  - 只有在接受到子进程的消息(s==1)时，父进程才进行wait操作。如果没有则进行父进程工作。
  - 只有在所有子进程结束后，父进程才能退出。



### 思考题

#### findProgramByPid的实现

- #### 方法一、对进程队列进行查找

  ```c++
  PCB * ProgramManager:: findProgramByPid(int pid){
       ListItem *item = allPrograms.front();
       while(item){
           PCB *temp = ListItem2PCB(item,tagInAllList);
           if(temp->pid == pid ){
               return temp;
           }
           item = item->next;
       }
  }
  ```

  - 对列表中所有进程进行遍历，提取出PCB后再对pid进行判断。

- #### 方法二、使用pid进行计算

  ```c++
  PCB * ProgramManager:: findProgramByPid(int pid){
      return (PCB*)(pid*4096+(int)PCB_SET);
  }
  ```

  - 代码简洁许多，且寻址更迅速。

**因为该改动没必要特地打印内容来展示正确性，便没有截图展示。**



## 实验过程

### Assignment 1 系统调用

------

#### 实验正确性

<img src='img/r1.png'>

- 代码中设置了3个功能同样的用户进程first_process，可以看到先调用系统调用1打印了helloworld后，调用系统调用0输出输入的5个参数。



#### 系统调用前后的寄存器变化

因为第一个使用的系统调用仅用到5个参数中的1个，参考性较弱。因为篇幅有限，便**直接分析系统调用0：**

<img src='img/r1-1.png'>

- 调用系统调用0前的寄存器情况

<img src='img/r1-2.png'>

- 以上是进行0x80中断前的寄存器。
- 根据代码，寄存器ecx、edx、ebx、esi、edi为输入的5个参数分别为324、12、132、124、0，eax为系统调用编号0。

<img src='img/r1-3.png'>

- 处理中断后要手动维护ds、es、fs、gs寄存器。
- 其中经过**TSS的载入，将特权级0进程的PCB栈导入esp中，堆栈基址0x10导入ss**。

<img src='img/r1-4.png'>

- 调用系统调用函数后，**eax值为系统调用实现的返回值，即5个输入参数的和592**
- 维护ds、es、fs、gs寄存器之后，**TSS还回先前特权级3栈导入esp中，栈基址ss为59，与第一张图系统调用前一致**。

综上，**TSS的作用为在特权级转移时的提供栈段选择子和栈指针**。



### Assignment 2 Fork的奥秘

------

#### 实验正确性

<img src='img/r2.png'>

- 父进程fork返回为子进程pid2，子进程fork返回0 。



#### fork前后的寄存器变化

<img src='img/r2-1.png'>

- **父进程首次系统调用**fork前的寄存器

<img src='img/r2-3.png'>

- 进入fork函数

<img src='img/r2-4.png'>

- 创建并初始化子进程

<img src='img/r2-5.png'>

- 开始复制父进程资源到子进程
- 可以看到父子进程的PCB都已经创建

<img src='img/r2-6.png'>

- 复制父进程的0特权级栈到子进程

<img src='img/r2-7.png'>

- 准备子进程系统调用的参数

<img src='img/r2-8.png'>

- 复制用户虚拟池

<img src='img/r2-9.png'>

- 复制父进程对应的页目录表到子进程

<img src='img/r2-10.png'>

- 复制父进程对应的物理页到子进程

<img src='img/r2-11.png'>

- 父进程fork返回后的系统调用

<img src='img/r2-12.png'>

- 子进程fork返回后的系统调用

**可以看到，子进程和父进程在返回之后的eip值相等，即两者的返回点一致。**

回看第二张图的eax寄存器，父进程的返回值早已计算号，为2：

<img src='img/r2-13.png'>

**本来子进程的返回值应当与父进程一致**，但因为在copyprocess中：

```c++
// 设置子进程的返回值为0
    childpss->eax = 0;
```

**所以子进程的返回值为0 。**



### Assignment 3 哼哈二将 wait & exit

------

#### 僵尸进程复现

<img src='img/r3.png'>

可以看到**父进程第一个子进程已经exit，但是其PCB未回收，所以出现了第一个子进程和第二个子进程的页目录表地址一致的情况。**因为第一个子进程资源回收了，第二个子进程便使用了空出来的资源。



#### 僵尸进程解决验证

- #### 方法一

<img src='img/r31.png'>

- - 因为代码设置不exit父进程，所以在父进程结束后，**剩余进程数为2，一个是first_thread初始线程，一个是父进程。**



- #### 方法二

<img src='img/r32.png'>

- - 因为代码设置不exit父进程，所以在父进程结束后，**剩余进程数为2，一个是first_thread初始线程，一个是父进程。**
  - 第一个子进程结束后，发送信号让父进程wait，所以当时剩余进程有3个，first_thread、父进程和第二个子进程。

#### exit隐式执行

进程能够隐式执行源于load_process中下述代码：

```c++
// 设置进程返回地址
int *userStack = (int *)interruptStack->esp;
userStack -= 3;
userStack[0] = (int)exit;
userStack[1] = 0;
userStack[2] = 0;
interruptStack->esp = (int)userStack;
```

- 在进程的3特权级栈中的栈顶处 userStack[0] 放入exit的地址。之后在进程结束后就会调用该栈的内容函数。

- 而 userStack[2] 为exit的参数，寄存器中如下变化：

  <img src='img/r311.png'>

  - **因为代码设置为0，图中ebx寄存器的值为0，即默认exit返回值是0。**以下去掉原代码中exit部分进行：

  - <img src='img/r312.png'>

    - **去掉exit，让进程自动调用隐式exit**

      <img src='img/r313.png'>

      **输入n进行调试，从s=1进入到exit的系统调用**

      <img src='img/r314.png'>

      因为隐式调用中默认ret值为0，所以**寄存器edx即exit()的参数值也为0.**

      <img src='img/r315.png'>

      **所以隐式调用exit返回值为0 。**

​		

## 实验总结

本次实验主要是了解到内核态到用户态的转变，就如同引言所说“不懂 Unix 的人注定最终还要重复发明一个蹩脚的 Unix。”本次实验教程主要实现还是往Unix靠近，毕竟中断描述符都定义为int 0x80 。虽然在往期实验已经实现物理和虚拟内存空间分配和线程创建。但是以往实验的进程都是在内核区域实现，用户区域并未涉及，而上次实验所划分一半的用户空间都没有使用过。而这次实验教程便是对用户进程的实现教学。

可以认为内核进程可以直接使用往期实验的进程来创建，而用户进程因为拥有自己独立的虚拟内存空间，所以需要新的代码实现。除了分配给用户进程的虚拟内存空间，还有进行页表与页目录表的更新，这才算建立好用户进程。

操作系统区分用户进程与内核进程的目的是为了保护计算机，防止进程不该访问的内容被访问或被攻击。而用户态与内核态靠特权级区分，CPU也将对应不同特权级给与不同的操作。因此我们需要通过设定中断来实现中断，以此达到特权级转换的效果。而在上述创建的用户进程中，当我们需要访问到内核代码即特权级更高的部分时，就需要借助特权级转移来实现。而这一特权级转移的中转站就是系统调用，即改变特权级访问内核后还能将特权级换回来的函数。

余下fork/wait/exit便是对于用户进程复制、删除、回收的衍生。这些在理解用户进程的创建后并不是什么难点。

本次实验大部分通过教程以及查阅资料就可以理解。关于思考题对于PCB的寻址，本来只想到遍历列表，还是经由TA提醒才想起可以通过pid的来由：地址偏移，来直接获取PCB。



## 参考文献

[TSS(任务状态段) - wanghetao - 博客园 (cnblogs.com)](https://www.cnblogs.com/wanghetao/archive/2011/10/28/2228130.html)

[(69条消息) DPL,RPL,CPL 之间的联系和区别_better0332的博客-CSDN博客_dpl是什么](https://blog.csdn.net/better0332/article/details/3416749)

[操作系统篇-调用门与特权级（CPL、DPL和RPL） - 卫卐 - 博客园 (cnblogs.com)](https://www.cnblogs.com/chenwb89/p/operating_system_004.html)

[(69条消息) 孤儿进程和僵尸进程的区别_人生匆匆的博客-CSDN博客_孤儿进程和僵尸进程的区别](https://blog.csdn.net/a13568hki/article/details/103851388)
