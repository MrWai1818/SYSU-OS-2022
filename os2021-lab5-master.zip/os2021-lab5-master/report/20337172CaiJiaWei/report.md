<font size =6>**操作系统原理 实验五**</font>

## 个人信息


【院系】计算机学院

【专业】计算机科学与技术

【学号】20337172

【姓名】蔡嘉威

## 实验题目

内核线程

## 实验目的

1. 学习C语言的可变参数机制的实现方法，实现可变参数机制，以及实现一个较为简单的printf函数。
2. 实现内核线程的实现。
3. 重点理解`asm_switch_thread`是如何实现线程切换的，体会操作系统实现并发执行的原理。
4. 实现基于时钟中断的时间片轮转(RR)调度算法，并实现一个线程调度算法。

## 实验要求

1. 实现了可变参数机制及printf函数。
2. 自行实现PCB，实现线程。
3. 了解线程调度，并实现一个调度算法。
4. 撰写实验报告。

## 实验方案

### Assignment 1 printf的实现:

- 为了使输出格式化，更具便利性，学习C语言的可变参数机制。借助<stdarg.h>库文件的内容。其中可变参数的输出实现，便是将不同类型(即可变类型)的变量**遵循C/C++函数调用规则**放入同一个栈中，再通过设置的va_list指针以及库中的va_start(<u>初始化指针并使其指向可变参数列表的起始位置</u>)、va_end(<u>清空列表指针ap</u>)等函数对栈中的数据进行调用，**其中栈中数据不随机访问，欲访问位于栈中间数据必须从头开始进行遍历**。其中可变参数列表起始地址安排遵循如下：
	
	> 可变参数列表的起始地址 = 固定参数列表的最后一个参数的地址 + 这个参数的大小

  之后便可以实现自己的可变参数函数，**因为保护模式下栈的数据push和pop变量都是4字节，所以各种变量数据的保存都是以4字节方式在栈中对齐保存**，所以栈的地址偏移是以4的倍数运算的。

- 因为前几次实验已经大体实现了屏幕打印的环境，接下来便可按照实验教程的步骤编写自己的printf函数并于内核启动阶段调用。

  ><img src="img/cd1-1.png">

  - printf的实现：如同注释所提及，设置buffer作为缓冲区，如果fmt(输入的可变参数列表)**所转换的字符串长度超过32bit**，即超过保护模式下寄存器存储数据的格式大小，则**忽略溢出部分**直接输出。如果字符串大小没超过则缓冲区清空，**直接输出字符串**。

- 之后对fmt中的内容进行判断，若出现**%**则**对可变参数的参数类型进行判断，并转换成字符串后填充**。
  
  ><img src="img/cd1-2.png">
  
  - 按照教程中的对可变参数类型的判定设置为单独输出“%”、输出字符、输出字符串、输出十进制以及十六进制整数。其中输出整数需要将数字转换成字符串，如下：
  
    ><img src="img/cd1-4.png">

  - 将输入的整数对于响应进制**取余数作为将转换为字符的部分**，再将整数本身**整除于进制**得到的全新整数即是接下来要**反复进行上述操作的部分**，直到整数整除0的结果为0，代表字符转换完全结束。**在全部转换完后需要将字符串倒序才是正确顺序**。
  
    ><img src="img/cd1-5.png">
  
  - 该函数即**将每一步转换fmt所产生的字符串的逐个加入buffer缓冲区**,若放入的字符串长度超过缓冲区长度则直接输出,否则则将缓冲区清空. 

- 因为前几次实验已经将屏幕打印所需的环境生成,我们仅需要在函数打印函数中添加所需**额外操作的判断即可**。

  ><img src="img/cd1-6.png">

    - 如代码中，若fmt转化的字符串出现**\n**则代表需要换行，则我们直接在屏幕打印时**对光标临时处理**即可。\t同理。

###  Assignment 1**新增内容：**

#### 1.增加制表符\t:

>相关代码以上已经展示，便不再赘述

#### 2.增加对浮点数的输出打印：

><img src="img/cd1-7.png">

- 于判断%后类型新增%f用于判断是否为浮点数，因为浮点数在汇编中**占据8字节，64位，其中高32位存小数点前数字，低32位存小数点后数字**。我们在对指向fmt的指针ap修改也应该改成**8字节大小**。之后调用自己实现的**ftos函数得到转换后的字符串**，之后放入缓冲区进行判断以及进行后续操作。

```c++
//为了输出浮点数准备的数字转换到字符串
int pint(char *n,int d,int start){//基本与itos一致
    int t = 0,l=start;	
    while (d){
        t= d % 10;
        d/= 10;
        n[l] = t > 9 ? t - 10 + 'A' : t + '0';
        ++l;
    }
    if(!l) {
        n[start] = '0';
        n[start+1] = '\0';
        ++l;
    }
    return l;
}
void ftos(char *n,double p){//浮点数转换为字符串输出
    int tint = (int) p;		//将整数部分与小数部分分开
    int tflt = (int)(100000* (p - tint));
    int s = pint(n,tflt,0);	//分别将数字转换成字符串  
    n[s++]='.';		//再加个点
    int s1 = pint(n,tint,s++);
    for(int i = 0, j = s1 - 1; i < j; ++i, --j) {
        swap(n[i], n[j]);
    }
    n[s1++]= ' \0'; 
}
```

- **处理浮点数：先将浮点数强制类型转换int，得到浮点前的数字。再将浮点数*100000后减去浮点前的数字，由此可以得到浮点后的数字。**至此我们将浮点数分成两个整数，方便字符串转换
- **注意：因为浮点后数字只乘了100000，所以浮点数能只能精确到小数点后5位** 
- ftos函数实现：将输入的浮点数以**浮点**为区分点，分成两个整数tint和tflt，之后将两个整数通过pint函数进行转换成对应字符串，**其中pint函数**即为之前**itos的变种**，**仅仅只是减少了进制转换，以及需要返回转化成的字符串长度**。在第一部分的整数转换后在字符串后**加上浮点**后在进行第二部分字符串转换，**最后进行字符串调转即可**。

### Assignment 2 线程的实现:

- 在进行该实验前需了解到，用户线程与内核线程的区别。其中对于操作系统而言，**调度器一调度就是以生成用户线程的用户进程为单位**，亦如时间中断等调度发生只能**影响进程一级的执行流**。而且进程占据处理器的时间片有限，除去执行进程的时间外还要扣去分配给线程、维护线程表、运行调度算法的时间消耗。因为本次实验处于基础阶段，使用时间中断来使用调度器进行线程调度，所以**在内核中实现线程机制更能发挥线程的价值**。

- 因为进程有自己的地址空间，可以认为线程是共享父进程的地址空间，即**线程是进程的fork**。但因为此次实验前所积累的知识不足，未了解二级分页制度，也就不懂得进程的地址空间分配。所以此次实验使用创建线程来代替进程，其中线程实际上就是运行某个函数。

- 首先要实现存储线程信息的TCB(**存储现场信息，内容不及PCB丰富**)，但因为本次实验使用线程代替进程，所以我们需要实现PCB。

  > <img src="img/cd2-1.png">

    - 首先为线程的状态进行定义，之后定义PCB的成员变量。
  
    - 每个线程有自己独立的栈存放在自己PCB中，其中该栈的地址也作为PCB的信息之一存储于PCB。该栈stack的作用便是当线程被换下处理器时保存esp内容，当线程重新被调用后再换上，**即保存线程被调度前的最后状态，等到再次调用线程时从该状态运行。**
  
    - tagInGeneralList和tagInAllList是线程在线程队列中的标识，用于与之后的ListItem2PCB配合，寻找在线程队列中的线程。这两个列表类型的变量**便是PCB存储在线程队列中的地址，因为每个变量在PCB的地址偏移是固定的，所以在我们取得在线程队列的所需地址减去tag在PCB的偏移量就可以得到PCB的起始地址**。
  
      ```c
      #define ListItem2PCB(ADDRESS, LIST_ITEM) ((PCB *)((int)(ADDRESS) - (int)&((PCB *)0)->LIST_ITEM))
      ```
  
      其中， (int)&((PCB *)0)->LIST_ITEM) 求出的是 LIST_ITEM 这个属性在PCB中的偏移地址。
  
      - 其中ListItem是链表类型，实现均在实验教程中给出，详细代码不再赘述。
  
    - **其余PCB成员的含义在代码注释中均有体现，便不在赘述。**

- 接下来为PCB分配内存空间，我们设置每个PCB的大小为一页(4096字节)，之后再内存中设置若干个PCB大小而定空间用于存放PCB，即**一个程序的大小**。其中每个PCB的地址是连续的，所以对PCB内容进行填充的地址也是连续的：

  ><img src="img/cd2-2.png">

  - 其中所有PCB的状态都是FALSE，代表未分配内容，对于存放PCB的连续地址空间对PCB的内容进行连续的访问，判断PCB是否已经赋值。

- PCB的释放便是将指向PCB地址的值清空，并将其状态调为FALSE。

- 接下来便是创建用于承载线程的程序，即存放若干个PCB的笼统。

  ><img src="img/cd2-3.png">

    - **比起实验教程中的各个实现增加了way参数，用于表示之后线程的不同调度方式**。
    - 其中程序声明包含线程的就绪队列**多个就绪队列用于实现多级反馈队列调度算法**、所有线程的队列，当前运行的线程、线程调度函数、线程生成函数、线程分配地址空间以及线程地址空间回收函数。

- 简单的线程生成函数：

  ```c++
  int ProgramManager::executeThread(ThreadFunction function, void *parameter, const char *name, int priority)
  {
      // 关中断，防止创建线程的过程被打断
      bool status = interruptManager.getInterruptStatus();
      interruptManager.disableInterrupt();
      // 分配一页作为PCB
      PCB *thread = allocatePCB();
      if (!thread)
          return -1;
      // 初始化分配的页
      memset(thread, 0, PCB_SIZE);
  
      for (int i = 0; i < MAX_PROGRAM_NAME && name[i]; ++i)
      {
          thread->name[i] = name[i];
      }
  
      thread->status = ProgramStatus::READY;
      thread->priority = priority;		//优先级
      thread->ticks = priority * 10;	//线程时间片	
      thread->ticksPassedBy = 0;		//线程已运行时间
      thread->wait = 0;	//线程等待时间
      thread->rr = 1+ thread->wait/ thread->ticks;	//线程响应比
      thread->pid = ((int)thread - (int)PCB_SET) / PCB_SIZE;	//线程标号
      thread->which = 0;	//线程所在就绪队列
      thread->total = 0;	//线程运行所需时间
      // 线程栈
      thread->stack = (int *)((int)thread + PCB_SIZE);
      thread->stack -= 7;
      thread->stack[0] = 0;
      thread->stack[1] = 0;
      thread->stack[2] = 0;
      thread->stack[3] = 0;
      thread->stack[4] = (int)function;
      thread->stack[5] = (int)program_exit;
      thread->stack[6] = (int)parameter;
  
      allPrograms.push_back(&(thread->tagInAllList));
      readyPrograms.push_back(&(thread->tagInGeneralList));
  
      // 恢复中断
      interruptManager.setInterruptStatus(status);
  
      return thread->pid;
  }
  
  ```

  - 因为此次实验是在多线程环境下实现，我们并未实现线程互斥的工具，为了防止**线程的竞争发生**，简单地使用关中断和开中断来实现线程互斥。所以当一个线程运行下生成新线程时，我们需要关闭中断。
  - 其中线程栈有7个赋值，其中4个为0的值是要放到ebp，ebx，edi，esi中的。 thread->stack[4] 是线程执行的函数的起始地址。 thread->stack[5] 是线程的返回地址，所有的线程执行完毕后都会返回到这个地址。 thread->stack[6] 是线程的参数的地址。
  - **之后便是对PCB的各种信息进行赋值，注释均有体现，便不再赘述。**

### Assignment 3 线程调度切换的秘密

- 先前的实验将程序以及线程调度的前置条件准备完成，接下来通过修改时间中断函数来实现如example1中的时间片轮转算法：

  ```c++
  extern "C" void c_time_interrupt_handler()
  {
      PCB *cur = programManager.running;
      if (cur->ticks!=0)		//若时间片未耗尽
      {			//对线程里的成员进行改变
          cur->ticks--;
          cur->ticksPassedBy++;
          times++;
          printf("pid %d name \"%s\" priority %d waiting time %d curt : %d , where: %d\n ", cur->pid, cur->name,cur->priority,times,cur->ticks,cur->stack);
      }
      else		//否则进行线程调度
      {
          programManager.schedule();
      }
  }
  ```

- 接下来实现线程调度函数：

  ```c++
  void ProgramManager::schedule()
  {
      bool status = interruptManager.getInterruptStatus();
      interruptManager.disableInterrupt();	//关中断
  
      if (readyPrograms.size() == 0)	//若就绪队列为空，无法调度，则返回
      {
          interruptManager.setInterruptStatus(status);
          return;
      }
  
      if (running->status == ProgramStatus::RUNNING)//将运行态的线程挂起
      {
          running->status = ProgramStatus::READY;
          running->ticks = running->priority * 10;		//并重新分配时间片
          readyPrograms.push_back(&(running->tagInGeneralList));	//将挂起线程重新加入就绪队列
      }
      else if (running->status == ProgramStatus::DEAD)	//若线程结束，则回收内存
      {
          releasePCB(running);
      }
  
      ListItem *item = readyPrograms.front();		//取得就绪队列第一个线程进行调度
      PCB *next = ListItem2PCB(item, tagInGeneralList);
      PCB *cur = running;
      next->status = ProgramStatus::RUNNING;	//使它变成运行态	
      running = next;
      readyPrograms.pop_front();
  
      asm_switch_thread(cur, next);	//线程切换，通过读取stack中保存的内容完成切换
  
      interruptManager.setInterruptStatus(status);	//开中断
  }
  ```

  - 正如同注释中所提及一般，当readyProgram 为空，那么说明当前系统中只有一个线程，无法进行调度，直接返回。之后便是对线程的状态进行判断并作出对应的处理。

  - 线程调度之后便是将位于就绪队列的首个地址取出，通过上述ListItem2PCB函数提出PCB所在地址，对新的PCB进行状态调整后进行**如下线程切换**

    ```asm
    asm_switch_thread:
        push ebp
        push ebx
        push edi
        push esi
    
        mov eax, [esp + 5 * 4]
        mov [eax], esp ; 保存当前栈指针到PCB中，以便日后恢复
    
        mov eax, [esp + 6 * 4]
        mov esp, [eax] ; 此时栈已经从cur栈切换到next栈
    
        pop esi
        pop edi
        pop ebx
        pop ebp
    
        sti
        ret
    ```

  - **按照C语言要求，对寄存器 ebp，ebx，edi，esi进行保存。**将四个值保存之后栈顶的数据便是线程需要执行的函数的地址。ret发生后，将执行函数会被押入eip，从而改变代码段为将执行的函数。进入函数代码完后，栈顶数据变为**将执行函数的参数**，之后等函数运行结束，ret执行会使CPU走向栈顶的 program_exit函数的地址,即线程的函数执行完毕
  
    ```c++
    void program_exit()
    {
        PCB *thread = programManager.running;	
        thread->status = ProgramStatus::DEAD;	//改变线程为终止态
    
        if (thread->pid)		//如果线程标号不为0表示，就绪队列还有其他线程
        {
            programManager.schedule();	//便循环进行调度
        }
        else
        {//如果线程标号为0表示，就绪队列仅剩初始线程
            interruptManager.disableInterrupt();//关中断	
            printf("halt\n");
            asm_halt();
        }
    }
    ```
  
- 接下来便在内核中设置程序的初始化，并且生成、调度第一个线程到处理器上：
  
     ```c++
     // 创建第一个线程
         int pid = programManager.executeThread(first_thread, nullptr, "first thread", 1);
         if (pid == -1)
         {
             printf("can not execute thread\n");
             asm_halt();
         }
         //设置初始线程，仿造schedule的内容
         ListItem *item = programManager.readyPrograms.front();
         PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
         firstThread->status = RUNNING;//调用刚刚创建的第一个线程
         programManager.readyPrograms.pop_front();
         programManager.running = firstThread;
         asm_switch_thread(0, firstThread);//线程调度
     ```
     
     - 按照schedule函数的实现中的后半部分，**忽略前面判断当前运行线程running的步骤，直接到后面的线程切换**，其中一号线程的实现如下
     
       ```c++
       void first_thread(void *arg)
       {
           // 第1个线程不可以返回
          printf("pid %d name \"%s\" \t  priority %d waiting time %d : Hello World!\n", programManager.running->pid, programManager.running->name,programManager.running->priority,programManager.running->wait);
           if (programManager.readyPrograms.size() == 0)
           {
               programManager.executeThread(second_thread, nullptr, "second thread", 3);//生成二号线程
               programManager.executeThread(third_thread, nullptr, "third thread", 2);
           }
           asm_halt();//因为设置不返回第一个线程，所以设置死循环
       }
       ```
     
       
     
     
     - **因为实验教程设置初始线程不能终止**，所以使一号线程的其他函数内容执行完后**进入循环**，导致每次新调度线程到它本身时都是**从循环开始，从而不会退出**。

### Assignment 4 调度算法的实现

#### 一.改动内容：

- #### 1.操作系统的第一个进程往往不会返回，因为其他进程都是一般由第一个进程fork得出。但是个人认为本次实验并不是完全实现完整的操作系统内核，认为此次实验仅是实现一个程序，而一个程序应该是有结束的时刻，因此会在线程初始化时为线程提供需要运行时间total,等到total为0，将线程的状态调整为终止态。整个Assignment 4 都是以程序结束为终止条件。

  ```c++
  thread->ticks = priority * 5;
  thread->total = priority *priority * 5 ;
  ```

  其中所需运行时间为 **线程优先级平方的5倍**，**时间片的设置为优先级的5倍**。

  #### 2.为了更加直观地感受到一个线程执行的时间(时间片的流逝)，所有线程都跟一号线程一样会进行循环，直到时间片清空或者达到调度算法相应指标时才会进行线程调度。线程实现如下：

  ```c++
  void fifth_thread(void *arg) {	//打印线程相关信息后循环
          printf("pid %d name \"%s\" \t  priority %d ticks %d rest time %d\n", programManager.running->pid, programManager.running->name,programManager.running->priority,programManager.running->ticks,programManager.running->total);
      asm_halt();
  }
  void forth_thread(void *arg) { //打印线程相关信息后循环
          printf("pid %d name \"%s\" \t  priority %d ticks %d rest time %d\n", programManager.running->pid, programManager.running->name,programManager.running->priority,programManager.running->ticks,programManager.running->total);
      asm_halt();
  }
  
  void third_thread(void *arg) {	//打印线程相关信息后，生成第五个线程循环
        printf("pid %d name \"%s\" \t  priority %d ticks %d rest time %d\n", programManager.running->pid, programManager.running->name,programManager.running->priority,programManager.running->ticks,programManager.running->total);
      printf("------The fifth thread is created.\n");
      programManager.executeThread(fifth_thread, nullptr, "fifth thread", 1);
       asm_halt();
  }
  void second_thread(void *arg) {	//打印线程相关信息后，生成第四个线程循环
          printf("pid %d name \"%s\" \t  priority %d ticks %d rest time %d\n", programManager.running->pid, programManager.running->name,programManager.running->priority,programManager.running->ticks,programManager.running->total);
      printf("------The forth thread is created.\n");
      programManager.executeThread(forth_thread, nullptr, "forth thread", 2);
      asm_halt();
  }
  void noson(void *arg){//打印线程相关信息后循环
          printf("pid %d name \"%s\" \t  priority %d ticks %d rest time %d\n", programManager.running->pid, programManager.running->name,programManager.running->priority,programManager.running->ticks,programManager.running->total);
      asm_halt();
  }
  void first_thread(void *arg)
  {
      // 第1个线程不可以返回
      printf("pid %d name \"%s\" \t  priority %d ticks %d rest time %d\n", programManager.running->pid, programManager.running->name,programManager.running->priority,programManager.running->ticks,programManager.running->total);
      
      if (programManager.readyPrograms.size() == 0)
      {   //生成三个线程
          printf("------The second thread is created.\n");
          programManager.executeThread(second_thread, nullptr, "second thread", 3);
           printf("------The third thread is created.\n");
          programManager.executeThread(third_thread, nullptr, "third thread", 2);
          printf("------The noson thread is created.\n");
          programManager.executeThread(noson, nullptr, "noson", 1);
      }
      asm_halt();
  }
  ```

  - 第一种是仅输出信息，第二种在输出信息后还会生成新的线程。
  
    #### 3.事实上，时间片轮转可与其他算法结合，产生新的算法，由于种类繁多，便不一一尝试，多级反馈队列调度算法(MFQS)便是结合的算法之一。

#### 二.先来先服务(FCFS)

- **按照线程的生成顺序进行线程调度**，一直运行单个线程直到运行所需时间结束，进行线程调度。仅需对时间中断的处理函数进行处理即可：

  ```c++
  void c_time_interrupt_handler(){
      PCB *cur = programManager.running;
      if (cur->total!=0){	//如果运行时间未耗尽则继续运行
          cur->ticksPassedBy++;
          cur->total -- ;
         printf("pid %d name \"%s\" priority %d ticks %d rest : %d , where : %d\n ", cur->pid, cur->name,cur->priority,cur->ticks,cur->total,cur->stack);
      }else{		//运行时间结束，杀死线程，并进行调度。
          cur->status =ProgramStatus ::DEAD;
          programManager.schedule();
      }
  }
  ```

  - 因为在生成线程函数executeThread中，**每生成一个线程就将线程压入就绪队列的队尾**，这符合先来先服务的思想。

#### 三.时间片轮转(RR)

- **时间片轮转便是按照每个线程所给的时间片进行调度的条件，当每个线程所给的时间片为0则进行调度，若线程的total未清零，则将线程放入就绪队列，等待下次调度**。实验教程中所实现的就是时间片轮转，其中实现的代码实现在上文均已呈现，便不再赘述。

#### 四.优先级/最短作业（进程）优先调度(PSA/SJF)

注：**因为每个在实验设置中，每个线程的作业长度(运行需要时间)是由优先级决定的，优先级越大，所需运行时间越短，因此将两个算法放一起**。事实上，SJF实现上仅是将排序的判断条件从优先级改成total。

- **在每个线程生成时，对就绪队列的所有线程进行优先级/运行所需时间的判断，优先级高/运行所需时间短的放在就绪队列前面，以供下次调度**。

  ```c++
  	ListItem *item = readyPrograms.front();	//对就绪队列中的线程优先级进行判断
      PCB *first = ListItem2PCB(item, tagInGeneralList);
      if(thread->priority<first->priority){		//若优先级高于新产生的则插入到队列之前
         readyPrograms.push_front(&(thread->tagInGeneralList));
      }else{		//反之正常插入
         readyPrograms.push_back(&(thread->tagInGeneralList));
      }
  ```

  - 该部分添加在executeThread()之中，即将线程压入就绪队列之前。

- **时间中断处理函数部分按照先来先服务(FCFS)的处理函数。**

#### 五.响应比最高者优先算法(HRRN)

- **在进行线程调度之前，对就绪队列中的所有线程进行响应比的计算，并且按照由高到低进行排序**，因为响应比的计算涉及浮点数的运算，便实现了可变参数函数的**浮点数输出**。
  $$
  响应比(RR) = 运行需要时间(total)+线程等待时间(wait)/运行需要时间(total)
  $$

  $$
  响应比(RR) = 1 + 线程等待时间(wait)/运行需要时间(total)
  $$

  

- **时间中断处理函数部分按照先来先服务(FCFS)的处理函数。**

- **因为每次调度前，线程的等待时间都会发生变化，线程的响应比自然也会变化**，所以我们需要在线程切换函数schedule中进行编辑：

  ```c++
  void ProgramManager::schedule()
  {   
      bool status = interruptManager.getInterruptStatus();
      interruptManager.disableInterrupt();	//关中断
      if (readyPrograms.size() == 0)		//若就绪队列空则程序结束
      {
          interruptManager.setInterruptStatus(status);
          if(running->ticks<=0){		//程序结束需要将pid置零
              running->pid = 0;
             program_exit();
          }
          return;
      }
      if (running->status == ProgramStatus::RUNNING)	//程序调度时等待时间需要清零
      {
          running->status = ProgramStatus::READY;
          running->ticks = running->priority * 5;
          running->wait = 0;	//等待时间清零
          readyPrograms.push_back(&(running->tagInGeneralList));
      }
      else if (running->status == ProgramStatus::DEAD)
      {   	//终止态程序标记打印
          printf("------ %s is done.\n",running->name);
          releasePCB(running);
      }
      //以下为等待时间赋值，计算并赋值响应比
       ListItem *item = readyPrograms.front();
       printf("Ready :");
      while (item){	//循环遍历就绪队列
          PCB *t= ListItem2PCB(item, tagInGeneralList);
          t->wait += running->ticksPassedBy; 	//等待时间等于上一个线程运行时间加上已经等待时间
          t->rr =1+(double)t->wait/(double)t->total; //计算响应比
          printf("pid :%d  rr :%f",t->pid,t->rr);	//输出信息
          item = item->next;
      }
      //以下按响应比排序
      ListItem *item1 = readyPrograms.front();	//循环遍历
      while(readyPrograms.find(item1)!= readyPrograms.size()-1){
          PCB *c= ListItem2PCB(item1, tagInGeneralList);//当前线程c
          PCB *n= ListItem2PCB(item1->next, tagInGeneralList);//下一个线程n
          if (n->rr>c->rr){	//若下一个线程n响应比高于当前线程c响应比
              PCB *w= ListItem2PCB(readyPrograms.front(), tagInGeneralList);
              ListItem *tmp = item1->next;  	//先删除下一个线程n
              readyPrograms.erase( readyPrograms.find(item1->next));
              if(w->rr<n->rr){	//将下一个线程n与就绪队列第一个线程比较
                  readyPrograms.push_front(tmp);
              }else{		//若大于，说明n的响应比最大，直接放队头
                  readyPrograms.insert(1,tmp);//否则放在队头之后
              }
          }else{
              item1=item1->next;
          }
      }
      //以下取排序后的就绪队列队头(最高响应比)
      ListItem *item2 = readyPrograms.front();
      PCB *next = ListItem2PCB(item2, tagInGeneralList);
      PCB *cur = running;
      next->status = ProgramStatus::RUNNING;
      running = next;
  
      readyPrograms.pop_front();
  
      asm_switch_thread(cur, next);	//线程切换
  
      interruptManager.setInterruptStatus(status);
  }
  ```
  
  - 当线程被调用时，它的等待时间需要被清零。
  
  - **若有一个线程是第三个被处理的线程，它的等待时间就等于前两个线程的运行时间**，所以线程等待时间等于上一个线程运行时间加上已经等待时间：
    $$
    线程等待时间(wait) + =  上一个线程运行时间(pre->ticksPassedBy)
    $$

  
  - 在处理完运行中的线程后，对就绪队列进行处理：为就绪队列所有线程赋值等待时间、计算并赋值其响应比，之后对就绪队列按照响应比进行排序，**以确保响应比最高的线程在就绪队列第一个（即下一个运行）**。
  - 之后每次线程调度都要**重新赋值等待时间和计算赋值响应比，并将响应比最高的线程放在第一位**。
  
- 

#### 六.多级反馈队列调度算法(MFQS)

- 多级反馈队列调度算法按照**优先级/时间片对线程进行排序，并压入最高级队列**，**之后按照时间片轮转法(RR)进行线程调度，若时间片结束但线程仍未结束，则将线程压入下一级就绪队列。直到最高级就绪队列的线程全部调度完(为空)，进入下一级就绪队列，对进程赋予时间片并且重新调度。若线程还未结束，则进入最低级队列，进行反复压入最低级调度，直到线程结束**。

- 算法**为PCB新设置了which变量，用于表示线程所在的就绪队列**，实现方面首先**设置了3个就绪队列**

  ```c++
  (program.h)
  List readyPrograms; // 处于ready(就绪态)的线程/进程的队列
  List readyPrograms1; // 低一级的就绪队列
  List readyPrograms2;// 最低级就绪队列
  ```

- 之后**按照优先级(PSA)对线程进行排序，并将排序好的所有线程放入第一个(最高优先级的就绪队列)readyPrograms中，因此executeThread基本不变**，按优先级(PSA)排序算法在上文已经展示，便不再赘述。

- 具体实现在schedule线程切换函数中实现：

  ```c++
  void ProgramManager::schedule()
  {   
      bool status = interruptManager.getInterruptStatus();
      interruptManager.disableInterrupt();	//关中断
      if ((readyPrograms.size() == 0)&&(readyPrograms1.size() == 0)&&(readyPrograms2.size() == 0))
      {	//因为就绪队列有三个，因此要三个就绪队列全为空才可以返回线程
          interruptManager.setInterruptStatus(status);
          if(running->ticks<=0){
              running->pid = 0;
             program_exit();
          }
          return;
      }
      if (running->status == ProgramStatus::RUNNING)
      {	//运行态线程挂起
          running->status = ProgramStatus::READY;
          running->ticks = running->priority * 5;
          running->wait = 0;
          switch (running->which)
          {		//根据PCB所在就绪队列判断，进入下一级优先队列
          case 0:	//最高级降级
              running->which = 1;
              readyPrograms1.push_back(&(running->tagInGeneralList));
              break;
          case 1:
              running->which = 2;
              readyPrograms2.push_back(&(running->tagInGeneralList));
              break;
          case 2:	//最低级的队列无法降级，则在最低级循环
              running->which = 2;
              readyPrograms2.push_back(&(running->tagInGeneralList));
              break;    
          }
         
      }
      else if (running->status == ProgramStatus::DEAD)
      {   	//线程结束
          printf("------ %s is done.\n",running->name);
          releasePCB(running);
      }
       ListItem *item2;	
      if(readyPrograms.size()!=0){//若最高级队列空了
          item2= readyPrograms.front();	
          readyPrograms.pop_front();
      }else if(readyPrograms1.size()!=0){//调度线程选择次级队列的线程
          item2 = readyPrograms1.front();
          readyPrograms1.pop_front();
      }else{		//若次级队列空了
          item2 = readyPrograms2.front();/调度线程选择最低级队列的线程
          readyPrograms2.pop_front();
      }
      //处理将要切换线程
      PCB *next = ListItem2PCB(item2, tagInGeneralList);
      PCB *cur = running;
      next->status = ProgramStatus::RUNNING;
      running = next;
  
      asm_switch_thread(cur, next);	//线程切换
  
      interruptManager.setInterruptStatus(status);
  }
  ```

  - 若高级就绪队列空了，调度线程就从低一级的就绪队列中取。
  - 处在高级队列的**线程若一次调度不得能完成工作**，则对其降级。

- **多级反馈队列调度算法核心是降级，未执行完的线程将会降低优先级，之后有空再调度。**



## 实验过程

### Assignment 1 printf的实现:

><img src="img/r1-1.png">

- 正如图中红色箭头所指示，**浮点数的输出正常**，**制表符\t也正常输出**，具体实现上文已经详细阐述，这里不再赘述。

### Assignment 2 线程的实现：

><img src="img/r2.png">

以上是初始线程的成员打印，详细成员列表在上文均已阐述，便不再赘述。

### 注：为了使CPU在线程上花费的时间更加直观地显示，本次实验屏幕打印部分会非常多，若欲运行程序检查其正确性，希望使用make debug，对程序进行调试，以便查看线程运作。

### Assignment 3 线程调度切换的秘密

><img src="img/r3-1.png">
>
><img src="img/r3-2.png">

- **第一个线程的PCB产生地址所在为139648(图中eax)**,在**载入各种信息后PCB的地址扩展到147344**(图中edx)，同时也是PCB栈stack的地址。接下来便是线程切换：

><img src="img/r3-4.png">

- 因为第一个线程之前是没有线程的，所以线程切换存储上一个线程的操作得到值都是0。**如果是未曾运行过的线程ebp、ebx、edi、esi存放0值，若是运行过的线程这4个寄存器用于存放线程在被切换之前的状态信息，如所需执行函数执行到哪部地址，函数对应参数值为多少，执行步骤的偏移地址等**

><img src="img/r3-5.png">

- 第一次线程切换切换到处理器，**这也是新创建线程被调度的例子**。

><img src="img/r3-6.png">

- 第一个线程的函数执行到循环步骤，**此前线程1会生成线程2和线程3，生成线程的寄存器变换如同上文提及线程1的生成，便不在赘述，之后线程1将进行循环，直到线程时间片耗尽。记下线程1函数最后执行到的步骤地址0x2316c(143724)和0x23174(143732)**。
  - 其中**0x2316c(143724)是循环asm_halt之前一步的地址**
  - **0x23174(143732)是整个线程1执行函数地址终止地址**

><img src="img/r3-7.png">

- 上文说到线程1在时间片耗尽前执行循环，**时间片每减少一次，都会打印一次信息到屏幕**，时间片耗尽后线程调度，图中寄存器和代码部分为**线程1切换到线程2**。
- 其中**esp和ebp存储线程1切换前的状态，分别为0x230b8(143544)与0x230f4(143604)**

><img src="img/r3-8.png">

- 线程2的PCB是接着线程1的PCB的，**因此线程1终止地址(stack的地址)也是线程2起始，而线程2PCB终止地址在esp中(2个PCB宽度2*4096)。**

><img src="img/r3-9.png">

- 接下来线程便切换到线程2，以下**执行线程2函数(起始为147832)**，之后等到时间片结束切换到线程3，过程与线程1到线程2一致，都属于线程**调度新产生的线程**，便不再赘述。以下探究**调度之前被换下处理器后又重新调度：线程3到线程1**。

><img src="img/r3-10.png">

- 从右边屏幕打印的内容可见，线程3的stack地址为151908，右边寄存器eax值为起始地址，esp与ebp为线程切换前执行到的地址。

><img src="img/r3-11.png">

- 这时候**线程3切换回之前已经调度过的线程1**，因此当前**esp和ebp的值为先前存储的值**。

><img src="img/r3-12.png">

- 因为线程1在被切换前运行到循环函数，所以在线程切换后也进入循环，可以看到**esp地址变换到0x23168，因为栈的扩展是自顶向下，所以执行0x2316c下一步函数(asm_halt)便是减少4个字节 的0x23168(asm_halt所在)**
  - **0x23174(143732)是整个线程1执行函数地址终止地址**

以上便是**一个线程从创建开始到第一次被调度，以及之后被换下，之后再被重新调度的过程以及对应的寄存器变换。**

### Assignment 4 调度算法的实现

#### *注：一个程序应该是有结束的时刻，因此会在线程初始化时为线程提供需要运行时间total,等到total为0，将线程的状态调整为终止态。整个Assignment 4 都是以程序结束为终止条件。*

**此前已经提醒过，若欲验证实验代码正确性，请使用make debug进行调试**

**以下实验截图均为make debug调试结果**

- ### *一.先来先服务(FCFS)*

  ><img src="img/r4-1-1.png">

  ><img src="img/r4-1-2.png">

  图中可见线程1运行本身函数时，**生成了3个子线程**，之后**进入循环状态，直到线程运行时间结束(线程运行完毕)**，而子线程的生成顺序为**second->third->noson**。为符合**先来先服务**算法，接下来线程执行顺序应该为**second->third->noson**，并且在**每个线程运行时间结束后才会进行线程调度**。
  
  ><img src="img/r4-1-3.png">

  如图所示，接下来**second生成了子线程forth后**，运行了**45次(45个时间中断)**运行结束。**因为打印行数过多，生成forth部分被覆盖，但因为third线程和second线程差不多，接下来third线程会有生成提示。**
  
  ><img src="img/r4-1-4.png">
  
  ><img src="img/r4-1-5.png">

  如图所示，second后顺序为third->noson。**其中second和third线程分别又生成了子线程forth和fifth**。按照**先来先服务原则**，接下来的调度顺序为**forth->fifth->程序结束**。
  
  ><img src="img/r4-1-6.png">
  
  ><img src="img/r4-1-7.png">
  
  **至此FCFS实现完成，以上截图可证明其正确性。**

- ### *二.时间片轮转(RR)*

  **因为设置给每个线程的时间片长度为它的优先级的5倍，而新添加的线程运行所需时间的长度为线程优先级平方的5倍，所以会出现1优先级的线程经过一次调度就结束。**

  ><img src="img/r4-2-1.png">

  first线程优先级是1，所以时间片=执行时间=5个时间中断，所以一次调度就结束了。**之后就绪队列内容为second->third->noson**。

  ><img src="img/r4-2-2.png">

  second线程因为优先级3，时间片为15，执行15次循环后，线程调度，其程序剩余时间还有30个时间中断。

  **因为是forth先生成，second才进行循环之后挂起，所以之后就绪队列内容为third->noson->forth->second**。

  ><img src="img/r4-2-3.png">

  third线程优先级为2，时间片10，剩余时间10。**third与fifth关系同理，所以之后就绪队列内容为noson->forth->second->fifth->third**。

  ><img src="img/r4-2-4.png">

  noson线程优先级1，一次调度结束运行，接下来是second生成的forth。**因为是forth先生成，second才进行循环之后挂起，third与fifth关系同理，所以在forth调度前，就绪队列中当前顺序为forth->second->fifth->third。**

  ><img src="img/r4-2-5.png">
  
  调度forth和second，因为调度后运行时间未结束所以挂起,执行fifth。**截图之后就绪队列中顺序应为third->forth->second**。
  
  ><img src="img/r4-2-6.png">
  
  ><img src="img/r4-2-7.png">
  
  **至此RR实现完成，以上截图可证明其正确性。**

- ### *三.优先级优先调度(PSA)*

  ><img src="img/r4-3-1.png">

  初始生成三个线程，**但是我们是在生成线程阶段对优先级进行排序**，所以**就绪队列的内容为noson->third->second**，所以第一个线程执行结束后，**执行的是noson线程**。

  ><img src="img/r4-3-2.png">

  接下来执行的是**third线程**，期间生成了fifth线程。因为**fifth的优先级是1，比second高，在生成时，就绪队列会重新排序**,所以**就绪队列的内容为fifth->second**。(详情查阅上述**实验方案中**的代码)。执行完后**就绪队列剩下second线程**。

  ><img src="img/r4-3-3.png">

  ><img src="img/r4-3-4.png">

  在**second线程执行时会生成forth线程，从而就绪队列为forth**。

  **至此PSA实现完成，以上截图可证明其正确性。**

- ### *四.响应比最高者优先算法(HRRN)*

  ><img src="img/r4-4-1.png">

  first线程运行与先前一致，但在**每次线程调度前，都会对就绪队列的线程的等待时间赋值，以及计算响应响应比，最后根据响应比排序：高响应比优先**。可见在first线程完成后，屏幕打印出**就绪队列的pid和响应比rr**。

  按照响应比排序后，**就绪队列的内容为noson->third->second**。

  ><img src="img/r4-4-2.png">

  noson执行后，因为**等待时间的变化，响应比rr需重新计算**，**其中就绪队列中pid=2的third线程响应比为1.5，所以排在第一个。**

  ><img src="img/r4-4-3.png">

  - 可以见到**third线程的wait等待时间变成了10(因为经过first和noson两个执行时间为5的线程)**。
  - 因为**third线程生成了fifth线程，执行时间为5**。所以fifth的响应比为5(**因为生成fifth后，third还运行了20个时间片，所以响应比为1+20/5=5**)。而second的**等待时间变成了30**(first 5 + noson 5 + third 20)，响应比也就为**1+30/45=1.666**。所以接下来执行fifth，最后就绪队列仅剩second，**且等待时间为35**。

  ><img src="img/r4-4-5.png">

  可见最上方**second线程的wait = 35，可验证先前步骤的正确性**。second线程结束后，**之前生成的forth线程调度运行**。

  **至此HRRN实现完成，以上截图可证明其正确性。**

- ### *五.多级反馈队列调度算法(MFQS)*

  ><img src="img/r4-5-1.png">

  多级反馈队列，我们在PCB新增设了**which，用于表示线程处在哪个就绪队列**。**所有线程初始生成时都是进入0号就绪队列，且按照优先级排序**。所以**0号就绪队列内容为noson->third->second**，其他就绪队列为空。

  ><img src="img/r4-5-2.png">

  在执行完noson后，按照优先级执行third，此时fifth进入**0号就绪队列**，而third线程运行时间未耗尽，所以进入**1号就绪队列**。此时因为fifth优先级更高，所以**0号就绪队列内容为fifth->second,1号就绪队列为third，2号就绪队列为空。**先执行fifth之后,**0号就绪队列内容为second,1号就绪队列为third，2号就绪队列为空。**

  ><img src="img/r4-5-3.png">

  接下来执行second线程，因为未执行完毕进入1号就绪队列。此时forth线程生成进入0号。所以**0号就绪队列内容为forth,1号就绪队列为third->second，2号就绪队列为空。**

  ><img src="img/r4-5-4.png">

  因为**0号就绪队列优先级最高，所以先执行其中内容，直到为空**，**所以先执行forth**。所以之后**0号就绪队列为空，1号就绪队列为third->second->forth**。

  ><img src="img/r4-5-5.png">

  之后调度third线程，可以看到**whichReady的值变为1，代表来自1号就绪队列**。此后**1号就绪队列为second->forth**

  ><img src="img/r4-5-6.png">

  之后执行forth，剩下second。执行second后，因为执行时间未结束，所以second进入2号就绪队列。所以**0号和1号就绪队列为空，2号就绪队列值为second**。

  ><img src="img/r4-5-7.png">

  最后执行second，**可以看到whichReady的值变为2**，之后程序结束。

  **至此MFQS实现完成，以上截图可证明其正确性。**

## *遭遇问题*

#### 线程的竞争问题：

- 在实现assignment 4 时，因为怀有“**所有程序都有对应的执行所需时间，则其中的线程也应当有实行所需时间，以及当其执行时间为0之时，线程应该结束**”，便使得教程中的ticks时间片作为实行所需时间，**在中断处理函数中为所有线程设置统一的时间片**，按照如下代码执行：

  ```c++
   int time1 = 0;	//为时间中断计数，作为时间片
   void way1(){
      PCB *cur = programManager.running;
       if (time1==10){	//时间片统一为10
         
           programManager.schedule(time1);	//时间片耗尽则线程调度 
           time1 = 0;
       }else{				//否则继续运行线程
            cur->ticks--;
           cur->ticksPassedBy++;
           time1++;
           printf("pid %d name \"%s\" priority %d readysize %d curt : %d where %d\n ", cur->pid, cur->name,cur->priority,programManager.readyPrograms.size(),time1,cur->stack );		//打印相关信息
           if (cur->ticks<=0){	//若线程运行所需时间耗尽
              cur->status =ProgramStatus ::DEAD;	//终止线程
              programManager.schedule(time1);		//进行线程调度
              time1 = 0;       
          }      
       }
  }
  ```

  起初的设想是为了时间片轮转法(RR)而设置的函数，但已经调试会发现。在first线程运行结束后，**调度second线程的time1不会重新计数(置0)，导致second一执行完函数，不会进行asm_halt循环直接进入third线程，而之后的线程运行一切正常。**

- #### 问题解决：与TA经过一个小时的探讨后，个人的观点理论上可行，代码也理论可行。问题出现在 " times1"这个全局变量上。因为所有线程共用这一个变量，实验并未设置临界区，导致first线程与second线程竞争访问变量times1，导致问题出现。之后通过重写代码，改成上述实验方案中的内容，解决问题。



## 实验总结

此次实验将进一步完善我们即将架构的操作系统，其中的内容便是进程实现，但因为此次实验的知识储备并未涉及到分页制度对进程地址的分配方式。我们还不能设置出完善的进程，从而对其进行管理，并管理其中fork出的线程。所以此次实验我们直接实现线程来代替进程。而首先最重要的就是实现线程的PCB，其中需要再次对栈的指针以及对应内存地址的偏移相关知识进行巩固。通过查看各种寄存器的变化，可以进一步了解线程调度的秘密。之后，借助线程调度的基础知识，对线程调度的算法进行扩充与完善。除此之外，为了信息可以更加便利地屏幕打印，学习可变参数函数地原理，对printf这个打印函数进行复现。

为了实现高响应比优先，需要计算响应比rr，其中需要使用到浮点数，为了使打印信息更加直观体现，printf屏幕打印需完善浮点数的打印。起初本人打算调用C语言的stdio基本库中的putchar函数，但想到基层实现应该不再借助库的其他函数，便使用了实验教程中函数的变种。

虽然实验是有着程序终止这一步骤，即程序在所有线程执行时间过后就会回收内存并退出。但事实上，程序的一号进程是不能回收的，因为操作系统中，其他进程都是由第一个进程fork得来。**但是经过询问TA，我的实验理论可行，且并无明显错误，所以验收得以通过。**

 

## 参考文献

lab5实验教程

