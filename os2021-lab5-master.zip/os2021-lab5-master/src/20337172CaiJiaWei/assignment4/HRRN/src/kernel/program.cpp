#include "program.h"
#include "stdlib.h"
#include "interrupt.h"
#include "asm_utils.h"
#include "stdio.h"
#include "thread.h"
#include "os_modules.h"

const int PCB_SIZE = 4096;                   // PCB的大小，4KB。
char PCB_SET[PCB_SIZE * MAX_PROGRAM_AMOUNT]; // 存放PCB的数组，预留了MAX_PROGRAM_AMOUNT个PCB的大小空间。
bool PCB_SET_STATUS[MAX_PROGRAM_AMOUNT];     // PCB的分配状态，true表示已经分配，false表示未分配。
void program_exit();
ProgramManager::ProgramManager()
{
    initialize();
}

void ProgramManager::initialize()
{
    allPrograms.initialize();
    readyPrograms.initialize();
    readyPrograms1.initialize();
    running = nullptr;
    way = 3;
    for (int i = 0; i < MAX_PROGRAM_AMOUNT; ++i)
    {
        PCB_SET_STATUS[i] = false;
    }
}
int ProgramManager::executeThread(ThreadFunction function, void *parameter, const char *name, int priority)
{
    // 关中断，防止创建线程的过程被打断
    bool status = interruptManager.getInterruptStatus();
    interruptManager.disableInterrupt();

    // 分配一页作为PCB
    PCB *thread = allocatePCB();

    if (!thread)
        return -1;

    // 初始化分配的页
    memset(thread, 0, PCB_SIZE);

    for (int i = 0; i < MAX_PROGRAM_NAME && name[i]; ++i)
    {
        thread->name[i] = name[i];
    }

    thread->status = ProgramStatus::READY;
    thread->priority = priority;
    thread->ticks = priority * 5;
    thread->total = priority *priority * 5 ;
    thread->ticksPassedBy = 0 ;
    thread->wait = 0;
    thread->pid = ((int)thread - (int)PCB_SET) / PCB_SIZE;
    //
    
    thread->rr =1.0; 
    // 线程栈
    thread->stack = (int *)((int)thread + PCB_SIZE);
    thread->stack -= 7;
    thread->stack[0] = 0;
    thread->stack[1] = 0;
    thread->stack[2] = 0;
    thread->stack[3] = 0;
    thread->stack[4] = (int)function;
    thread->stack[5] = (int)program_exit;
    thread->stack[6] = (int)parameter;

    readyPrograms.push_back(&(thread->tagInGeneralList));
    allPrograms.push_back(&(thread->tagInAllList));
    // 恢复中断
    interruptManager.setInterruptStatus(status);
    return thread->pid;
}
void ProgramManager::schedule()
{   
    bool status = interruptManager.getInterruptStatus();
    interruptManager.disableInterrupt();	//关中断
    if (readyPrograms.size() == 0)		//若就绪队列空则程序结束
    {
        interruptManager.setInterruptStatus(status);
        if(running->ticks<=0){		//程序结束需要将pid置零
            running->pid = 0;
           program_exit();
        }
        return;
    }
    if (running->status == ProgramStatus::RUNNING)	//程序调度时等待时间需要清零
    {
        running->status = ProgramStatus::READY;
        running->ticks = running->priority * 5;
        running->wait = 0;	//等待时间清零
        readyPrograms.push_back(&(running->tagInGeneralList));
    }
    else if (running->status == ProgramStatus::DEAD)
    {   	//终止态程序标记打印
        printf("------ %s is done.\n",running->name);
        releasePCB(running);
    }
    //以下为等待时间赋值，计算并赋值并=响应比
     ListItem *item = readyPrograms.front();
     printf("Ready :");
    while (item){	//循环遍历就绪队列
        PCB *t= ListItem2PCB(item, tagInGeneralList);
        t->wait += running->ticksPassedBy; 	//等待时间等于上一个线程运行时间加上已经等待时间
        t->rr =1+(double)t->wait/(double)t->total; //计算响应比
        printf("pid :%d  rr :%f",t->pid,t->rr);	//输出信息
        item = item->next;
    }
    //以下按响应比排序
    ListItem *item1 = readyPrograms.front();	//循环遍历
    while(readyPrograms.find(item1)!= readyPrograms.size()-1){
        PCB *c= ListItem2PCB(item1, tagInGeneralList);//当前线程c
        PCB *n= ListItem2PCB(item1->next, tagInGeneralList);//下一个线程n
        if (n->rr>c->rr){	//若下一个线程n响应比高于当前线程c响应比
            PCB *w= ListItem2PCB(readyPrograms.front(), tagInGeneralList);
            ListItem *tmp = item1->next;  	//先删除下一个线程n
            readyPrograms.erase( readyPrograms.find(item1->next));
            if(w->rr<n->rr){	//将下一个线程n与就绪队列第一个线程比较
                readyPrograms.push_front(tmp);
            }else{		//若大于，说明n的响应比最大，直接放队头
                readyPrograms.insert(1,tmp);//否则放在队头之后
            }
        }else{
            item1=item1->next;
        }
    }
    //以下取排序后的就绪队列队头(最高响应比)
    ListItem *item2 = readyPrograms.front();
    PCB *next = ListItem2PCB(item2, tagInGeneralList);
    PCB *cur = running;
    next->status = ProgramStatus::RUNNING;
    running = next;

    readyPrograms.pop_front();

    asm_switch_thread(cur, next);	//线程切换

    interruptManager.setInterruptStatus(status);
}

void program_exit()
{
    PCB *thread = programManager.running;
    thread->status = ProgramStatus::DEAD;

    if (thread->pid)
    {
        programManager.schedule();
    }
    else
    {
        interruptManager.disableInterrupt();
        printf("halt\n");
        asm_halt();
    }
}

PCB *ProgramManager::allocatePCB()
{
    for (int i = 0; i < MAX_PROGRAM_AMOUNT; ++i)
    {
        if (!PCB_SET_STATUS[i])
        {
            PCB_SET_STATUS[i] = true;
            return (PCB *)((int)PCB_SET + PCB_SIZE * i);
        }
    }

    return nullptr;
}

void ProgramManager::releasePCB(PCB *program)
{
    int index = ((int)program - (int)PCB_SET) / PCB_SIZE;
    PCB_SET_STATUS[index] = false;
}