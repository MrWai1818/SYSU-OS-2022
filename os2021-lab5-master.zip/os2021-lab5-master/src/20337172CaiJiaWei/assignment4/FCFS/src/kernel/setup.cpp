#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"
#include "program.h"
#include "thread.h"

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;
void first_thread(void *arg);
void final_jug_thread(void *arg) {
    printf("pid %d name \"%s\" \t  priority %d totally time %d\n", programManager.running->pid, programManager.running->name,programManager.running->priority,programManager.running->wait);
    //  if ((!programManager.readyPrograms.size())){
    //      if(programManager.way==2){
    //          programManager.way=0;
    //          return;
    //      }else{
    //         programManager.way++;
    //      }
    //     printf("\nRestarting with a new way\n\n");
    //      programManager.executeThread(first_thread, nullptr, "first thread", 1);
    //  }
    programManager.running->pid=0;
}
void fifth_thread(void *arg) {
        printf("pid %d name \"%s\" \t  priority %d ticks %d rest time %d\n", programManager.running->pid, programManager.running->name,programManager.running->priority,programManager.running->ticks,programManager.running->total);
    //programManager.executeThread(final_jug_thread, nullptr, "final_jug_thread", 10);
    asm_halt();
}
void forth_thread(void *arg) {
        printf("pid %d name \"%s\" \t  priority %d ticks %d rest time %d\n", programManager.running->pid, programManager.running->name,programManager.running->priority,programManager.running->ticks,programManager.running->total);
    asm_halt();
}

void third_thread(void *arg) {
      printf("pid %d name \"%s\" \t  priority %d ticks %d rest time %d\n", programManager.running->pid, programManager.running->name,programManager.running->priority,programManager.running->ticks,programManager.running->total);
    printf("------The fifth thread is created.\n");
    programManager.executeThread(fifth_thread, nullptr, "fifth thread", 1);
     asm_halt();
}
void second_thread(void *arg) {
        printf("pid %d name \"%s\" \t  priority %d ticks %d rest time %d\n", programManager.running->pid, programManager.running->name,programManager.running->priority,programManager.running->ticks,programManager.running->total);
    printf("------The forth thread is created.\n");
    programManager.executeThread(forth_thread, nullptr, "forth thread", 2);
    asm_halt();
}
void noson(void *arg){
        printf("pid %d name \"%s\" \t  priority %d ticks %d rest time %d\n", programManager.running->pid, programManager.running->name,programManager.running->priority,programManager.running->ticks,programManager.running->total);
    asm_halt();
}
void first_thread(void *arg)
{
    // 第1个线程不可以返回
    printf("pid %d name \"%s\" \t  priority %d ticks %d rest time %d\n", programManager.running->pid, programManager.running->name,programManager.running->priority,programManager.running->ticks,programManager.running->total);
    
    if (programManager.readyPrograms.size() == 0)
    {   
        printf("------The second thread is created.\n");
        programManager.executeThread(second_thread, nullptr, "second thread", 3);
         printf("------The third thread is created.\n");
        programManager.executeThread(third_thread, nullptr, "third thread", 2);
        printf("------The noson thread is created.\n");
        programManager.executeThread(noson, nullptr, "noson", 1);
    }
    asm_halt();
}

extern "C" void setup_kernel()
{

    // 中断管理器
    interruptManager.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);

    // 输出管理器
    stdio.initialize();

    // 进程/线程管理器
    programManager.initialize();

    // 创建第一个线程
    int pid = programManager.executeThread(first_thread, nullptr, "first thread", 1);
    if (pid == -1)
    {
        printf("can not execute thread\n");
        asm_halt();
    }
    ListItem *item = programManager.readyPrograms.front();
    PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
    firstThread->status = RUNNING;
    programManager.readyPrograms.pop_front();
    programManager.running = firstThread;
    asm_switch_thread(0, firstThread);

    asm_halt();
}
