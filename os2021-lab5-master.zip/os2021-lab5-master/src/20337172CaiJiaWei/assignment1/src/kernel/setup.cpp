#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;


extern "C" void setup_kernel()
{
    // 中断处理部件
    interruptManager.initialize();
    // 屏幕IO处理部件
    stdio.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);
    //asm_enable_interrupt();
    printf("print percentage: %%\n"
           "print char \"N\":\t %c\n"
           "print string \"Hello World!\": \t%s\n"
           "print decimal: \"-1234\": \t%d\n"
           "print hexadecimal \"0x7abcdef0\": \t%x\n"		
           "print octaladecimal \"05050\": \t%o\n",		//添加的8进制输出
           'N', "Hello World!", -1234, 0x7abcdef0,05050);	
    printf("print floating number :\"1.23241\"%f\n",1.23241);//添加了浮点数的输出
    printf("let's do a table :\tlala\t");		//制表符实现的直观体现
    //uint a = 1 / 0;
    asm_halt();
}
