#include "os_type.h"

template<typename T>
void swap(T &x, T &y) {
    T z = x;
    x = y;
    y = z;
}
//为了输出浮点数准备的数字转换到字符串
int pint(char *n,int d,int start){//基本与itos一致
    int t = 0,l=start;	
    while (d){
        t= d % 10;
        d/= 10;
        n[l] = t > 9 ? t - 10 + 'A' : t + '0';
        ++l;
    }
    if(!l) {
        n[start] = '0';
        n[start+1] = '\0';
        ++l;
    }
    return l;
}
void ftos(char *n,double p){//浮点数转换为字符串输出
    int tint = (int) p;		//将整数部分与小数部分分开
    int tflt = (int)(100000* (p - tint));
    int s = pint(n,tflt,0);	//分别将数字转换成字符串  
    n[s++]='.';		//再加个点
    int s1 = pint(n,tint,s++);
    for(int i = 0, j = s1 - 1; i < j; ++i, --j) {
        swap(n[i], n[j]);
    }
    n[s1++]= ' \0'; 
}
void itos(char *numStr, uint32 num, uint32 mod) {
    // 只能转换2~26进制的整数
    if (mod < 2 || mod > 26 || num < 0) {
        return;
    }

    uint32 length, temp;

    // 进制转换
    length = 0;
    while(num) {
        temp = num % mod;
        num /= mod;
        numStr[length] = temp > 9 ? temp - 10 + 'A' : temp + '0';
        ++length;
    }

    // 特别处理num=0的情况
    if(!length) {
        numStr[0] = '0';
        numStr[1] = '\0';
        ++length;
    }

    // 将字符串倒转，使得numStr[0]保存的是num的高位数字
    for(int i = 0, j = length - 1; i < j; ++i, --j) {
        swap(numStr[i], numStr[j]);
    }
    
    numStr[length] = '\0';
}

void memset(void *memory, char value, int length)
{
    for (int i = 0; i < length; ++i)
    {
        ((char *)memory)[i] = value;
    }
}