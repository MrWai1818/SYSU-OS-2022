#ifndef THREAD_H
#define THREAD_H

#include "list.h"
#include "os_constant.h"

typedef void (*ThreadFunction)(void *);

enum ProgramStatus	//线程的状态
{
    CREATED,	//创建
    RUNNING,	//运行
    READY,		//就绪
    BLOCKED,	//阻塞	
    DEAD		//终止
};

struct PCB
{
    int *stack;                      // 栈指针，用于调度时保存esp
    char name[MAX_PROGRAM_NAME + 1]; // 线程名
    enum ProgramStatus status;       // 线程的状态
    int priority;                    // 线程优先级
    int pid;                         // 线程pid
    int ticks;                       // 线程时间片总时间
    int wait;		//线程从创建到被调度时的等待时间
    int ticksPassedBy;               // 线程已执行时间
    int total;		//线程的运行时间
    double rr;		//线程的响应比
    int which;		//线程所在的就绪队列
    ListItem tagInGeneralList;       // 线程队列标识
    ListItem tagInAllList;           // 线程队列标识
};

#endif
