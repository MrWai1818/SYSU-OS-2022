#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"
#include "program.h"
#include "thread.h"
#include "sync.h"
#include "memory.h"

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;
// 内存管理器
MemoryManager memoryManager;

void first_thread(void *arg)
{
    // 第1个线程不可以返回
    // stdio.moveCursor(0);
    // for (int i = 0; i < 25 * 80; ++i)
    // {
    //     stdio.print(' ');
    // }
    // stdio.moveCursor(0);
    int p[7]={1,2,3,4,2,1,3};
    printf("The list of pages :");
     for(int i=0;i<7;i++){
        printf("%d  ",p[i]);
    }
    printf("\n");
    for (int i = 0; i < 7; i++){
        char *temp = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 10,p[i]);
        printf("p%d 's Virtualaddr  :%x    ",p[i], temp);
        printf("p%d 's Physicaladdr :  %x \n",p[i],memoryManager.vaddr2paddr((int)temp));
    }
    
    // for(int i =0;i<7;i++){
    //     if(memoryManager.size<3){
    //         memoryManager.size++;
    //         char *temp = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 10,p[i]);
    //         memoryManager.FIFO[memoryManager.size-1] = temp;
    //         printf("p%d 's Virtualaddr  :%x    ",p[i], temp);
    //         printf("p%d 's Physicaladdr :  %x \n",p[i],memoryManager.vaddr2paddr((int)temp));
    //     }else{
    //         memoryManager.releasePages(AddressPoolType::KERNEL, (int)memoryManager.FIFO[0], 10);
    //         char *temp = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 10,p[i]);
    //         memoryManager.FIFO[0] = memoryManager.FIFO[1];
    //         memoryManager.FIFO[1] = memoryManager.FIFO[2];
    //         memoryManager.FIFO[2] = temp;
    //         printf("p%d 's Virtualaddr  :%x    ",p[i], temp);
    //         printf("p%d 's Physicaladdr :  %x \n",p[i],memoryManager.vaddr2paddr((int)temp));
    //     }
    // }
    // char *p1 = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 10);
    // char *p2 = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 10);
    // char *p3 = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 10);

    // printf("Virtual  :  %x %x %x    ", p1, p2, p3);
    // printf("Physical  :  %x %x %x\n",memoryManager.vaddr2paddr((int)p1),memoryManager.vaddr2paddr((int)p2),memoryManager.vaddr2paddr((int)p3));
  //  memoryManager.releasePages(AddressPoolType::KERNEL, (int)p2, 10);
    // p2 = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 10);

    // printf("Virtual  :%x    ", p2);
    // printf("Physical  :  %x \n",memoryManager.vaddr2paddr((int)p2));
    // p2 = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 10);
    
    // printf("Virtual  :%x    ", p2);
    // printf("Physical  :  %x \n",memoryManager.vaddr2paddr((int)p2));
    asm_halt();
}

extern "C" void setup_kernel()
{

    // 中断管理器
    interruptManager.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);

    // 输出管理器
    stdio.initialize();

    // 进程/线程管理器
    programManager.initialize();

    // 内存管理器
    memoryManager.openPageMechanism();
    memoryManager.initialize();

    // 创建第一个线程
    int pid = programManager.executeThread(first_thread, nullptr, "first thread", 1);
    if (pid == -1)
    {
        printf("can not execute thread\n");
        asm_halt();
    }

    ListItem *item = programManager.readyPrograms.front();
    PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
    firstThread->status = RUNNING;
    programManager.readyPrograms.pop_front();
    programManager.running = firstThread;
    asm_switch_thread(0, firstThread);

    asm_halt();
}
