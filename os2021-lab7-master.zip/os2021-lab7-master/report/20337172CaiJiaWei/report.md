<font size =6>**操作系统原理 实验五**</font>

## 个人信息

【院系】计算机学院

【专业】计算机科学与技术

【学号】20337172

【姓名】蔡嘉威

## 实验题目

内存管理

## 实验目的

1. 实现二级分页机制，并能够在虚拟机地址空间中进行内存管理，包括内存的申请和释放等。
2. 实现动态分区算法。
3. 实现页面置换算法。
4. 掌握和实现虚拟内存管理技术。

## 实验要求

1. 实现二级分页机制，进行内存管理
2. 实现动态分区算法
3. 实现页面置换算法
4. 撰写实验报告。

##  实验方案



### Preparation

------

为实现内存管理，我们需要知道计算机可用的内存大小，这时候可以借助芯片功能号为0xe801的15h中断获取内存，其中中断返回结果为内存大小，且将结果保存在寄存器中，**ax寄存器存15MB，单位1KB，bx存16MB~4GB，单位64KB**。总内存有：
$$
内存总容量 = (ax ⋅ 1024 + bx ⋅ 64 ⋅ 1024) 字节
$$

  以上得到内存大小后，就要对其进行管理。我们需要标识来记录每个存储单位是否被分配的状态，为了尽量降低额外开销，我们使用bitmap这一数据结构来记录资源的状态，一份资源一bit，其中**bitmap存在内核**中。以下是bitmap的成员结构：

```c++
class BitMap
{
public:
    // 被管理的资源个数，bitmap的总位数
    int length;
    // bitmap的起始地址
    char *bitmap;
public:
    // 初始化
    BitMap();
    // 设置BitMap，bitmap=起始地址，length=总位数(即被管理的资源个数)
    void initialize(char *bitmap, const int length);
    // 获取第index个资源的状态，true=allocated，false=free
    bool get(const int index) const;
    // 设置第index个资源的状态，true=allocated，false=free
    void set(const int index, const bool status);
    // 分配count个连续的资源，若没有则返回-1，否则返回分配的第1个资源单元序号
    int allocate(const int count);
    // 释放第index个资源开始的count个资源
    void release(const int index, const int count);
    // 返回Bitmap存储区域
    char *getBitmap();
    // 返回Bitmap的大小
    int size() const;
private:
    // 禁止Bitmap之间的赋值
    BitMap(const BitMap &) {}
    void operator=(const BitMap&) {}
};
```

**因为bitmap的实现近乎根据实验教程，所以只挑选较关键部分进行分析**

```c++
//将存储单位的对应位图状态进行更改
void BitMap::set(const int index, const bool status){
    int pos = index / 8;
    int offset = index % 8;
    // 清0
    bitmap[pos] = bitmap[pos] & (~(1 << offset));
    // 置1
    if (status)
    {
    bitmap[pos] = bitmap[pos] | (1 << offset);
    }
}
```

- 指针访问bitmap最小单位是bytes，但我们设置用于标识的最小单位是bit，所以我们要通过地址偏移实现对位图的修改：
  $$
  i = 8 ⋅ pos + offset, 0 ≤ offset < 8
  $$

  - i表示位图或存储单位的第i个资源
  - pos是每存储8个单位的标号
  - offset即是第i个单位在pos中的偏移

以上我们实现了位图，为了实现进一步的分页制度，我们需要地址池这一数据结构来说明哪些页已经被分配，哪些未被分配。bitmap是一种资源管理方式，而我们使用地址池来更系统地使用这一方式。以下是地址池的成员结构：

```c++
class AddressPool
{
public:
    BitMap resources;	//对应内存空间的bitmap
    int startAddress;	//可用空间的起始地址
public:
    AddressPool();
    // 初始化地址池
    void initialize(char *bitmap, const int length, const int startAddress);
    // 从地址池中分配count个连续页，成功则返回第一个页的地址，失败则返回-1
    int allocate(const int count);
    // 释放若干页的空间
    void release(const int address, const int amount);
};
```

**以上地址池部分的实现根据实验教程，因逻辑简单便不在赘述。**



### Assignment1

------

有了以上两种数据结构的基础，可以开始实现页式管理。将地址空间可用的内存分为内核和用户两部分，通过创建新的数据结构存放两个地址池作为可用内存的管理器，其成员如下：

```c++
class MemoryManager
{
public:
    // 可管理的内存容量
    int totalMemory;
    // 内核物理地址池
    AddressPool kernelPhysical;
    // 用户物理地址池
    AddressPool userPhysical;
    // 内核虚拟地址池
    AddressPool kernelVirtual;
public:
    MemoryManager();
    // 初始化地址池
    void initialize();
    // 从type类型的物理地址池中分配count个连续的页
    // 成功，返回起始地址；失败，返回0
    int allocatePhysicalPages(enum AddressPoolType type, const int count);
    // 释放从paddr开始的count个物理页
    void releasePhysicalPages(enum AddressPoolType type, const int startAddress, const int count);
    // 获取内存总容量
    int getTotalMemory();
    // 开启分页机制
    void openPageMechanism();
    // 页内存分配
    int allocatePages(enum AddressPoolType type, const int count);
    // 虚拟页分配
    int allocateVirtualPages(enum AddressPoolType type, const int count);
    // 建立虚拟页到物理页的联系
    bool connectPhysicalVirtualPage(const int virtualAddress, const int physicalPageAddress);
    // 计算virtualAddress的页目录项的虚拟地址
    int toPDE(const int virtualAddress);
    // 计算virtualAddress的页表项的虚拟地址
    int toPTE(const int virtualAddress);
    // 页内存释放
    void releasePages(enum AddressPoolType type, const int virtualAddress, const int count);    
    // 找到虚拟地址对应的物理地址
    int vaddr2paddr(int vaddr);
    // 释放虚拟页
    void releaseVirtualPages(enum AddressPoolType type, const int vaddr, const int count);
};
```

**分页机制的开启，程序使用的地址空间是虚拟地址空间，通过CPU对虚拟地址分段寻址转化为线性地址，再通过线性地址最终转化成对应的物理地址。可以认为分页制度在开通了虚拟内存后才有意义，否则分页的线性地址就是物理地址。**

以下对地址池进行初始化：

```c++
void MemoryManager::initialize(){
    this->totalMemory = 0;
    this->totalMemory = getTotalMemory();
    // 预留的内存
    int usedMemory = 256 * PAGE_SIZE + 0x100000;
    if (this->totalMemory < usedMemory){
        printf("memory is too small, halt.\n");
        asm_halt();
    }
    // 剩余的空闲的内存
    int freeMemory = this->totalMemory - usedMemory;
	//为内核和用户分配可用内存，各一半
    int freePages = freeMemory / PAGE_SIZE;
    int kernelPages = freePages / 2;
    int userPages = freePages - kernelPages;
	//内核地址起始和用户地址起始
    int kernelPhysicalStartAddress = usedMemory;
    int userPhysicalStartAddress = usedMemory + kernelPages * PAGE_SIZE;
	//内核、用户、虚拟内核bitmap起始
    int kernelPhysicalBitMapStart = BITMAP_START_ADDRESS;
    int userPhysicalBitMapStart = kernelPhysicalBitMapStart + ceil(kernelPages, 8);
    int kernelVirtualBitMapStart = userPhysicalBitMapStart + ceil(userPages, 8);
	//内核地址池初始化
    kernelPhysical.initialize(
        (char *)kernelPhysicalBitMapStart,
        kernelPages,
        kernelPhysicalStartAddress);
	//用户地址池初始化
    userPhysical.initialize(
        (char *)userPhysicalBitMapStart,
        userPages,
        userPhysicalStartAddress);
	//用户虚拟地址池初始化
    kernelVirtual.initialize(
        (char *)kernelVirtualBitMapStart,
        kernelPages,
        KERNEL_VIRTUAL_START);
	//内存信息输出
    printf("total memory: %d bytes ( %d MB )\n",
           this->totalMemory,
           this->totalMemory / 1024 / 1024);
	//内核地址空间可用
    printf("kernel pool\n"
           "    start address: 0x%x\n"
           "    total pages: %d ( %d MB )\n"
           "    bitmap start address: 0x%x\n",
           kernelPhysicalStartAddress,
           kernelPages, kernelPages * PAGE_SIZE / 1024 / 1024,
           kernelPhysicalBitMapStart);
	//用户地址空间可用
    printf("user pool\n"
           "    start address: 0x%x\n"
           "    total pages: %d ( %d MB )\n"
           "    bit map start address: 0x%x\n",
           userPhysicalStartAddress,
           userPages, userPages * PAGE_SIZE / 1024 / 1024,
           userPhysicalBitMapStart);
	//内核虚拟地址空间
    printf("kernel virtual pool\n"
           "    start address: 0x%x\n"
           "    total pages: %d  ( %d MB ) \n"
           "    bit map start address: 0x%x\n",
           KERNEL_VIRTUAL_START,
           userPages, kernelPages * PAGE_SIZE / 1024 / 1024,
           kernelVirtualBitMapStart);
}
```

- 因为分页机制的开启，程序看到的是虚拟地址，所以多设置内核虚拟地址空间的bitmap。
- 我们的内核放在0x100000的地址空间之前，即我们预设其大小为**1MB**，因为在0x7C00开始载入操作系统，**所以在0x10000之后放置bitmap**。

- usedMemory为暂时空闲的256个页表，其中第一个页表是指向二级页表的页目录表，第二个个页表指向0~1MB内核部分的页表。**之后的254个页表作为进程间的共享公共区域，这个区域是一些标准的系统库，这个共享库在物理内存中只存储一份，每个进程将这个区域的虚拟地址映射到同一份共享库物理内存上。**

```c++
//物理页面分配
int MemoryManager::allocatePhysicalPages(enum AddressPoolType type, const int count){
    int start = -1;
    if (type == AddressPoolType::KERNEL){	//调用地址池的函数
        start = kernelPhysical.allocate(count);
    }else if (type == AddressPoolType::USER){
        start = userPhysical.allocate(count);
    }
    return (start == -1) ? 0 : start;
}
```

- **物理以及虚拟页面的分配(allocate)和释放(release)**实现和逻辑都较简单且相似，便不再赘述
- 其中物理页面释放仅是根据地址空间类型调用对应地址池的函数即可

```C++
//获取内存
int MemoryManager::getTotalMemory(){
    if (!this->totalMemory){
        int memory = *((int *)MEMORY_SIZE_ADDRESS);
        // ax寄存器保存的内容
        int low = memory & 0xffff;
        // bx寄存器保存的内容
        int high = (memory >> 16) & 0xffff;
        this->totalMemory = low * 1024 + high * 64 * 1024;
    }
    return this->totalMemory;
}
```

- 根据上述芯片的中断获取可用物理内存的大小

```c++
//打开分页机制
void MemoryManager::openPageMechanism(){
    // 页目录表指针
    int *directory = (int *)PAGE_DIRECTORY;
    //线性地址0~4MB对应的页表
    int *page = (int *)(PAGE_DIRECTORY + PAGE_SIZE);
    // 初始化页目录表
    memset(directory, 0, PAGE_SIZE);
    // 初始化线性地址0~4MB对应的页表
    memset(page, 0, PAGE_SIZE);
    int address = 0;
    // 将线性地址0~1MB恒等映射到物理地址0~1MB
    for (int i = 0; i < 256; ++i){
        // U/S = 1, R/W = 1, P = 1
        page[i] = address | 0x7;
        address += PAGE_SIZE;
    }
    // 初始化页目录项
    // 0~1MB
    directory[0] = ((int)page) | 0x07;
    // 3GB的内核空间
    directory[768] = directory[0];
    // 最后一个页目录项指向页目录表
    directory[1023] = ((int)directory) | 0x7;
    // 初始化cr3，cr0，开启分页机制
    asm_init_page_reg(directory);
    printf("open page mechanism\n");
}
```

- 在初始化页目录表和页表后，为了访问方便，我们将物理地址和虚拟地址的0~1MB区域设置恒等映射，并且设置对应的页目录项和页表项。

- 之后我们将页目录项完善，第一个页目录项指向0~1MB内核空间，之后第768个页目录项指向3GB的内核空间，最后一个页目录项1023指向页目录表本身,是为了**构造页目录项和页表项的虚拟地址**。**而两者之间刚好有256个页表，对应之前提及的usedmemory的256个页。这256个页出去最后一个指向页目录表，代表虚拟地址的3GB~4GB空间，这一部分是作为进程间进行通信时的共享区域。对虚拟空间3GB~4GB进行访问时就是对内核该区域进行访问。**(内核虚拟地址addr与虚拟地址addr+0xc0000000(3GB)的物理地址一致)。

- 因为3GB~4GB是共享区域，去除内核的1MB，**以0xc0100000剩下作为虚拟内核起始地址，可以让所有进程都能够共享内核分配的页内存。**

- 最后将处理好的页目录表放入cr3寄存器，**交给CPU将虚拟地址转换成物理地址即可**，转换代码如下：

  ```asm
  asm_init_page_reg:
      push ebp
      mov ebp, esp
      push eax
      mov eax, [ebp + 4 * 2]
      mov cr3, eax ; 放入页目录表地址
      mov eax, cr0
      or eax, 0x80000000
      mov cr0, eax ; 置PG=1，开启分页机制
      pop eax
      pop ebp
      ret
  ```

接下来便是对内存的分配：

```c++
int MemoryManager::allocatePages(enum AddressPoolType type, const int count){
    // 第一步：从虚拟地址池中分配若干虚拟页
    int virtualAddress = allocateVirtualPages(type, count);
    if (!virtualAddress){
        return 0;
    }
    bool flag;
    int physicalPageAddress;
    int vaddress = virtualAddress;
    // 依次为每一个虚拟页指定物理页
    for (int i = 0; i < count; ++i, vaddress += PAGE_SIZE){
        flag = false;
        // 第二步：从物理地址池中分配一个物理页
        physicalPageAddress = allocatePhysicalPages(type, 1);
        if (physicalPageAddress){
            // 第三步：为虚拟页建立页目录项和页表项，使虚拟页内的地址经过分页机制变换到物理页内。
            flag = connectPhysicalVirtualPage(vaddress, physicalPageAddress);
        }else{
            flag = false;
        }// 分配失败，释放前面已经分配的虚拟页和物理页表
        if (!flag){
            // 前i个页表已经指定了物理页
            releasePages(type, virtualAddress, i);
            // 剩余的页表未指定物理页
            releaseVirtualPages(type, virtualAddress + i * PAGE_SIZE, count - i);
            return 0;
        }
    }
    return virtualAddress;
}
```

- 首先在虚拟空间中分配页，再为其分配对应的物理页，最后将虚拟页缓冲到内存物理地址(建立映射关系)中即可。
- 如果上述步骤任意一步失败，要将虚拟页和对应物理页释放。**详细分析将在Assignment4呈现.**

```c++
bool MemoryManager::connectPhysicalVirtualPage(const int virtualAddress, const int physicalPageAddress){
    // 计算虚拟地址对应的页目录项和页表项
    int *pde = (int *)toPDE(virtualAddress);
    int *pte = (int *)toPTE(virtualAddress);
    // 页目录项无对应的页表，先分配一个页表
    if(!(*pde & 0x00000001)){
        // 从内核物理地址空间中分配一个页表
        int page = allocatePhysicalPages(AddressPoolType::KERNEL, 1);
        if (!page)
            return false;
        // 使页目录项指向页表
        *pde = page | 0x7;
        // 初始化页表
        char *pagePtr = (char *)(((int)pte) & 0xfffff000);
        memset(pagePtr, 0, PAGE_SIZE);
    }
    // 使页表项指向物理页
    *pte = physicalPageAddress | 0x7;
    return true;
}
```

- 分配好虚拟页和物理页后，需要为虚拟地址设置对应的页表和页目录项，再将分配的虚拟页通过虚拟地址指向对应的物理页。**详细分析将在Assignment4呈现.**

```c++
void MemoryManager::releasePages(enum AddressPoolType type, const int virtualAddress, const int count){
    int vaddr = virtualAddress;
    int *pte;
    for (int i = 0; i < count; ++i, vaddr += PAGE_SIZE){
        // 第一步，对每一个虚拟页，释放为其分配的物理页
        releasePhysicalPages(type, vaddr2paddr(vaddr), 1);
        // 设置页表项为不存在，防止释放后被再次使用
        pte = (int *)toPTE(vaddr);
        *pte = 0;
    }
    // 第二步，释放虚拟页
    releaseVirtualPages(type, virtualAddress, count);
}
```

- 页内存释放需要虚拟页以及对应的物理页，**当然产生的页目录项和页表也要删除。**



### Assignment2

------

**分页机制属于非连续的内存分配管理，接下来将要实现的动态分区算法属于连续内存分配管理。**经过思考总结，决定延续采用实验教程中bitmap结构来实现动态分区算法。个人认为**动态分区也可以看作为分页机制，只不过分页机制的页大小为4KB而动态分区为1B，因此分页产生的线性地址直接就是物理地址，无需进行转换。**因此主要改动都在bitmap的实现之中。



#### 准备工作

如果沿用实验教程中bitmap结构，1位可表示1B，本次操作系统的**可用内存大小为126MB，则代表所需位图大小为2MB左右，先前实验将bitmap装在0x10000，在1MB的内核内，但是如今的位图过大，所以将其放在内核0x100000之后**，对内存管理的地址池大小进行更改：

```c++
void MemoryManager::initialize(){
    this->totalMemory = 0;
    this->totalMemory = getTotalMemory();
    //可用内存=总内存-位图大小-内核大小
    int freeMemory = this->totalMemory-2097152-0x100000;
    。。。。。
     //7ce000=8183808，代表内核位图大小8183808
    int kernelPhysicalStartAddress = 0x100000+0x7ce000;
    //f9c000=8183808*2，用户起始要算上内核位图和用户位图
    int userPhysicalStartAddress =0x100000+0xf9c000+ kernelPages * PAGE_SIZE;
	//位图起始在内核后
    int kernelPhysicalBitMapStart = 0x100000;
    int userPhysicalBitMapStart = kernelPhysicalBitMapStart + ceil(kernelPages, 8);
   。。。。。。
}
```

- 经过计算预设用户位图和内核位图各需要占有8183808位，大约1MB，两个合起来就大约2MB，所以内核程序装不下，将位图放在内核程序后。内核位图放在内核地址空间后，用户位图放在用户地址空间后。



#### 首次适应(First Fit)

每次都从低地址开始，找到空闲且可用的空间就分配给进程

```c++
void BitMap::initialize(char *bitmap, const int length){
    this->bitmap = bitmap;
    this->length = length;
    int bytes = ceil(length, 8);
    printf("pages' num:%d size_of_bitmap:%d" ,length,bytes);
    bitmap[bytes]={0};	//初始化空闲分区表
}
```

- 因为位图过大，所以舍弃掉位图的循环赋值，否则开销以及运行时间都会很大。

因为实验教程中bitmap的allocate()代码使用的二重循环，每次从低地址寻找可以使用的内存，符合FirstFit的原理，便不再修改。



#### 邻近适应(Next Fit)

与首次适应(First Fit)几乎一致，唯一不同的就是空闲分区表按地址递增排序，即每次分配从上次查找结束位置开始。因此在bitmap类中添加标识作为上一次结束位置：

```c++
class BitMap{
    public:
        。。。。。
        int lastAddress; //上次分配结束位置
   	。。。。。
}
```

之后在每次分配结束更改lastAddress即可：

```c++
int BitMap::allocate(const int count){
    。。。。。。
    //查找可用内存从上次结束开始
    index = lastAddress;
	。。。。。。
        // 存在连续的count个资源
        if (empty == count){
          	。。。。。。
            lastAddress = start +count ;//更新结束位置
            return start;
        }
    }
    return -1;
}
```



#### 最佳适应(Best Fit)

分区按容量递增排序，每次进程进入都要重新排序，而优先使用小的空闲区，尽量留大的。所以设置临时的空闲分区表来存储分区：

```c++
int BitMap::allocate(const int count){
    。。。。。。
    int index, empty, start, space =-1;
    int blockSize[256] = {64946177};//设置空闲分区表
    int blockStart[256] = {0} ;//表中每块分区的起点
    index = 0;
    //找到内存中的全部空闲分区
    while (index < length){
        。。。。。。
        empty = 0;	//判断一个分区的大小
        start = index;//分区的起点
        //计算当前分区的大小，以及下个分区的起点
        while ((index < length) && (!get(index))){
            ++empty;
            ++index;
        }
        space++;//空闲分区数-1
        blockSize[space] = empty;     
        blockStart[space] = start;
        if (space != 0){//空闲分区数=1
            for(int i =0;i<space;i++){//冒泡排序
                for(int j=0;j<space-i;j++){
                    if(blockSize[j]>blockSize[j+1]){
                        int temp = blockSize[j];
                        blockSize[j] = blockSize[j+1];
                        blockSize[j+1] = temp;
                        temp = blockStart[j];
                        blockStart[j] = blockStart[j+1];
                        blockStart[j+1] = temp;
                    }
                }
            }
        }     
    }
    //输出内存中的所有分区标号以及大小
    for(int i =0;i<space+1;i++){
        printf("block:%d size:%d\n",i,blockSize[i]); 
    }
    //为申请的进程进行分配
    for (int j = 0; j < space+1; j++){
        //  存在连续的count个资源
        if (blockSize[j] >= count){
            start = blockStart[j];
            for (int i = 0; i < count; ++i){
                set(start + i, true);
            }
            lastAddress = start + count;
            return start;
        }
    }
    return -1;
}
```

- 局部变量blockSize存放分区表每个分区大小。
- 局部变量blockStart存放分区表每个分区的起始块号。
- empty用于计算分区大小，start记录分区的起始块号，space记录分区个数。
- **因为是动态分区，只有在程序进入内存后才会开始划分，否则分区只有1个，就是整块内存。**
- **每一次分配分区时，都对内存中已有的分区进行排除，剩下未被占用的内存作为空闲分区，通过冒泡排序对所有空闲分区根据大小排序后，找到合适大小的空闲分区才进行分配。**(每次分配内存->使用二重循环寻找内存中的空闲分区->进行排序->分配大小合适的空闲分区)



#### 最坏(最大)适应(Worst Fit)

与最佳适应(Best Fit)几乎一致，仅是对空闲分区排序按照从大到小，优先使用大的空闲分区。

**因为代码仅是更改排序算法的排序顺序，其余未改动，便不再赘述。**



#### 统一测试案例

```c++
void first_thread(void *arg){
    char *p1 = (char *)memoryManager.allocatePhysicalPages(AddressPoolType::KERNEL, 40960);
    char *p2 = (char *)memoryManager.allocatePhysicalPages(AddressPoolType::KERNEL, 8192);
    char *p3 = (char *)memoryManager.allocatePhysicalPages(AddressPoolType::KERNEL, 40960);
    char *p4 = (char *)memoryManager.allocatePhysicalPages(AddressPoolType::KERNEL, 4096);
    char *p5 = (char *)memoryManager.allocatePhysicalPages(AddressPoolType::KERNEL, 40960);
    printf("%x %x %x %x %x\n", p1, p2, p3,p4,p5);
	memoryManager.releasePhysicalPages(AddressPoolType::KERNEL, (int)p2, 8192);
	memoryManager.releasePhysicalPages(AddressPoolType::KERNEL, (int)p4, 4096);
    p2 = (char *)memoryManager.allocatePhysicalPages(AddressPoolType::KERNEL, 2048);
    printf("%x\n", p2);
    p2 = (char *)memoryManager.allocatePhysicalPages(AddressPoolType::KERNEL, 4096);
    printf("%x\n", p2);
    asm_halt();
}
```

- 首先设置5个分区，大小分别为40960，8192，40960，4096，40960(单位为B)
- 同时释放2号、4号两个分区
- 再生成大小为2048B和4096B的两个分区



### Assignment3

------

许多情况下，一般的程序是不能一次性全部装入内存中运行，这时候就需要使用页面置换机制，让部分程序先进入内存，等到将访问的页不在内存内，发生缺页中断，从外存中换入需要的页。为了实现更符合实际，**给每个进程分配固定的驻留集的大小，当驻留集满时，程序运行到不再驻留集的页面时，发生页面置换。**

**注意：1.释放虚拟地址对应的物理页不必释放虚拟页     2.因为本次实验未涉及磁盘的读写，对于置换出来的页直接释放其物理页而不是换入外存。**



#### 先进先出(FIFO)

当驻留集满时，置换最早进入内存的页面。设置

```c++
class MemoryManager{
    public:
        。。。。。。
        int FIFO[3];	//驻留集大小3
        int pname[7];	//虚拟内存中进程分区的名字
        int list[7];	//虚拟内存中进程分区的起始地址
        int size;		//该进程需要分几区
        。。。。。。
        // 页内存分配
    	int allocatePages(enum AddressPoolType type, const int count,int name);
    	。。。。。。
};
```

- 在存储管理器中设置FIFO数组作为驻留集，大小为3，FIFO满时进行页面置换。
- pname和list数组为两个对应的数组，pname是虚拟内存中进程将要分几区运行每个区的名字(标号)，list是虚拟内存中进程每个分区的起始地址。
- size代表进程要分几个区运行的区数。

```c++
int MemoryManager::allocatePages(enum AddressPoolType type, const int count,int name){
    int tempf = 0;	//用于判断该名称的区是否存在已有的进程分区中
    int virtualAddress=0;	//虚拟地址
    for(int i =0;i<this->size;i++){
        if(this->pname[i]==name){
            tempf = 1;
            virtualAddress =this->list[i];	//存在，则取出来作为虚拟地址
            break;
        }
    }
    // 若不是已拥有
    if(tempf==0){
        this->size++;	//分区数目增加
        virtualAddress = allocateVirtualPages(type, count);	//分配新的虚拟内存空间
        this->list[size-1] =  virtualAddress;	//该分区起始地址存入已拥有
        this->pname[size-1]=name;	//该分区名称存入已拥有
    }
    if (!virtualAddress){
        return 0;
    }
    bool flag;
    int physicalPageAddress;
    int vaddress = virtualAddress;
    int tt =0;	//判断将访问的分区是否在驻留集中
    for(int i=0;i<3;i++){
        if(this->FIFO[i]== vaddress){
            tt=1;     //若有，则不必在改变并分配物理内存，更改驻留集即可
            break;
        }
    }	
    if(tt==0){		//不存在则为虚拟地址分配对应物理地址
            // 依次为每一个虚拟页指定物理页
        if(size<4){	//前3次驻留集未空，直接将生产物理地址载入
            this->FIFO[size-1] =  vaddress;
        }else{
            int vaddr = FIFO[0];	//替换最早进入驻留集的分区(页)
            int *pte;
            for (int i = 0; i < count; ++i, vaddr += PAGE_SIZE){	//将最早进入驻留集的区对应物理地址释放
                releasePhysicalPages(AddressPoolType::KERNEL, vaddr2paddr(vaddr), 1);
                pte = (int *)toPTE(vaddr);	//但是虚拟地址不释放
                *pte = 0;
            }
            this->FIFO[0] = this->FIFO[1];	//第二进入驻留集的分区变成第一个进入驻留集的
            this->FIFO[1] = this->FIFO[2];
            this->FIFO[2] =vaddress ;		//新的分区的虚拟地址进入驻留集
        } 
        for (int i = 0; i < count; ++i, vaddress += PAGE_SIZE){//为新的分区分配物理页
            flag = false;
            // 第二步：从物理地址池中分配一个物理页
            physicalPageAddress = allocatePhysicalPages(type, 1);
            if (physicalPageAddress){
                // 第三步：为虚拟页建立页目录项和页表项，使虚拟页内的地址经过分页机制变换到物理页内。
                flag = connectPhysicalVirtualPage(vaddress, physicalPageAddress);
            }else{
                flag = false;
            }
            // 分配失败，释放前面已经分配的虚拟页和物理页表
            if (!flag){
                // 前i个页表已经指定了物理页
                releasePages(type, virtualAddress, i);
                // 剩余的页表未指定物理页
                releaseVirtualPages(type, virtualAddress + i * PAGE_SIZE, count - i);
                return 0;
            }
        }
    }
    return virtualAddress;
}
```

- 在代码开始判断将要访问的页分区是否**已经在虚拟内存空间中被分配，如果是则直接从list中取出该分区在虚拟内存中的地址。**若未分配则正常在虚拟内存空间中分配该分区所需的虚拟页，**暂不分配物理页**。
- 接下来判断将访问的页分区对应的虚拟地址是否已经存在驻留集FIFO中，若不在**则将其添加进FIFO，并为这个虚拟页分区分配对应的物理页分区。**如果FIFO满了则释放去FIFO数组第一个虚拟地址对应的物理页**(但是其虚拟内存中的页分区不释放),之后将第一个虚拟地址后面的虚拟地址顺序标号前移一位，新来虚拟地址放在最后一位，这代表“先入先出”。**
- 之后对新进入FIFO的虚拟地址分配物理页，以上是建立在将访问的虚拟地址不在FIFO中的情况下。



#### 最近最久未使用(LRU)

LRU算法需要一个计时数组为每一个分区上次被访问的间隔时间计数，存储管理器memory结构如下：

```c++
class MemoryManager{
    public:
        。。。。。。
        int LRU[3];		//驻留集，大小为3
        int counter[3];	//计时器，大小与LRU一致
        int pname[7];	//虚拟内存中进程分区的名字
        int list[7];	//虚拟内存中进程分区的起始地址
        int size;		//该进程需要分几区
        。。。。。。
        // 页内存分配
    	int allocatePages(enum AddressPoolType type, const int count,int name);
    	。。。。。。
};
```

- LRU数组作为大小为3的驻留集，和上一个FIFO的区别仅是名称不同
- pname、list、size等成员均与FIFO算法中一致，代表已经在虚拟内存空间中分配的页分区。
- counter数组大小需与LRU一致，为驻留集每个页分区被访问的时间间隔记录。

```c++
void MemoryManager::initialize(){
    。。。。。。
    for(int i=0;i<3;i++){
        this->LRU[i]=-1;
    }
    this->counter[0]=3;//为LRU中各个分区对应的计时器赋值
    this->counter[1]=2;
    this->counter[2]=1;   
    。。。。。。
}
```

- 当驻留集未空，驻留集中不会发生页面置换，因此暂时不需要对计时器counter进行判断。当驻留集满时，才需要分析counter的值，因此**在驻留集进行页面置换前，每个计时器的值可以按照分区进入驻留集的顺序预先设置好。**

```c++
int MemoryManager::allocatePages(enum AddressPoolType type, const int count,int name){
    //前置实现基本与FIFO一致，判断将访问页分区是否已经在虚拟内存中被分配
    int tempf = 0;
    int virtualAddress=0;
    for(int i =0;i<this->size;i++){
        if(this->pname[i]==name){
            tempf = 1;
            virtualAddress =this->list[i];
            break;
        }
    }
    // 若未分配则为该名称分区在虚拟内存空间中分配页
    if(tempf==0){
        this->size++;
        virtualAddress = allocateVirtualPages(type, count);
        this->list[size-1] =  virtualAddress;  
        this->pname[size-1]=name;
    }
    if (!virtualAddress){
        return 0;
    }
    bool flag;
    int physicalPageAddress;
    int vaddress = virtualAddress;
    int tt =0;	//判段将访问分区是否已经在驻留集中
    for(int i=0;i<3;i++){
        if(this->LRU[i]== vaddress){
            tt=1;     //在则不需要重新分配物理空间
            counter[i] =1;	//要初始化计时器
            break;
        }
    }
    if(tt==0){
        if(size<4){//驻留集未满则加入驻留集
            this->LRU[size-1] =  vaddress;
        }else{	//找到计时器中值最大的进行置换
            int max=0,maxv=0;
            for(int i=0;i<3;i++){//找到最大值
                if(counter[i]>maxv){
                    max=i;
                    maxv=counter[i];
                }
            }
            int vaddr = LRU[max];
            int *pte;	//释放时钟最大的分区的物理页
            for (int i = 0; i < count; ++i, vaddr += PAGE_SIZE){
              releasePhysicalPages(AddressPoolType::KERNEL, vaddr2paddr(vaddr), 1);
                pte = (int *)toPTE(vaddr);
                *pte = 0;
            }
            this->LRU[max] =vaddress ;	//将时间间隔最大的分区置换为新分区
            counter[max]=1;		//计时器置1
            for(int i=0;i<3;i++){	//驻留集其他分区计时器+1
                if (i!=max){
                    counter[i]++;
                }
            }
        } 
        for (int i = 0; i < count; ++i, vaddress += PAGE_SIZE){
            flag = false;
            // 第二步：从物理地址池中分配一个物理页
            physicalPageAddress = allocatePhysicalPages(type, 1);
            if (physicalPageAddress){
                // 第三步：为虚拟页建立页目录项和页表项，使虚拟页内的地址经过分页机制变换到物理页内。
                flag = connectPhysicalVirtualPage(vaddress, physicalPageAddress);
            }else{
                flag = false;
            }
            // 分配失败，释放前面已经分配的虚拟页和物理页表
            if (!flag){
                // 前i个页表已经指定了物理页
                releasePages(type, virtualAddress, i);
                // 剩余的页表未指定物理页
                releaseVirtualPages(type, virtualAddress + i * PAGE_SIZE, count - i);
                return 0;
            }
        }
    }
    return virtualAddress;
}
```

- 在代码开始判断将要访问的页分区是否**已经在虚拟内存空间中被分配，如果是则直接从list中取出该分区在虚拟内存中的地址。**若未分配则正常在虚拟内存空间中分配该分区所需的虚拟页，**暂不分配物理页**。
- 如果将访问分区就在驻留集里则不需要再次分配物理页，但**需要将计时器重置。**如果不在驻留集里，则对计时器进行判断，取最大的进行置换，**并将驻留集其他分区的计时器的计时+1**，之后再为新进入的分区分配物理地址。



#### 统一测试案例

```c++
void first_thread(void *arg){
    int p[7]={1,2,3,4,2,1,3};
    printf("The list of pages :");	//输出页分区访问顺序
    for(int i=0;i<7;i++){
        printf("%d  ",p[i]);
    }
    printf("\n");
    for (int i = 0; i < 7; i++){	//按照顺序访问页分区
        char *temp = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 10,p[i]);
        printf("p%d 's Virtualaddr  :%x    ",p[i], temp);
        printf("p%d 's Physicaladdr :  %x \n",p[i],memoryManager.vaddr2paddr((int)temp));
    }
    asm_halt();
}
```

- 数组p代表页分区的访问顺序
- 通过for循环遍历按照p数组中顺序访问页分区



### Assignment4

------

**因为分页制度要在虚拟内存的建立才会有意义，因此Assignment1的实验代码与Assignment4的代码均为实验教程src/5中的改版。**



#### “虚拟页内存管理“分析

虚拟页内存的初始化在Assignment1已分析，以下分析虚拟页内存分配的三步过程和虚拟页内存释放。

- #### 虚拟页内存分配

  **页内存分配的主要过程可以看作是为若干个连续的虚拟页指定物理页的过程**

  ```c++
  int MemoryManager::allocatePages(enum AddressPoolType type, const int count){
      // 第一步：从虚拟地址池中分配若干虚拟页
      int virtualAddress = allocateVirtualPages(type, count);
      if (!virtualAddress)
      {
          return 0;
      }
      bool flag;
      int physicalPageAddress;
      int vaddress = virtualAddress;
      // 依次为每一个虚拟页指定物理页
      for (int i = 0; i < count; ++i, vaddress += PAGE_SIZE){
          flag = false;
          // 第二步：从物理地址池中分配一个物理页
          physicalPageAddress = allocatePhysicalPages(type, 1);
          if (physicalPageAddress){
              // 第三步：为虚拟页建立页目录项和页表项，使虚拟页内的地址经过分页机制变换到物理页内。
              flag = connectPhysicalVirtualPage(vaddress, physicalPageAddress);
          }else{
              flag = false;
          }
          // 分配失败，释放前面已经分配的虚拟页和物理页表
          if (!flag){
              // 前i个页表已经指定了物理页
              releasePages(type, virtualAddress, i);
              // 剩余的页表未指定物理页
              releaseVirtualPages(type, virtualAddress + i * PAGE_SIZE, count - i);
              return 0;
          }
      }
      return virtualAddress;
  }
  ```

  - **从虚拟地址池中分配若干虚拟页**

    ```c++
    int MemoryManager::allocateVirtualPages(enum AddressPoolType type, const int count){
        int start = -1;
        if (type == AddressPoolType::KERNEL){
            start = kernelVirtual.allocate(count);
        }
        return (start == -1) ? 0 : start;
    }
    ```

    - 因为只设置了内核虚拟内存空间，所以虚拟页分配只为内核空间分配

  - **从物理地址池中分配一个物理页**

    - 因为物理页分配函数几乎与虚拟内存分配函数一致，便不再赘述。

  - **为虚拟页建立页目录项和页表项，使虚拟页内的地址经过分页机制变换到物理页内**

    ```c++
    bool MemoryManager::connectPhysicalVirtualPage(const int virtualAddress, const int physicalPageAddress){
        // 计算虚拟地址对应的页目录项和页表项
        int *pde = (int *)toPDE(virtualAddress);
        int *pte = (int *)toPTE(virtualAddress);
        // 页目录项无对应的页表，先分配一个页表
        if(!(*pde & 0x00000001)){
            // 从内核物理地址空间中分配一个页表
            int page = allocatePhysicalPages(AddressPoolType::KERNEL, 1);
            if (!page)
                return false;
            // 使页目录项指向页表
            *pde = page | 0x7;
            // 初始化页表
            char *pagePtr = (char *)(((int)pte) & 0xfffff000);
            memset(pagePtr, 0, PAGE_SIZE);
        }
        // 使页表项指向物理页
        *pte = physicalPageAddress | 0x7;
        return true;
    }
    ```

    - 在二级分页机制下，虚拟地址31~22位可在cr3寄存器中寻找到页目录表的物理地址，之后在页目录表中根据虚拟地址31~22位找到页表的物理地址。

    - 之后CPU根据21~12位虚拟地址找到页表物理地址再由此得出页表中物理页的物理地址。

    - 最后将物理页的物理地址的31-12位替换虚拟地址的31-12位得到虚拟地址对应的物理地址。

    - 在缓冲虚拟地址到物理地址前，需要为虚拟地址**在物理内存中的页目录表中**设置对应的页目录项和页表项的**虚拟地址**：

      ```c++
      int MemoryManager::toPDE(const int virtualAddress){
          return (0xfffff000 + (((virtualAddress & 0xffc00000) >> 22) * 4));
      }
      ```

      - pde的虚拟地址的页内偏移(11~0位)=虚拟地址[31:22]×4。因为一个页目录项大小为4字节，所以偏移位为页目录号×4。
      - 因为pde处于页目录表，而先前我们设置页目录表最后一项(directory[1023])指向页目录表本身，所以pde[21：12]的值即是pde在页目录表的位置，即1023，所以pde[21:12]= 1111111111。
      - 因为pde是页目录项的第1023项，所以pde[31:22]为页目录项的标号=1023=11111111。

      ```c++
      int MemoryManager::toPTE(const int virtualAddress){
          return (0xffc00000 + ((virtualAddress & 0xffc00000) >> 10) + (((virtualAddress & 0x003ff000) >> 12) * 4));
      }
      ```

      - 页表项所在的物理页是页表，所以其偏移pte[11:0]=页号(虚拟地址[21:12])×4
      - 由虚拟地址[31:22]指向的是pte页表，所以pte[21:12]=虚拟地址[31:22]
      - 和pde一样，pte[31:22]为该页表的页目录项所在的标号，为1023，所以pte[31:22]=11111111

    - 在获取了pte和pde后，设置一个物理页来存放虚拟地址的页目录表地址，再让pte指向对应的物理地址即可

- #### 虚拟页内存释放

  ```c++
  void MemoryManager::releasePages(enum AddressPoolType type, const int virtualAddress, const int count){
      int vaddr = virtualAddress;
      int *pte;
      for (int i = 0; i < count; ++i, vaddr += PAGE_SIZE){
          // 第一步，对每一个虚拟页，释放为其分配的物理页
          releasePhysicalPages(type, vaddr2paddr(vaddr), 1);
          // 设置页表项为不存在，防止释放后被再次使用
          pte = (int *)toPTE(vaddr);
          *pte = 0;
      }
      // 第二步，释放虚拟页
      releaseVirtualPages(type, virtualAddress, count);
  }
  ```

  - 对每个虚拟页要先释放其已经缓冲的物理页
  - 重置物理地址中的页表以及页表项
  - 释放虚拟页



#### 实验教程存在的bug

**1.cache中的页表没更新，导致页释放后CPU仍然能访问被释放的空间**

- 解决：在每次页分区释放时都重新打开分页机制，更新cr3的值

  ```c++
  void MemoryManager::releasePages(enum AddressPoolType type, const int virtualAddress, const int count){
      。。。。。。
      // 第二步，释放虚拟页
      releaseVirtualPages(type, virtualAddress, count);
  	asm_init_page_reg((int*)PAGE_DIRECTORY);
  }
  ```

**2.没有处理进程间竞争，如果不同进程同时申请同一块物理空间，会出现竞争条件**

- 模拟bug：因为设置两个进程同时申请的情况较难模拟，**且本次实验重点在于内存管理，不是处理竞争，所以只给出解决的代码以及结果。**

- 解决：使用自旋锁或者信号量机制处理

  使用lab6的自旋锁：

  ```c++
  class SpinLock{
      private:
          uint32 bolt;
      public:
          SpinLock();
          void initialize();
          void lock();
          void unlock();
  };
  ```

  测试代码：

  ```c++
  SpinLock aLock;
  void second_thread(void *arg){   
      aLock.lock();
      char *p1 = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 100);
      printf("second thread :%x \n", p1);
      aLock.unlock();
  }
  void third_thread(void *arg){
      aLock.lock();
      char *p1 = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 100);
      printf("third thread :%x \n", p1);
      aLock.unlock();
  }
  ```

  **因为本次实验重点在于内存管理，自旋锁实现代码便不再赘述，与lab6一致**

**3.在setup中声明申请分区时重复使用命名，如：**

```c++
char *p2 = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 10);
p2 = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 100);
```

**这会导致第一个p2的空间无法被直接访问。**

- 模拟bug：因为这个问题更倾向于理论上**对物理地址直接访问的途径缺失，个人认为没有模拟必要。**

- 解决：对每个页的分区命不同的名，或者在页表记录分区的物理地址。

**bug处理后的结果将于实验过程中给出。**



## 实验过程

### Assignment1

------

<img src = 'img/r1.png'>

- 红笔标注第一行代表可用内存空间，红笔框起三段分别为内核地址空间、用户地址空间、内核虚拟地址空间的起始地址、页数以及bitmap起始地址。

- 红笔标注后第一行对应代码中:

  ```c++
  printf("%x %x %x\n", p1, p2, p3);
  ```

  的输出。代表p1、p2、p3三个分区申请后的结果，输出的是虚拟地址：

  - p1=C0100000，因为虚拟内存空间起始地址为C0100000
  - p2=C0164000，因为p1大小为100页即4096×100，所以p1结束地址为C0164000，这也是p2的起始。其中16进制64000=10进制409600。p3同理

- 红笔标注后第二行打印前，代码执行了：

  ```c++
  memoryManager.releasePages(AddressPoolType::KERNEL, (int)p2, 10);
  p2 = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 100);
  ```

  - 释放了第一个p2的页，并且重新分配了大小为100的页，但是因为仅**释放10页，不够新的分区分配，所以新的p2地址放在分区p3之后。**
  - 新p2=**C01D2000=p3+409600=C016E000+64000(16)**

- 红笔标注后第二行打印前，代码执行了：

  ```c++
  p2 = (char *)memoryManager.allocatePages(AddressPoolType::KERNEL, 10);
  ```

  - 以p2的名字重新分配10页，因为先前已经释放了10页的旧p2，新p2地址会从旧p2地址开始，所以p2=C0164000。



### Assignment2

------

#### 首次适应(First Fit)

<img src = "img/r2-1.png">

- 红笔框起第一段代表可用页数、**位图大小**以及可用内存空间。实验方案中已经说明过，**认为动态分区是以页大小为1B进行的”分页“。**输出两次页数和位图大小是因为用户空间和内核空间各一次。

- 红笔框起2段分别为内核地址空间、用户地址空间、内核虚拟地址空间的起始地址、页数以及bitmap起始地址。实验方案中已经说明过，因为**位图大小为8118272B≈1MB，算上用户地址的位图≈2MB，放不进内核程序0~1MB内，所以放在0x100000内核程序之后，而内核地址真正开始地址为0x100000+(8118272×2)B=0x100000+0x7be000×2=0x8ce000**。也就是说在内核起始地址前有内核位图和用户位图，所以**用户位图起始地址为0x100000+8118272B=0x100000+0x7be000=0x8be000**.

- 红笔框起之后的内容是按照**实验方案中统一测试案例代码**，分配大小为40960、8192、40960、4096、40960的5个分区。之后执行

  ```c++
  memoryManager.releasePhysicalPages(AddressPoolType::KERNEL, (int)p2, 8192);
  memoryManager.releasePhysicalPages(AddressPoolType::KERNEL, (int)p4, 4096);
  p2 = (char *)memoryManager.allocatePhysicalPages(AddressPoolType::KERNEL, 2048);
  printf("%x\n", p2);
  p2 = (char *)memoryManager.allocatePhysicalPages(AddressPoolType::KERNEL, 4096);
  ```

  释放第二第四个分区的页后分配大小为2048B和4096B的页，根据FirstFit算法，**会分配旧p2空闲的8192B空间**，因为新的4096+2048<空闲的8192，所以**新的两个分区会紧接着分配在旧p2释放后的空闲分区。**

- 第一个新p2起始为旧p2的起始8D800，第二个新p2起始将紧接在第一个新p2后，地址为**8D8000+2048=8D8000+800(16)=8D8800。**

- #### **以上红框部分在整个Assignment2的输出均一致，在之后的不同算法中便不再重复说明**



#### 邻近适应(Next Fit)

NextFit算法仅是**寻找空闲分区时的起点为上次分区的终点**，其他代码与FirstFit并无不同。

<img src = "img/r2-2.png">

- 起始生成的5个分区大小均一致，**所以起始地址都与FirstFit中相同。**
- **释放的两个分区也与FirstFit中一致，为8192和4096分区。接下来生成的两个分区的顺序也是2048、4096，便不再重新张贴代码。**
- 在p5生成后，尽管释放了两个分区，上一次分配分区的结束地址仍是**0x8e5000+40960=0x8e5000+a000(16)=0x8ef000**，所以新分配的2048B的起始地址就是**0x8ef000**。
- 因为新分配了2048的地址，所以新一轮的查找地址就是上一次分配结束的地址**0x8ef000+2048=0x8ef000+800(16)=0x8ef800**。



#### 最佳适应(Best Fit)

<img src = "img/r2-3.png">

- 除了先前的内存信息提示，BestFit新增了红框标出的**空闲分区表信息**。**每次分配新的分区就会打印一次当前内存的空闲分区表。**
- **因为分配新的分区就会打印一次，所以在第一次打印各个分区的起始地址前有5行空闲分区表信息。**可以看到从上到下，每一次新的分区分配后，空闲分区表的空闲分区都会减少。
- 在释放大小8192和4096分区后，我们分配大小为2048的分区，可以**看到空闲分区表按大小升序排列好输出，**选择**最小的且可用**空闲分区，即之前p4=4096分区释放后的空闲分区，所以地址为p4地址**0x8e4000** 。
- 之后分配大小4096的分区，根据空闲分区表，当前最小空闲分区大小2048，但是不足以让4096的新分区分配，所以选择8192的空闲分区，所以新分区起始地址为**0x8D8000**.



#### 最坏(最大)适应(Worst Fit)

<img src = "img/r2-4.png">

- 前5个分区跟BestFit一样，包括其空闲分区表，便不再重复说明
- 在释放8196和4096分区后，可以看到空闲分区**按照大小降序排列**，设置新的2048的分区，因为要优先占据大的空闲分区，所以新分区分配在p5之后，地址为**0x8e5000+40960=0x8e5000+a000(16)=0x8ef000**。
- 下个大小为4096的新分区也是分配在新的2048分区后，地址为**0x8ef000+2048=0x8ef000+600(16)=0x8ef800**。
- **重点在于先前释放的空间因为不是最大的，并没有被重新分配。**



### Assignment3

------

#### 先进先出(FIFO)

<img src = "img/r3-1.png">

- 红框标出为置换相关的输出，之前的均为内存信息，与先前的截图内容一致，便不在赘述。
- 第一个红框代表**页分区的访问顺序**，先前在实验方案已经说明本次实验的为进程分配固定大小的物理页，驻留集大小为3，代表最多只能同时容纳3个等大的页。
- **不管是什么算法，在驻留集未满，都不需要进行页面置换，因此正常按顺序为页分区分配物理页。(图中第二个红框)**

- 访问p4时，因为驻留集已经满了，所以要进行页面置换，按照FIFO算法，首先**置换最先进入驻留集的p1，所以p4地址为p1地址0x200000**。p2因为本来就存在于驻留集中，所以地址不变。
- 再次访问p1时，因为p1已经被换出，所以要**置换当前驻留集最早进入的页分区，即置换p2，所以p2地址为0x20a000**.
- 之后访问的p3一直在驻留集，所以地址不变。
- **驻留集的顺序为：4，1，3**



#### 最近最久未使用(LRU)

<img src = "img/r3-2.png">

- 红框标出为置换相关的输出，之前的均为内存信息，与先前的截图内容一致，便不在赘述。
- 同FIFO中所说明的，只有在驻留集满了才需要页面置换，在此之前的正常将页分区载入驻留集。
- 访问p4时，因为p1是最近最久未访问的(**中间间隔p2p3**)，所以p4换到p1位置。p2一样仍是存在驻留集中所以不置换，但是因为又访问了p2，**所以p2的计时器重置，p2绝对不是最近最久未访问。**
- 接下来访问p1时，**因为p2刚访问，p3访问时间早于p4**，所以p1置换p3，p1地址为p3的0x214000 。
- 再次访问p3时，因为刚被换出，最近未访问的是p4，所以p3换回p4位置，地址为0x200000 。
- **驻留集的顺序为3，2，1**

- **事实上，因为驻留集过小，p3刚被换出又需要访问，这违反时间局部性。**



### Assignment4

------

在实验方案中我们总结出三个bug：cache中的页表没更新，导致页释放后CPU仍然能访问被释放的空、没有处理进程间竞争，如果不同进程同时申请同一块物理空间，会出现竞争条件、在setup中声明申请分区时重复使用命名。将修改的代码全部放在一个映像中，运行结果：

<img src = "img/r4.png">

- 程序运行正常

- #### **因为上述提及的bug只会在极少概率的情况下影响程序的正常运行，所以要复现因bug导致的错误很难，因此只显示修改后的正常代码。**



### 遭遇问题以及解决

------

- ##### 1.在实现动态分区时，思维受限于分页机制的实现，打算脱离实验教程自己实现数据结构来管理内存空间，但因为能力不足失败。

  解决：经过长时间思考，将实验教程中的bitmap中的页大小设定为1b,即可实现对正常内存的管理，经过于TA核对，被告知”动态分区与分页的差别可以看作是分页的粒度的差别“，坚定实现方式。

- ##### 2.在将页大小设置为1B后，因为bitmap过大，按照实验教程赋值需要花费大量时间，且会出现部分位的值出错的情况。

  解决：经过近乎3小时调试发现，因为实验教程将bitmap放入0x10000于内核程序内，**这是认定了bitmap很小，但是将页大小设置为1B后，bitmap大小接近2MB，所以要放在内核程序外。**否则：

  <img src = "img/q1.png">

  - **可以看到bitmap[65536]的值为-23，出现错误，且程序卡死无后续输出。**

- ##### 3.事实上，对于Assignment4最初只考虑到”在setup中声明申请分区时重复使用命名“这一个bug，cache中页表未修改以及竞争条件的问题。

  解决：与同学讨论和通过验收后询问Ta得到解决。

  

## 实验总结

本次实验需要实现内存管理，因为当今计算机大部分都会使用分页机制，所以本次实验教程似乎以此为切入点进行教学。但事实上个人认为如果不开启虚拟内存设置，分页机制逻辑地址产生的线性地址就等同于物理地址，这就使得分页机制没有意义。所以关于分页机制的实现和虚拟内存管理的实现不应该分开，或者不应该中间还隔这两个实验，这会让读者有很强的割裂感，而且在对Assignment2进行分析时很容易被带入分页机制中，对连续内存分配和非连续内存分配的分类会产生混淆。而之后的Assignment3也是需要建立在虚拟内存已经实现的基础上才能进一步实现页面置换，但对于虚拟内存的实现分析却放在该实验之后，个人觉得略失合理性。依本人的愚见，实验教程应该循循渐进，关联性更强的内容相关应该放一起。

本次实验是个人至今为止实现耗时最久的一次，个人认为不同Assignment的跨度有点大，而且内存管理方面理论和实验的差别很大，理论的题目需考虑的远少于实际情况，如实验中还需考虑内存状态信息的存储、以及存储对应状态信息的数据结构的存储。这些都是需要更进一步的考量。再加上个人的程序设计相关的基本知识的掌握并不是非常扎实，导致在对内存分配寻址相关的部分浪费许多时间，这也点醒本人回头复习内存相关的基本知识。总体来说，这次实验的收获感要大于往期实验。



## 参考文献

[彻底搞懂虚拟内存，虚拟地址，虚拟地址空间-面包板社区 (eet-china.com)](https://www.eet-china.com/mp/a48477.html)

[(68条消息) 虚拟地址、逻辑地址、线性地址、物理地址的区别_种向日葵的小仙女的博客-CSDN博客_逻辑地址和虚拟地址的区别](https://blog.csdn.net/qiuchaoxi/article/details/79616220)